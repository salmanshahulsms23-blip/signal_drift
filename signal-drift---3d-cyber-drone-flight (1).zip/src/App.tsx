/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef, useState, useCallback } from 'react';
import {
  ScreenMode,
  MissionResult,
  LiveFlightStats,
  GameSettings,
  UserProfile,
  ProfileMeta,
} from './types/game';
import { MISSIONS } from './game/levels';
import { GameSceneManager } from './game/sceneManager';
import {
  loadSettings,
  saveSettings,
  listProfiles,
  getActiveProfileId,
  setActiveProfileId,
  loadProfile,
  saveProfile,
  createNewProfile,
  updateProfileNickname,
  deleteProfile,
  calculateLevelFromXP,
  checkAutoMigration,
  ACHIEVEMENTS,
} from './utils/storage';
import { sound } from './audio/soundEngine';

import { GameHUD } from './components/GameHUD';
import { MobileControls } from './components/MobileControls';
import { MainMenu } from './components/screens/MainMenu';
import { BriefingScreen } from './components/screens/BriefingScreen';
import { ResultScreen } from './components/screens/ResultScreen';
import { GameOverScreen } from './components/screens/GameOverScreen';
import { PauseMenu } from './components/screens/PauseMenu';
import { LevelSelect } from './components/screens/LevelSelect';
import { PilotRegistration } from './components/screens/PilotRegistration';
import { PilotSelect } from './components/screens/PilotSelect';
import { DroneHangar } from './components/screens/DroneHangar';
import { SettingsModal } from './components/screens/SettingsModal';
import { HowToPlayModal } from './components/screens/HowToPlayModal';
import { AchievementsModal } from './components/screens/AchievementsModal';

export default function App() {
  const canvasMountRef = useRef<HTMLDivElement>(null);
  const sceneManagerRef = useRef<GameSceneManager | null>(null);

  // Profile Management State
  const [profiles, setProfiles] = useState<ProfileMeta[]>(() => {
    checkAutoMigration();
    return listProfiles();
  });

  const [activeProfile, setActiveProfile] = useState<UserProfile | null>(() => {
    checkAutoMigration();
    const activeId = getActiveProfileId();
    if (activeId) {
      const p = loadProfile(activeId);
      if (p) return p;
    }
    const all = listProfiles();
    if (all.length > 0) {
      const first = loadProfile(all[0].id);
      if (first) {
        setActiveProfileId(first.id);
        return first;
      }
    }
    return null;
  });

  // Game UI State
  const [screen, setScreen] = useState<ScreenMode>(() => {
    // If no profiles exist, start at registration
    const all = listProfiles();
    return all.length === 0 ? 'registration' : 'main_menu';
  });

  const [currentMissionId, setCurrentMissionId] = useState<number>(1);
  const [liveStats, setLiveStats] = useState<LiveFlightStats | null>(null);
  const [lastResult, setLastResult] = useState<MissionResult | null>(null);
  const [failureReason, setFailureReason] = useState<string>('Telemetry Lost');

  // Modals
  const [showSettings, setShowSettings] = useState<boolean>(false);
  const [showHowToPlay, setShowHowToPlay] = useState<boolean>(false);
  const [showAchievements, setShowAchievements] = useState<boolean>(false);

  // Persistent Settings
  const [settings, setSettings] = useState<GameSettings>(() => {
    return activeProfile?.settings || loadSettings();
  });

  const currentMission = MISSIONS.find((m) => m.id === currentMissionId) || MISSIONS[0];

  // Initialize SceneManager once in isolated canvas mount
  useEffect(() => {
    if (!canvasMountRef.current) return;

    const manager = new GameSceneManager(canvasMountRef.current);
    sceneManagerRef.current = manager;

    // Load initial mission for background orbit showcase
    manager.loadMission(currentMission);
    manager.setMenuMode();

    if (activeProfile) {
      manager.updateProfileEquipment(activeProfile.upgrades, activeProfile.cosmetics);
    }

    // Initial audio settings
    sound.updateSettings(
      settings.sound,
      settings.soundVolume,
      settings.music,
      settings.musicVolume
    );

    return () => {
      manager.destroy();
      sceneManagerRef.current = null;
      sound.dispose();
    };
  }, []);

  // Sync profile equipment to scene manager whenever active profile changes
  useEffect(() => {
    if (activeProfile && sceneManagerRef.current) {
      sceneManagerRef.current.updateProfileEquipment(activeProfile.upgrades, activeProfile.cosmetics);
    }
  }, [activeProfile?.cosmetics, activeProfile?.upgrades]);

  // Update graphics quality when setting changes
  useEffect(() => {
    if (sceneManagerRef.current) {
      sceneManagerRef.current.updateGraphicsQuality(settings.graphics);
    }
  }, [settings.graphics]);

  // Handle Mission Victory
  const handleMissionWin = useCallback(
    (
      score: number,
      battery: number,
      time: number,
      accuracy: number,
      cells: number,
      creditsGained: number
    ) => {
      if (!activeProfile) return;

      const mission = MISSIONS.find((m) => m.id === currentMissionId) || MISSIONS[0];

      // Calculate Stars (1 to 3) based on score thresholds
      let stars = 1;
      if (score >= mission.starScores[2]) stars = 3;
      else if (score >= mission.starScores[1]) stars = 2;

      // Base XP
      let xpGained = 300 + stars * 150 + Math.round(score * 0.1);

      // Check achievements
      const newAchievements: string[] = [];
      const currentAch = [...activeProfile.achievements];

      const unlockAch = (id: string) => {
        if (!currentAch.includes(id)) {
          currentAch.push(id);
          const def = ACHIEVEMENTS.find((a) => a.id === id);
          if (def) {
            newAchievements.push(def.title);
            xpGained += def.xp;
          }
        }
      };

      if (mission.id === 1) unlockAch('first_flight');
      if (accuracy === 100) unlockAch('flawless_route');
      if (battery >= 65) unlockAch('energy_saver');
      if (liveStats && liveStats.collisionsCount === 0) unlockAch('no_collision');
      if (time <= mission.timeLimit * 0.5) unlockAch('speed_pilot');
      if (cells >= mission.energyCells.length && mission.energyCells.length > 0)
        unlockAch('cell_collector');
      if (mission.gates.some((g) => g.isDecoy) && liveStats && liveStats.wrongGatesHit === 0)
        unlockAch('decoy_buster');

      // Update player progress
      const prevScoreRecord = activeProfile.levelScores[mission.id];
      const bestScore = prevScoreRecord
        ? Math.max(prevScoreRecord.score, score)
        : score;
      const bestStars = prevScoreRecord
        ? Math.max(prevScoreRecord.stars, stars)
        : stars;

      const updatedLevelScores = {
        ...activeProfile.levelScores,
        [mission.id]: {
          stars: bestStars,
          score: bestScore,
          accuracy,
          bestTime: prevScoreRecord
            ? Math.min(prevScoreRecord.bestTime, time)
            : time,
          completed: true,
        },
      };

      // Check Three-Star Ace achievement (>= 8 missions with 3 stars)
      const threeStarCount = Object.values(updatedLevelScores).filter(
        (s) => s.stars >= 3
      ).length;
      if (threeStarCount >= 8) unlockAch('three_star_ace');

      // Unlock next level (up to 20)
      const nextUnlocked = Math.max(
        activeProfile.unlockedLevel,
        Math.min(20, mission.id + 1)
      );

      if (mission.id === 20) {
        unlockAch('signal_master');
      }

      const totalXp = activeProfile.xp + xpGained;
      const newLvl = calculateLevelFromXP(totalXp);
      const totalCredits = (activeProfile.credits || 0) + (creditsGained || 150);

      const updatedProfile: UserProfile = {
        ...activeProfile,
        unlockedLevel: nextUnlocked,
        xp: totalXp,
        level: newLvl,
        credits: totalCredits,
        levelScores: updatedLevelScores,
        achievements: currentAch,
        totalMissionsCompleted: activeProfile.totalMissionsCompleted + 1,
        totalGatesCleared:
          activeProfile.totalGatesCleared +
          mission.gates.filter((g) => !g.isDecoy).length,
        totalEnergyCells: activeProfile.totalEnergyCells + cells,
      };

      setActiveProfile(updatedProfile);
      saveProfile(updatedProfile);
      setProfiles(listProfiles());

      const resultData: MissionResult = {
        missionId: mission.id,
        success: true,
        score,
        stars,
        accuracy,
        batteryRemaining: battery,
        timeElapsed: time,
        cellsCollected: cells,
        totalCells: mission.energyCells.length,
        xpEarned: xpGained,
        creditsEarned: creditsGained,
        newLevel: newLvl > activeProfile.level,
        newAchievements,
      };

      setLastResult(resultData);
      setScreen('victory');
    },
    [currentMissionId, activeProfile, liveStats]
  );

  // Handle Mission Failure
  const handleMissionFail = useCallback((reason: string) => {
    setFailureReason(reason);
    setScreen('failed');
  }, []);

  // Bind SceneManager callbacks
  useEffect(() => {
    if (!sceneManagerRef.current) return;
    sceneManagerRef.current.setCallbacks(
      (stats) => setLiveStats(stats),
      handleMissionWin,
      handleMissionFail
    );
  }, [handleMissionWin, handleMissionFail]);

  // Global Keyboard Shortcuts (Pause toggle)
  useEffect(() => {
    const handleGlobalKey = (e: KeyboardEvent) => {
      if (e.code === 'Escape' || e.code === 'KeyP') {
        if (screen === 'playing') {
          sound.playButtonClick();
          sceneManagerRef.current?.pauseGameplay();
          setScreen('paused');
        } else if (screen === 'paused') {
          sound.playButtonClick();
          sceneManagerRef.current?.resumeGameplay();
          setScreen('playing');
        }
      }
    };
    window.addEventListener('keydown', handleGlobalKey);
    return () => window.removeEventListener('keydown', handleGlobalKey);
  }, [screen]);

  // --- PROFILE ACTIONS ---

  const handleCreateProfile = (nickname: string, avatar: string, starterColor: string) => {
    const newProf = createNewProfile(nickname, avatar, starterColor);
    setActiveProfile(newProf);
    setProfiles(listProfiles());
    setSettings(newProf.settings);
    if (sceneManagerRef.current) {
      sceneManagerRef.current.updateProfileEquipment(newProf.upgrades, newProf.cosmetics);
    }
    setScreen('main_menu');
  };

  const handleSelectProfile = (id: string) => {
    const prof = loadProfile(id);
    if (prof) {
      setActiveProfileId(id);
      setActiveProfile(prof);
      setSettings(prof.settings);
      if (sceneManagerRef.current) {
        sceneManagerRef.current.updateProfileEquipment(prof.upgrades, prof.cosmetics);
      }
      setScreen('main_menu');
    }
  };

  const handleEditNickname = (id: string, newNickname: string) => {
    updateProfileNickname(id, newNickname);
    if (activeProfile && activeProfile.id === id) {
      setActiveProfile({ ...activeProfile, nickname: newNickname });
    }
    setProfiles(listProfiles());
  };

  const handleDeleteProfile = (id: string) => {
    const nextActiveId = deleteProfile(id);
    const updatedList = listProfiles();
    setProfiles(updatedList);

    if (updatedList.length === 0) {
      setActiveProfile(null);
      setScreen('registration');
    } else if (nextActiveId) {
      const nextProf = loadProfile(nextActiveId);
      if (nextProf) {
        setActiveProfile(nextProf);
        setSettings(nextProf.settings);
        if (sceneManagerRef.current) {
          sceneManagerRef.current.updateProfileEquipment(nextProf.upgrades, nextProf.cosmetics);
        }
      }
    }
  };

  const handleUpdateProfile = (updated: UserProfile) => {
    setActiveProfile(updated);
    saveProfile(updated);
    setProfiles(listProfiles());
    if (sceneManagerRef.current) {
      sceneManagerRef.current.updateProfileEquipment(updated.upgrades, updated.cosmetics);
    }
  };

  const handleToggleUnlockAll = (enabled: boolean) => {
    if (!activeProfile) return;
    const updated: UserProfile = {
      ...activeProfile,
      testingUnlockedAll: enabled,
    };
    handleUpdateProfile(updated);
  };

  // --- MISSION ACTIONS ---

  const startMission = (missionId: number) => {
    const mission = MISSIONS.find((m) => m.id === missionId) || MISSIONS[0];
    setCurrentMissionId(mission.id);
    setScreen('briefing');

    if (sceneManagerRef.current) {
      if (activeProfile) {
        sceneManagerRef.current.updateProfileEquipment(activeProfile.upgrades, activeProfile.cosmetics);
      }
      sceneManagerRef.current.loadMission(mission);
      sceneManagerRef.current.startPreview();
    }
  };

  const handleLaunchFlight = () => {
    setScreen('playing');
    if (sceneManagerRef.current) {
      sceneManagerRef.current.startGameplay();
    }
  };

  const handlePause = () => {
    setScreen('paused');
    sceneManagerRef.current?.pauseGameplay();
  };

  const handleResume = () => {
    setScreen('playing');
    sceneManagerRef.current?.resumeGameplay();
  };

  const handleRestartMission = () => {
    startMission(currentMissionId);
  };

  const handleNextMission = () => {
    const nextId = Math.min(20, currentMissionId + 1);
    startMission(nextId);
  };

  const handleOpenLevelSelect = () => {
    setScreen('level_select');
  };

  const handleSaveSettings = (newSettings: GameSettings) => {
    setSettings(newSettings);
    saveSettings(newSettings);
    if (activeProfile) {
      const updated = { ...activeProfile, settings: newSettings };
      handleUpdateProfile(updated);
    }
  };

  const handleResetProgress = () => {
    if (!activeProfile) return;
    const resetProf: UserProfile = {
      ...activeProfile,
      unlockedLevel: 1,
      xp: 0,
      level: 1,
      credits: 300,
      levelScores: {},
      achievements: [],
      totalMissionsCompleted: 0,
      totalGatesCleared: 0,
      totalEnergyCells: 0,
    };
    handleUpdateProfile(resetProf);
    if (sceneManagerRef.current) {
      sceneManagerRef.current.loadMission(MISSIONS[0]);
      sceneManagerRef.current.setMenuMode();
    }
    setScreen('main_menu');
  };

  const handleSubmitQuestionAnswer = (index: number) => {
    sceneManagerRef.current?.submitQuestionAnswer(index);
  };

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-slate-950 font-sans">
      {/* 3D WebGL Canvas Mount Container */}
      <div
        ref={canvasMountRef}
        className="absolute inset-0 w-full h-full z-0 pointer-events-none"
      />

      {/* Pilot Registration Screen (shown if no profiles or user clicks Register) */}
      {screen === 'registration' && (
        <PilotRegistration
          onComplete={handleCreateProfile}
          allowCancel={profiles.length > 0}
          onCancel={() => setScreen('pilot_select')}
        />
      )}

      {/* Pilot Selection Screen */}
      {screen === 'pilot_select' && (
        <PilotSelect
          profiles={profiles}
          activeProfileId={activeProfile?.id || null}
          onSelectProfile={handleSelectProfile}
          onCreateNewPilot={() => setScreen('registration')}
          onEditNickname={handleEditNickname}
          onDeleteProfile={handleDeleteProfile}
          onClose={() => setScreen('main_menu')}
        />
      )}

      {/* Drone Hangar Screen */}
      {screen === 'hangar' && activeProfile && (
        <DroneHangar
          profile={activeProfile}
          onUpdateProfile={handleUpdateProfile}
          onClose={() => setScreen('main_menu')}
        />
      )}

      {/* In-Game Flight HUD (Playing State) */}
      {screen === 'playing' && (
        <GameHUD
          stats={liveStats}
          mission={currentMission}
          onPause={handlePause}
          onSubmitQuestionAnswer={handleSubmitQuestionAnswer}
        />
      )}

      {/* On-screen Mobile Touch Controls (Playing State) */}
      {screen === 'playing' && sceneManagerRef.current && (
        <MobileControls
          input={sceneManagerRef.current.input}
          forceShow={settings.touchControls}
        />
      )}

      {/* Main Menu Screen */}
      {screen === 'main_menu' && activeProfile && (
        <MainMenu
          profile={activeProfile}
          onPlayCampaign={() => startMission(activeProfile.unlockedLevel)}
          onOpenLevelSelect={handleOpenLevelSelect}
          onOpenHowToPlay={() => setShowHowToPlay(true)}
          onOpenAchievements={() => setShowAchievements(true)}
          onOpenSettings={() => setShowSettings(true)}
          onOpenPilotSelect={() => setScreen('pilot_select')}
          onOpenHangar={() => setScreen('hangar')}
        />
      )}

      {/* Level Select Screen */}
      {screen === 'level_select' && activeProfile && (
        <LevelSelect
          profile={activeProfile}
          onSelectMission={(id) => startMission(id)}
          onToggleUnlockAll={handleToggleUnlockAll}
          onBack={() => {
            sceneManagerRef.current?.setMenuMode();
            setScreen('main_menu');
          }}
        />
      )}

      {/* Mission Briefing Screen */}
      {screen === 'briefing' && (
        <BriefingScreen
          mission={currentMission}
          onLaunch={handleLaunchFlight}
        />
      )}

      {/* Pause Menu */}
      {screen === 'paused' && activeProfile && (
        <PauseMenu
          mission={currentMission}
          settings={settings}
          profile={activeProfile}
          onResume={handleResume}
          onRestart={handleRestartMission}
          onOpenLevelSelect={handleOpenLevelSelect}
          onSwitchPilot={() => setScreen('pilot_select')}
          onUpdateSettings={handleSaveSettings}
        />
      )}

      {/* Mission Result (Victory) Screen */}
      {screen === 'victory' && lastResult && activeProfile && (
        <ResultScreen
          result={lastResult}
          mission={currentMission}
          profile={activeProfile}
          onNextMission={handleNextMission}
          onRetryMission={handleRestartMission}
          onOpenLevelSelect={handleOpenLevelSelect}
          onOpenHangar={() => setScreen('hangar')}
        />
      )}

      {/* Mission Failed Screen */}
      {screen === 'failed' && (
        <GameOverScreen
          reason={failureReason}
          mission={currentMission}
          onRestart={handleRestartMission}
          onOpenLevelSelect={handleOpenLevelSelect}
        />
      )}

      {/* Modals */}
      {showSettings && (
        <SettingsModal
          settings={settings}
          onSave={handleSaveSettings}
          onResetProgress={handleResetProgress}
          onClose={() => setShowSettings(false)}
        />
      )}

      {showHowToPlay && (
        <HowToPlayModal onClose={() => setShowHowToPlay(false)} />
      )}

      {showAchievements && activeProfile && (
        <AchievementsModal
          playerStats={activeProfile}
          onClose={() => setShowAchievements(false)}
        />
      )}
    </div>
  );
}

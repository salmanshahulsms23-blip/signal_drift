/**
 * Signal Drift - Procedural Web Audio Engine
 * 100% self-contained synthesized SFX and cyber ambient music.
 * Zero external audio files, zero 404 dependencies.
 */

class SoundEngine {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private sfxGain: GainNode | null = null;
  private musicGain: GainNode | null = null;

  // Drone Engine Synthesizer Nodes
  private engineOsc: OscillatorNode | null = null;
  private engineSubOsc: OscillatorNode | null = null;
  private engineGain: GainNode | null = null;
  private engineFilter: BiquadFilterNode | null = null;
  private isEngineRunning: boolean = false;

  // Ambient Cyber Music Synthesizer
  private isMusicPlaying: boolean = false;
  private musicTimer: number | null = null;
  private musicStep: number = 0;

  // Settings
  private soundEnabled: boolean = true;
  private musicEnabled: boolean = true;
  private soundVolume: number = 0.8;
  private musicVolume: number = 0.5;

  constructor() {
    // AudioContext will be initialized on first user interaction
  }

  private initContext() {
    if (this.ctx) {
      if (this.ctx.state === 'suspended') {
        this.ctx.resume();
      }
      return;
    }
    const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AudioContextClass) return;

    this.ctx = new AudioContextClass();

    this.masterGain = this.ctx.createGain();
    this.masterGain.gain.setValueAtTime(1.0, this.ctx.currentTime);
    this.masterGain.connect(this.ctx.destination);

    this.sfxGain = this.ctx.createGain();
    this.sfxGain.gain.setValueAtTime(this.soundEnabled ? this.soundVolume : 0, this.ctx.currentTime);
    this.sfxGain.connect(this.masterGain);

    this.musicGain = this.ctx.createGain();
    this.musicGain.gain.setValueAtTime(this.musicEnabled ? this.musicVolume : 0, this.ctx.currentTime);
    this.musicGain.connect(this.masterGain);
  }

  public updateSettings(sound: boolean, soundVol: number, music: boolean, musicVol: number) {
    this.soundEnabled = sound;
    this.soundVolume = soundVol;
    this.musicEnabled = music;
    this.musicVolume = musicVol;

    if (this.ctx) {
      const now = this.ctx.currentTime;
      if (this.sfxGain) {
        this.sfxGain.gain.setTargetAtTime(sound ? soundVol : 0, now, 0.05);
      }
      if (this.musicGain) {
        this.musicGain.gain.setTargetAtTime(music ? musicVol : 0, now, 0.05);
      }
    }

    if (music && !this.isMusicPlaying) {
      this.startMusic();
    } else if (!music && this.isMusicPlaying) {
      this.stopMusic();
    }
  }

  // Mobile vibration helper
  public triggerVibration(pattern: number | number[]) {
    try {
      if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
        navigator.vibrate(pattern);
      }
    } catch {
      // Ignore vibration errors if not allowed
    }
  }

  // --- DRONE ENGINE HUM ---
  public startEngine() {
    this.initContext();
    if (!this.ctx || !this.sfxGain || this.isEngineRunning) return;

    try {
      const now = this.ctx.currentTime;
      this.engineOsc = this.ctx.createOscillator();
      this.engineSubOsc = this.ctx.createOscillator();
      this.engineFilter = this.ctx.createBiquadFilter();
      this.engineGain = this.ctx.createGain();

      this.engineOsc.type = 'sawtooth';
      this.engineOsc.frequency.setValueAtTime(65, now);

      this.engineSubOsc.type = 'triangle';
      this.engineSubOsc.frequency.setValueAtTime(32.5, now);

      this.engineFilter.type = 'lowpass';
      this.engineFilter.frequency.setValueAtTime(180, now);
      this.engineFilter.Q.setValueAtTime(3, now);

      this.engineGain.gain.setValueAtTime(0.01, now);
      this.engineGain.gain.setTargetAtTime(0.18, now, 0.2);

      this.engineOsc.connect(this.engineFilter);
      this.engineSubOsc.connect(this.engineFilter);
      this.engineFilter.connect(this.engineGain);
      this.engineGain.connect(this.sfxGain);

      this.engineOsc.start(now);
      this.engineSubOsc.start(now);
      this.isEngineRunning = true;
    } catch {
      // Audio engine fallback
    }
  }

  public updateEnginePitch(speedRatio: number, isBoosting: boolean) {
    if (!this.ctx || !this.isEngineRunning || !this.engineOsc || !this.engineFilter || !this.engineGain) return;
    const now = this.ctx.currentTime;
    const baseFreq = 65 + speedRatio * 85 + (isBoosting ? 60 : 0);
    const filterFreq = 180 + speedRatio * 420 + (isBoosting ? 650 : 0);
    const vol = 0.12 + speedRatio * 0.12 + (isBoosting ? 0.15 : 0);

    this.engineOsc.frequency.setTargetAtTime(baseFreq, now, 0.08);
    if (this.engineSubOsc) {
      this.engineSubOsc.frequency.setTargetAtTime(baseFreq * 0.5, now, 0.08);
    }
    this.engineFilter.frequency.setTargetAtTime(filterFreq, now, 0.08);
    this.engineGain.gain.setTargetAtTime(this.soundEnabled ? vol : 0, now, 0.08);
  }

  public stopEngine() {
    if (!this.ctx || !this.isEngineRunning) return;
    try {
      const now = this.ctx.currentTime;
      if (this.engineGain) {
        this.engineGain.gain.setTargetAtTime(0, now, 0.1);
      }
      setTimeout(() => {
        try {
          this.engineOsc?.stop();
          this.engineSubOsc?.stop();
          this.engineOsc?.disconnect();
          this.engineSubOsc?.disconnect();
          this.engineFilter?.disconnect();
          this.engineGain?.disconnect();
        } catch {
          // ignore
        }
        this.engineOsc = null;
        this.engineSubOsc = null;
        this.engineFilter = null;
        this.engineGain = null;
        this.isEngineRunning = false;
      }, 120);
    } catch {
      this.isEngineRunning = false;
    }
  }

  // --- SOUND EFFECTS ---

  public playGateCleared(index: number) {
    this.initContext();
    if (!this.ctx || !this.sfxGain || !this.soundEnabled) return;
    const now = this.ctx.currentTime;

    // Harmonic arpeggio based on gate sequence index
    const baseFreqs = [523.25, 659.25, 783.99, 1046.50, 1318.51, 1567.98]; // C, E, G, C5, E5, G5
    const root = baseFreqs[index % baseFreqs.length];

    [0, 0.06, 0.12].forEach((delay, i) => {
      const osc = this.ctx!.createOscillator();
      const gain = this.ctx!.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(root * (1 + i * 0.25), now + delay);
      gain.gain.setValueAtTime(0.25, now + delay);
      gain.gain.exponentialRampToValueAtTime(0.001, now + delay + 0.45);

      osc.connect(gain);
      gain.connect(this.sfxGain!);
      osc.start(now + delay);
      osc.stop(now + delay + 0.5);
    });

    this.triggerVibration([30, 20, 40]);
  }

  public playWrongGate() {
    this.initContext();
    if (!this.ctx || !this.sfxGain || !this.soundEnabled) return;
    const now = this.ctx.currentTime;

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(140, now);
    osc.frequency.linearRampToValueAtTime(90, now + 0.25);

    gain.gain.setValueAtTime(0.3, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.3);

    osc.connect(gain);
    gain.connect(this.sfxGain);
    osc.start(now);
    osc.stop(now + 0.35);

    this.triggerVibration([80, 50, 80]);
  }

  public playEnergyPickup() {
    this.initContext();
    if (!this.ctx || !this.sfxGain || !this.soundEnabled) return;
    const now = this.ctx.currentTime;

    const freqs = [880, 1108.73, 1320, 1760]; // A5 major chime
    freqs.forEach((f, i) => {
      const osc = this.ctx!.createOscillator();
      const gain = this.ctx!.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(f, now + i * 0.04);
      gain.gain.setValueAtTime(0.2, now + i * 0.04);
      gain.gain.exponentialRampToValueAtTime(0.001, now + i * 0.04 + 0.3);

      osc.connect(gain);
      gain.connect(this.sfxGain!);
      osc.start(now + i * 0.04);
      osc.stop(now + i * 0.04 + 0.35);
    });

    this.triggerVibration(45);
  }

  public playCollision() {
    this.initContext();
    if (!this.ctx || !this.sfxGain || !this.soundEnabled) return;
    const now = this.ctx.currentTime;

    // Deep sub punch
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(130, now);
    osc.frequency.exponentialRampToValueAtTime(30, now + 0.25);

    gain.gain.setValueAtTime(0.5, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.3);

    // Crunch noise
    const bufferSize = this.ctx.sampleRate * 0.15;
    const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      data[i] = (Math.random() * 2 - 1) * Math.exp(-i / (bufferSize * 0.25));
    }
    const noise = this.ctx.createBufferSource();
    noise.buffer = buffer;
    const noiseFilter = this.ctx.createBiquadFilter();
    noiseFilter.type = 'bandpass';
    noiseFilter.frequency.setValueAtTime(450, now);
    const noiseGain = this.ctx.createGain();
    noiseGain.gain.setValueAtTime(0.4, now);
    noiseGain.gain.exponentialRampToValueAtTime(0.01, now + 0.2);

    osc.connect(gain);
    gain.connect(this.sfxGain);

    noise.connect(noiseFilter);
    noiseFilter.connect(noiseGain);
    noiseGain.connect(this.sfxGain);

    osc.start(now);
    osc.stop(now + 0.3);
    noise.start(now);

    this.triggerVibration([60, 40, 100]);
  }

  public playBoost() {
    this.initContext();
    if (!this.ctx || !this.sfxGain || !this.soundEnabled) return;
    const now = this.ctx.currentTime;

    const osc = this.ctx.createOscillator();
    const filter = this.ctx.createBiquadFilter();
    const gain = this.ctx.createGain();

    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(120, now);
    osc.frequency.linearRampToValueAtTime(260, now + 0.3);

    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(300, now);
    filter.frequency.linearRampToValueAtTime(1200, now + 0.25);

    gain.gain.setValueAtTime(0.2, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);

    osc.connect(filter);
    filter.connect(gain);
    gain.connect(this.sfxGain);

    osc.start(now);
    osc.stop(now + 0.4);
  }

  public playTowerActivation() {
    this.initContext();
    if (!this.ctx || !this.sfxGain || !this.soundEnabled) return;
    const now = this.ctx.currentTime;

    // Epic ascending cyber pulse
    const freqs = [220, 330, 440, 554.37, 659.25, 880, 1108.73, 1320];
    freqs.forEach((f, i) => {
      const osc = this.ctx!.createOscillator();
      const gain = this.ctx!.createGain();
      osc.type = i % 2 === 0 ? 'sine' : 'sawtooth';
      osc.frequency.setValueAtTime(f, now + i * 0.12);

      gain.gain.setValueAtTime(0.25, now + i * 0.12);
      gain.gain.exponentialRampToValueAtTime(0.001, now + i * 0.12 + 0.9);

      osc.connect(gain);
      gain.connect(this.sfxGain!);
      osc.start(now + i * 0.12);
      osc.stop(now + i * 0.12 + 1.0);
    });

    this.triggerVibration([100, 50, 150, 50, 300]);
  }

  public playMissionSuccess() {
    this.initContext();
    if (!this.ctx || !this.sfxGain || !this.soundEnabled) return;
    const now = this.ctx.currentTime;

    const chords = [
      [523.25, 659.25, 783.99], // C major
      [587.33, 739.99, 880.00], // D major
      [659.25, 830.61, 987.77], // E major
      [1046.50, 1318.51, 1567.98] // C6 high burst
    ];

    chords.forEach((chord, step) => {
      const stepTime = now + step * 0.22;
      chord.forEach(f => {
        const osc = this.ctx!.createOscillator();
        const gain = this.ctx!.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(f, stepTime);
        gain.gain.setValueAtTime(0.2, stepTime);
        gain.gain.exponentialRampToValueAtTime(0.001, stepTime + 0.7);

        osc.connect(gain);
        gain.connect(this.sfxGain!);
        osc.start(stepTime);
        osc.stop(stepTime + 0.75);
      });
    });

    this.triggerVibration([80, 50, 80, 50, 250]);
  }

  public playMissionFailed() {
    this.initContext();
    if (!this.ctx || !this.sfxGain || !this.soundEnabled) return;
    const now = this.ctx.currentTime;

    const notes = [329.63, 311.13, 293.66, 277.18, 220.00]; // descending minor
    notes.forEach((f, i) => {
      const t = now + i * 0.18;
      const osc = this.ctx!.createOscillator();
      const gain = this.ctx!.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(f, t);
      gain.gain.setValueAtTime(0.25, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.4);

      osc.connect(gain);
      gain.connect(this.sfxGain!);
      osc.start(t);
      osc.stop(t + 0.45);
    });

    this.triggerVibration([150, 80, 250]);
  }

  public playButtonClick() {
    this.initContext();
    if (!this.ctx || !this.sfxGain || !this.soundEnabled) return;
    const now = this.ctx.currentTime;

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(900, now);
    osc.frequency.exponentialRampToValueAtTime(1400, now + 0.04);

    gain.gain.setValueAtTime(0.12, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.05);

    osc.connect(gain);
    gain.connect(this.sfxGain);
    osc.start(now);
    osc.stop(now + 0.06);
  }

  public playCountdownBeep(highPitch: boolean = false) {
    this.initContext();
    if (!this.ctx || !this.sfxGain || !this.soundEnabled) return;
    const now = this.ctx.currentTime;

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(highPitch ? 1200 : 600, now);

    gain.gain.setValueAtTime(0.2, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + (highPitch ? 0.35 : 0.15));

    osc.connect(gain);
    gain.connect(this.sfxGain);
    osc.start(now);
    osc.stop(now + (highPitch ? 0.4 : 0.2));
  }

  // --- GENERATIVE CYBER AMBIENT MUSIC ---
  public startMusic() {
    this.initContext();
    if (!this.ctx || !this.musicGain || !this.musicEnabled || this.isMusicPlaying) return;

    this.isMusicPlaying = true;
    this.musicStep = 0;
    this.scheduleNextMusicNote();
  }

  private scheduleNextMusicNote() {
    if (!this.isMusicPlaying || !this.ctx || !this.musicGain || !this.musicEnabled) return;

    const chordProgression = [
      [130.81, 196.00, 261.63, 392.00], // C3, G3, C4, G4
      [116.54, 174.61, 233.08, 349.23], // Bb2, F3, Bb3, F4
      [146.83, 220.00, 293.66, 440.00], // D3, A3, D4, A4
      [123.47, 185.00, 246.94, 369.99], // B2, F#3, B3, F#4
    ];

    const currentChord = chordProgression[Math.floor(this.musicStep / 8) % chordProgression.length];
    const now = this.ctx.currentTime;

    // Soft warm synth pad chord on phrase boundary
    if (this.musicStep % 8 === 0) {
      currentChord.forEach(f => {
        const osc = this.ctx!.createOscillator();
        const filter = this.ctx!.createBiquadFilter();
        const gain = this.ctx!.createGain();

        osc.type = 'triangle';
        osc.frequency.setValueAtTime(f, now);

        filter.type = 'lowpass';
        filter.frequency.setValueAtTime(450, now);

        gain.gain.setValueAtTime(0.001, now);
        gain.gain.linearRampToValueAtTime(0.06, now + 1.2);
        gain.gain.linearRampToValueAtTime(0.001, now + 3.8);

        osc.connect(filter);
        filter.connect(gain);
        gain.connect(this.musicGain!);

        osc.start(now);
        osc.stop(now + 4.0);
      });
    }

    // Melodic cyber pulse every 2 steps
    if (this.musicStep % 2 === 0) {
      const melodyFreqs = [523.25, 659.25, 783.99, 880, 1046.50];
      const noteFreq = melodyFreqs[(this.musicStep * 3) % melodyFreqs.length];

      const leadOsc = this.ctx.createOscillator();
      const leadGain = this.ctx.createGain();
      leadOsc.type = 'sine';
      leadOsc.frequency.setValueAtTime(noteFreq, now);

      leadGain.gain.setValueAtTime(0.025, now);
      leadGain.gain.exponentialRampToValueAtTime(0.0005, now + 0.35);

      leadOsc.connect(leadGain);
      leadGain.connect(this.musicGain);

      leadOsc.start(now);
      leadOsc.stop(now + 0.4);
    }

    this.musicStep++;
    // 120 BPM tempo: 8th notes are 250ms
    this.musicTimer = window.setTimeout(() => this.scheduleNextMusicNote(), 250);
  }

  public stopMusic() {
    this.isMusicPlaying = false;
    if (this.musicTimer !== null) {
      clearTimeout(this.musicTimer);
      this.musicTimer = null;
    }
  }

  public dispose() {
    this.stopEngine();
    this.stopMusic();
    if (this.ctx && this.ctx.state !== 'closed') {
      this.ctx.close();
    }
    this.ctx = null;
  }
}

export const sound = new SoundEngine();

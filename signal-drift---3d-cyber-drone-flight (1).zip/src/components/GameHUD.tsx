import React from 'react';
import { LiveFlightStats, MissionData } from '../types/game';
import { sound } from '../audio/soundEngine';

interface GameHUDProps {
  stats: LiveFlightStats | null;
  mission: MissionData | null;
  onPause: () => void;
  onSubmitQuestionAnswer?: (index: number) => void;
}

export const GameHUD: React.FC<GameHUDProps> = ({
  stats,
  mission,
  onPause,
  onSubmitQuestionAnswer,
}) => {
  if (!stats || !mission) return null;

  const isBatteryLow = stats.battery < 25;
  const isBatteryCritical = stats.battery < 15;
  const batteryColor = isBatteryCritical
    ? 'bg-rose-500 shadow-[0_0_12px_rgba(244,63,94,0.8)]'
    : isBatteryLow
    ? 'bg-amber-400 shadow-[0_0_10px_rgba(251,191,36,0.6)]'
    : 'bg-cyan-400 shadow-[0_0_10px_rgba(6,182,212,0.6)]';

  const isHealthLow = stats.health < 35;
  const healthColor = isHealthLow
    ? 'bg-rose-500 shadow-[0_0_10px_rgba(244,63,94,0.7)]'
    : 'bg-emerald-400 shadow-[0_0_10px_rgba(52,211,153,0.5)]';

  const minutes = Math.floor(stats.timeRemaining / 60);
  const seconds = stats.timeRemaining % 60;
  const formattedTime = `${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;

  const renderSymbolIcon = (sym: string) => {
    switch (sym) {
      case 'triangle': return '▲';
      case 'circle': return '●';
      case 'star': return '★';
      case 'lightning': return '⚡';
      case 'diamond': return '◆';
      case 'hexagon': return '⬡';
      default: return '●';
    }
  };

  const getSymbolBg = (color: string) => {
    switch (color) {
      case 'red': return 'bg-rose-500/20 text-rose-300 border-rose-500/60';
      case 'blue': return 'bg-blue-500/20 text-blue-300 border-blue-500/60';
      case 'green': return 'bg-emerald-500/20 text-emerald-300 border-emerald-500/60';
      case 'purple': return 'bg-purple-500/20 text-purple-300 border-purple-500/60';
      case 'orange': return 'bg-orange-500/20 text-orange-300 border-orange-500/60';
      case 'yellow': return 'bg-amber-500/20 text-amber-300 border-amber-500/60';
      case 'cyan': return 'bg-cyan-500/20 text-cyan-300 border-cyan-500/60';
      default: return 'bg-cyan-500/20 text-cyan-300 border-cyan-500/60';
    }
  };

  // Turbo Meter Progress
  let turboMeterRatio = 1.0;
  let turboLabel = 'TURBO READY';
  let turboColor = 'bg-cyan-400 shadow-[0_0_10px_rgba(6,182,212,0.8)]';

  if (stats.turboState === 'active') {
    turboMeterRatio = stats.turboTimeRemaining / 6.0;
    turboLabel = `OVERDRIVE (${stats.turboTimeRemaining}s)`;
    turboColor = 'bg-amber-400 shadow-[0_0_12px_rgba(251,191,36,0.9)]';
  } else if (stats.turboState === 'cooldown') {
    turboMeterRatio = 1 - stats.turboCooldownRemaining / 3.0;
    turboLabel = `COOLING (${stats.turboCooldownRemaining}s)`;
    turboColor = 'bg-slate-500';
  }

  return (
    <div className="absolute inset-0 pointer-events-none select-none z-10 flex flex-col justify-between p-3 sm:p-5">
      {/* --- TOP PERIMETER CLUSTER --- */}
      <div className="flex items-start justify-between w-full">
        {/* Left: Mission & Next Target Requirement */}
        <div className="flex flex-col gap-1.5">
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 text-xs font-display font-bold bg-cyan-950/90 border border-cyan-500/40 text-cyan-400 rounded">
              M{mission.id.toString().padStart(2, '0')}
            </span>
            <span className="text-xs sm:text-sm font-tech text-slate-300 font-semibold tracking-wider uppercase drop-shadow">
              {mission.name}
            </span>
          </div>

          {/* Current Target Requirement Badge (PART 2: Only shows next required gate's color & symbol!) */}
          <div className="flex items-center gap-2.5 px-3 py-1.5 bg-slate-950/85 border border-cyan-500/30 rounded-xl shadow-lg">
            {stats.towerActive ? (
              <div className="w-3 h-3 rounded-full bg-amber-400 animate-ping" />
            ) : stats.nextGateRequirement ? (
              <div
                className={`w-7 h-7 rounded-lg border flex items-center justify-center font-display font-black text-sm shadow-md ${getSymbolBg(
                  stats.nextGateRequirement.color
                )}`}
              >
                {renderSymbolIcon(stats.nextGateRequirement.symbol)}
              </div>
            ) : null}

            <div className="flex flex-col">
              <span className="text-[10px] text-slate-400 uppercase font-tech tracking-wider">
                {stats.towerActive
                  ? 'Final Objective'
                  : `Next Required Gate (${stats.currentGateIndex + 1} / ${stats.totalGates})`}
              </span>
              <span className="text-sm sm:text-base font-display font-bold text-cyan-300 tracking-wide drop-shadow">
                {stats.nextTargetName}
              </span>
            </div>

            <div className="ml-2 pl-2 border-l border-slate-700/60 text-right">
              <span className="text-xs font-tech tabular-nums font-bold text-slate-200">
                {stats.nextTargetDistance}m
              </span>
            </div>
          </div>

          {/* Timed Gate Circular Alert Countdown (Missions 8-10, 20) */}
          {stats.timedGateSecondsLeft !== null && (
            <div className="flex items-center gap-2 px-3 py-1 bg-amber-950/90 border border-amber-500/70 rounded-lg text-amber-300 shadow-[0_0_15px_rgba(245,158,11,0.4)] animate-pulse">
              <span className="text-xs font-display font-black">⏱️ GATE TIMEOUT:</span>
              <span className="text-sm font-display font-bold tabular-nums">
                {stats.timedGateSecondsLeft}s
              </span>
            </div>
          )}
        </div>

        {/* Center: Bearing Compass or Blackout Static */}
        <div className="hidden md:flex flex-col items-center">
          {stats.isBlackout ? (
            <div className="relative w-44 h-10 bg-slate-950/90 border border-rose-500/60 rounded-lg flex items-center justify-center overflow-hidden shadow-[0_0_15px_rgba(244,63,94,0.3)]">
              <span className="text-[10px] font-tech font-bold text-rose-400 tracking-wider uppercase animate-pulse">
                ⚠️ SIGNAL BLACKOUT
              </span>
            </div>
          ) : (
            <div className="relative w-36 h-10 bg-slate-950/80 border border-slate-800 rounded-lg flex items-center justify-center overflow-hidden">
              <div className="absolute inset-x-0 top-0 h-[1px] bg-gradient-to-r from-transparent via-cyan-500 to-transparent" />
              <div className="flex items-center gap-2">
                <span className="text-[11px] font-tech text-slate-400 uppercase tracking-widest">
                  Bearing
                </span>
                <span className="text-sm font-display font-bold text-cyan-400 tabular-nums">
                  {stats.compassAngle}°
                </span>
              </div>
              <div
                className="absolute bottom-1 w-2 h-2 border-l-2 border-b-2 border-cyan-400 transition-transform duration-75"
                style={{
                  transform: `translateX(${Math.max(-55, Math.min(55, stats.compassAngle * 0.7))}px) rotate(-45deg)`,
                }}
              />
            </div>
          )}

          {stats.missionStatusText && (
            <span
              className={`mt-1.5 text-[11px] font-tech tracking-widest uppercase font-semibold px-2 py-0.5 rounded ${
                stats.towerActive
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                  : 'text-slate-400'
              }`}
            >
              {stats.missionStatusText}
            </span>
          )}
        </div>

        {/* Top Right: Timer, Score, Credits, Pause */}
        <div className="flex items-center gap-2.5">
          {/* Mission Timer */}
          <div className="flex flex-col items-end px-3 py-1 bg-slate-950/85 border border-slate-800 rounded-lg">
            <span className="text-[10px] font-tech uppercase text-slate-400 tracking-wider">
              Time
            </span>
            <span
              className={`text-lg sm:text-xl font-display font-bold tabular-nums ${
                stats.timeRemaining < 20 ? 'text-rose-400 animate-pulse' : 'text-slate-100'
              }`}
            >
              {formattedTime}
            </span>
          </div>

          {/* Live Credits */}
          <div className="hidden sm:flex flex-col items-end px-3 py-1 bg-slate-950/85 border border-slate-800 rounded-lg">
            <span className="text-[10px] font-tech uppercase text-amber-400 tracking-wider">
              Credits
            </span>
            <span className="text-lg font-display font-bold text-amber-300 tabular-nums">
              +{stats.creditsEarnedThisFlight}
            </span>
          </div>

          {/* Current Score */}
          <div className="flex flex-col items-end px-3 py-1 bg-slate-950/85 border border-slate-800 rounded-lg">
            <span className="text-[10px] font-tech uppercase text-slate-400 tracking-wider">
              Score
            </span>
            <span className="text-lg sm:text-xl font-display font-bold text-cyan-400 tabular-nums glow-cyan">
              {stats.score.toLocaleString()}
            </span>
          </div>

          {/* Pause Button */}
          <button
            onClick={() => {
              sound.playButtonClick();
              onPause();
            }}
            className="pointer-events-auto p-2 sm:px-3 sm:py-2 bg-slate-900/90 hover:bg-slate-800 border border-slate-700 hover:border-cyan-500/50 rounded-lg text-slate-300 hover:text-cyan-400 transition-colors shadow-lg active:scale-95"
            title="Pause Flight (Esc)"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 9v6m4-6v6m7-3a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
          </button>
        </div>
      </div>

      {/* --- QUESTION GATE MODAL (Missions 11-13, 20) --- */}
      {stats.activeQuestionGate && (
        <div className="pointer-events-auto my-auto mx-auto w-full max-w-md bg-slate-950/95 border border-cyan-500/80 rounded-3xl p-6 shadow-[0_0_50px_rgba(6,182,212,0.4)] flex flex-col items-center text-center animate-in fade-in zoom-in duration-200">
          <div className="w-12 h-12 rounded-2xl bg-cyan-500/20 border border-cyan-500/60 flex items-center justify-center text-cyan-300 text-xl mb-2">
            🧠
          </div>
          <span className="text-xs font-tech font-bold text-cyan-400 tracking-[0.25em] uppercase">
            NEURAL GATEWAY TELEMETRY QUERY
          </span>

          {stats.activeQuestionGate.timeRemaining !== undefined && (
            <span className="text-xs font-display font-bold text-amber-400 my-1">
              Time Remaining: {stats.activeQuestionGate.timeRemaining}s
            </span>
          )}

          <p className="text-sm font-tech font-bold text-slate-100 my-3">
            {stats.activeQuestionGate.question}
          </p>

          <div className="flex flex-col gap-2.5 w-full mt-2">
            {stats.activeQuestionGate.options.map((opt, idx) => (
              <button
                key={idx}
                onClick={() => {
                  sound.playButtonClick();
                  onSubmitQuestionAnswer?.(idx);
                }}
                className="w-full py-2.5 px-4 rounded-xl bg-slate-900 hover:bg-cyan-950/80 border border-slate-700 hover:border-cyan-400 text-xs font-tech font-bold text-slate-200 hover:text-cyan-300 transition-all text-left flex items-center gap-2 active:scale-98"
              >
                <span className="w-5 h-5 rounded-md bg-slate-800 text-cyan-400 flex items-center justify-center text-[10px] font-display font-bold">
                  {String.fromCharCode(65 + idx)}
                </span>
                <span>{opt}</span>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* --- BOTTOM PERIMETER CLUSTER --- */}
      <div className="flex items-end justify-between w-full">
        {/* Left: Battery & Hull & Shield Gauge */}
        <div className="flex flex-col gap-2 w-48 sm:w-60 bg-slate-950/85 border border-slate-800/90 rounded-xl p-3 shadow-xl">
          {/* Battery Status */}
          <div className="flex flex-col gap-1">
            <div className="flex justify-between items-center text-xs font-tech">
              <span className="text-slate-400 uppercase tracking-wider flex items-center gap-1">
                <span>⚡</span> Power Reserve
              </span>
              <span
                className={`font-display font-bold tabular-nums ${
                  isBatteryCritical
                    ? 'text-rose-400 animate-pulse'
                    : isBatteryLow
                    ? 'text-amber-400'
                    : 'text-cyan-400'
                }`}
              >
                {stats.battery}%
              </span>
            </div>
            <div className="h-2 w-full bg-slate-800 rounded-full overflow-hidden p-[1px]">
              <div
                className={`h-full rounded-full transition-all duration-150 ${batteryColor}`}
                style={{ width: `${stats.battery}%` }}
              />
            </div>
          </div>

          {/* Hull Health & Shield */}
          <div className="flex flex-col gap-1">
            <div className="flex justify-between items-center text-xs font-tech">
              <span className="text-slate-400 uppercase tracking-wider flex items-center gap-1">
                <span>🛡️</span> Hull Integrity
                {stats.shieldActive && (
                  <span className="text-[10px] text-cyan-400 border border-cyan-500/50 px-1 rounded bg-cyan-950">
                    SHIELD ACTIVE
                  </span>
                )}
              </span>
              <span
                className={`font-display font-bold tabular-nums ${
                  isHealthLow ? 'text-rose-400 animate-pulse' : 'text-emerald-400'
                }`}
              >
                {stats.health}%
              </span>
            </div>
            <div className="h-1.5 w-full bg-slate-800 rounded-full overflow-hidden p-[1px]">
              <div
                className={`h-full rounded-full transition-all duration-150 ${healthColor}`}
                style={{ width: `${stats.health}%` }}
              />
            </div>
          </div>

          {/* Altitude indicator (PART 6) */}
          <div className="flex justify-between items-center text-[10px] font-tech text-slate-400 pt-1 border-t border-slate-800/60">
            <span>ALTITUDE:</span>
            <span className="font-display font-bold text-cyan-400 tabular-nums">
              {stats.altitude}m
            </span>
          </div>
        </div>

        {/* Center: Flight Dynamics & Turbo Meter (PART 5) */}
        <div className="hidden sm:flex flex-col items-center gap-1.5 px-4 py-2 bg-slate-950/85 border border-slate-800/80 rounded-xl min-w-[210px]">
          <div className="flex items-baseline gap-1">
            <span className="text-2xl font-display font-bold text-slate-100 tabular-nums">
              {stats.speed}
            </span>
            <span className="text-[10px] font-tech text-slate-400 uppercase tracking-wider">
              km/h
            </span>
          </div>

          {/* Turbo Boost Meter */}
          <div className="w-full flex flex-col gap-1">
            <div className="flex justify-between items-center text-[10px] font-tech">
              <span className="text-slate-400 font-bold uppercase tracking-wider">
                {turboLabel}
              </span>
            </div>
            <div className="h-2 w-full bg-slate-800 rounded-full overflow-hidden p-[1px]">
              <div
                className={`h-full rounded-full transition-all duration-100 ${turboColor}`}
                style={{ width: `${Math.round(turboMeterRatio * 100)}%` }}
              />
            </div>
          </div>

          {stats.streak > 1 && (
            <span className="text-[10px] font-display text-amber-400 font-bold">
              x{stats.streak} CHAIN
            </span>
          )}
        </div>

        {/* Right: Sequence Progress & Pickups */}
        <div className="flex flex-col items-end gap-1.5 bg-slate-950/85 border border-slate-800/90 rounded-xl p-3 shadow-xl">
          <div className="flex items-center gap-2 text-xs font-tech text-slate-300">
            <span className="text-slate-400 uppercase tracking-wider">Gate Progress</span>
            <span className="font-display font-bold text-cyan-400">
              {stats.currentGateIndex} / {stats.totalGates}
            </span>
          </div>

          <div className="flex items-center gap-1.5 text-xs font-tech text-slate-300">
            <span className="text-slate-400 uppercase tracking-wider">Cells:</span>
            <span className="font-display font-bold text-amber-400">
              {stats.cellsCollected} / {stats.totalCells}
            </span>
            <span>💎</span>
          </div>

          {stats.wrongGatesHit > 0 && (
            <span className="text-[10px] font-tech text-rose-400">
              Sequence Errors: {stats.wrongGatesHit}
            </span>
          )}
        </div>
      </div>
    </div>
  );
};

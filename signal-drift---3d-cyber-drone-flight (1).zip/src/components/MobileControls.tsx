import React, { useEffect, useState } from 'react';
import { InputState } from '../game/sceneManager';

interface MobileControlsProps {
  input: InputState;
  forceShow?: boolean;
}

export const MobileControls: React.FC<MobileControlsProps> = ({ input, forceShow = false }) => {
  const [isTouchDevice, setIsTouchDevice] = useState(false);

  useEffect(() => {
    const hasTouch =
      'ontouchstart' in window ||
      navigator.maxTouchPoints > 0 ||
      window.matchMedia('(pointer: coarse)').matches;
    setIsTouchDevice(hasTouch);
  }, []);

  if (!isTouchDevice && !forceShow) return null;

  const handleTouch = (key: keyof InputState, active: boolean) => (e: React.TouchEvent | React.MouseEvent) => {
    e.preventDefault();
    input[key] = active;
  };

  return (
    <div className="absolute inset-0 pointer-events-none select-none z-20 flex justify-between items-end p-4 sm:p-6 pb-6">
      {/* Left Cluster: Throttle & Steering */}
      <div className="flex flex-col gap-2 pointer-events-auto">
        <div className="flex justify-center mb-1">
          <button
            onTouchStart={handleTouch('forward', true)}
            onTouchEnd={handleTouch('forward', false)}
            onMouseDown={handleTouch('forward', true)}
            onMouseUp={handleTouch('forward', false)}
            className="w-16 h-14 bg-slate-900/85 active:bg-cyan-600/80 border border-slate-700/80 active:border-cyan-400 rounded-xl flex items-center justify-center text-cyan-300 shadow-xl transition-transform active:scale-95"
            aria-label="Throttle Forward"
          >
            <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M5 15l7-7 7 7" />
            </svg>
          </button>
        </div>

        <div className="flex items-center gap-3">
          <button
            onTouchStart={handleTouch('left', true)}
            onTouchEnd={handleTouch('left', false)}
            onMouseDown={handleTouch('left', true)}
            onMouseUp={handleTouch('left', false)}
            className="w-16 h-14 bg-slate-900/85 active:bg-cyan-600/80 border border-slate-700/80 active:border-cyan-400 rounded-xl flex items-center justify-center text-cyan-300 shadow-xl transition-transform active:scale-95"
            aria-label="Steer Left"
          >
            <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M15 19l-7-7 7-7" />
            </svg>
          </button>

          <button
            onTouchStart={handleTouch('down', true)}
            onTouchEnd={handleTouch('down', false)}
            onMouseDown={handleTouch('down', true)}
            onMouseUp={handleTouch('down', false)}
            className="w-16 h-14 bg-slate-900/85 active:bg-amber-600/80 border border-slate-700/80 active:border-amber-400 rounded-xl flex flex-col items-center justify-center text-amber-300 shadow-xl transition-transform active:scale-95"
            aria-label="Descend"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M19 9l-7 7-7-7" />
            </svg>
            <span className="text-[10px] font-display font-bold">DESCEND</span>
          </button>

          <button
            onTouchStart={handleTouch('right', true)}
            onTouchEnd={handleTouch('right', false)}
            onMouseDown={handleTouch('right', true)}
            onMouseUp={handleTouch('right', false)}
            className="w-16 h-14 bg-slate-900/85 active:bg-cyan-600/80 border border-slate-700/80 active:border-cyan-400 rounded-xl flex items-center justify-center text-cyan-300 shadow-xl transition-transform active:scale-95"
            aria-label="Steer Right"
          >
            <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M9 5l7 7-7 7" />
            </svg>
          </button>
        </div>
      </div>

      {/* Right Cluster: Turbo Overdrive & Vertical Lift/Descend */}
      <div className="flex flex-col gap-2.5 items-end pointer-events-auto">
        <button
          onTouchStart={handleTouch('boost', true)}
          onTouchEnd={handleTouch('boost', false)}
          onMouseDown={handleTouch('boost', true)}
          onMouseUp={handleTouch('boost', false)}
          className="w-28 h-14 bg-gradient-to-r from-amber-600/90 to-rose-600/90 active:from-amber-500 active:to-rose-500 border border-amber-400/80 rounded-2xl flex items-center justify-center text-white font-display font-black tracking-wider text-sm shadow-[0_0_15px_rgba(245,158,11,0.5)] transition-transform active:scale-95"
          aria-label="Hold for Turbo Boost"
        >
          TURBO ⚡
        </button>

        <div className="flex items-center gap-2">
          {/* Descend button */}
          <button
            onTouchStart={handleTouch('down', true)}
            onTouchEnd={handleTouch('down', false)}
            onMouseDown={handleTouch('down', true)}
            onMouseUp={handleTouch('down', false)}
            className="w-16 h-16 bg-slate-900/85 active:bg-slate-700/90 border border-slate-700/80 rounded-2xl flex flex-col items-center justify-center text-slate-300 shadow-lg active:scale-95"
            aria-label="Descend"
          >
            <svg className="w-6 h-6 text-slate-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
            </svg>
            <span className="text-[9px] font-tech font-bold uppercase text-slate-400">DESCEND</span>
          </button>

          {/* Ascend Lift button */}
          <button
            onTouchStart={handleTouch('up', true)}
            onTouchEnd={handleTouch('up', false)}
            onMouseDown={handleTouch('up', true)}
            onMouseUp={handleTouch('up', false)}
            className="w-18 h-18 bg-cyan-900/85 active:bg-cyan-500/90 border border-cyan-400/80 rounded-2xl flex flex-col items-center justify-center text-cyan-200 shadow-[0_0_15px_rgba(6,182,212,0.4)] active:scale-95"
            aria-label="Ascend Lift"
          >
            <svg className="w-7 h-7 text-cyan-200" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M5 10l7-7m0 0l7 7m-7-7v18" />
            </svg>
            <span className="text-[10px] font-display font-bold uppercase text-cyan-200">ASCEND</span>
          </button>
        </div>
      </div>
    </div>
  );
};

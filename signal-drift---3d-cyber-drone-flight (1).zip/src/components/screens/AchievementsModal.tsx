import React from 'react';
import { PlayerStats } from '../../types/game';
import { ACHIEVEMENTS } from '../../utils/storage';
import { sound } from '../../audio/soundEngine';

interface AchievementsModalProps {
  playerStats: PlayerStats;
  onClose: () => void;
}

export const AchievementsModal: React.FC<AchievementsModalProps> = ({
  playerStats,
  onClose,
}) => {
  const earnedCount = playerStats.achievements.length;

  return (
    <div className="absolute inset-0 z-50 flex items-center justify-center p-4 select-none bg-slate-950/80 overflow-y-auto">
      <div className="w-full max-w-xl bg-slate-950/95 border border-cyan-500/40 rounded-3xl p-6 sm:p-7 shadow-[0_0_50px_rgba(6,182,212,0.25)] flex flex-col my-auto max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex flex-col">
            <h3 className="text-xl font-display font-black text-slate-100 flex items-center gap-2">
              <span>🏆</span> PILOT HONORS
            </h3>
            <span className="text-xs font-tech text-cyan-400 uppercase tracking-widest">
              Career Achievements ({earnedCount} / {ACHIEVEMENTS.length} Unlocked)
            </span>
          </div>
          <button
            onClick={() => {
              sound.playButtonClick();
              onClose();
            }}
            className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-slate-100 transition-colors"
          >
            ✕
          </button>
        </div>

        {/* Achievements List */}
        <div className="flex flex-col gap-2.5 py-4 overflow-y-auto pr-1">
          {ACHIEVEMENTS.map((ach) => {
            const isUnlocked = playerStats.achievements.includes(ach.id);
            return (
              <div
                key={ach.id}
                className={`flex items-center justify-between p-3 rounded-2xl border transition-all ${
                  isUnlocked
                    ? 'bg-slate-900/80 border-cyan-500/40 shadow-sm'
                    : 'bg-slate-950/40 border-slate-800/40 opacity-50'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div
                    className={`w-11 h-11 rounded-xl flex items-center justify-center text-xl ${
                      isUnlocked
                        ? 'bg-cyan-950/80 border border-cyan-500/50 shadow-[0_0_10px_rgba(6,182,212,0.4)]'
                        : 'bg-slate-900 border border-slate-800 text-slate-600'
                    }`}
                  >
                    {isUnlocked ? ach.icon : '🔒'}
                  </div>

                  <div className="flex flex-col">
                    <span
                      className={`text-sm font-display font-bold ${
                        isUnlocked ? 'text-slate-100' : 'text-slate-400'
                      }`}
                    >
                      {ach.title}
                    </span>
                    <span className="text-xs font-tech text-slate-400">
                      {ach.description}
                    </span>
                  </div>
                </div>

                <div className="flex flex-col items-end pl-3">
                  <span
                    className={`text-xs font-display font-bold tabular-nums ${
                      isUnlocked ? 'text-amber-400' : 'text-slate-500'
                    }`}
                  >
                    +{ach.xp} XP
                  </span>
                  {isUnlocked && (
                    <span className="text-[10px] font-tech text-emerald-400 font-bold uppercase">
                      CLAIMED ✓
                    </span>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Close Button */}
        <button
          onClick={() => {
            sound.playButtonClick();
            onClose();
          }}
          className="mt-2 w-full py-3 px-6 rounded-xl bg-slate-900 hover:bg-slate-850 border border-slate-700 text-slate-200 font-display font-bold text-xs tracking-wider transition-all"
        >
          CLOSE
        </button>
      </div>
    </div>
  );
};

import React, { useEffect, useState } from 'react';
import { MissionData } from '../../types/game';
import { sound } from '../../audio/soundEngine';

interface BriefingScreenProps {
  mission: MissionData;
  onLaunch: () => void;
}

export const BriefingScreen: React.FC<BriefingScreenProps> = ({ mission, onLaunch }) => {
  const [countdown, setCountdown] = useState<number>(3);

  // Gates sequence (excluding decoys)
  const trueSequence = mission.gates.filter((g) => !g.isDecoy);

  useEffect(() => {
    // 3-second countdown
    sound.playCountdownBeep(false);

    const interval = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          return 0;
        }
        sound.playCountdownBeep(false);
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  // Safely trigger onLaunch after countdown reaches 0
  useEffect(() => {
    if (countdown === 0) {
      sound.playCountdownBeep(true);
      const timer = setTimeout(() => {
        onLaunch();
      }, 450);
      return () => clearTimeout(timer);
    }
  }, [countdown, onLaunch]);

  const getSymbolIcon = (symbol?: string) => {
    switch (symbol) {
      case 'triangle': return '▲';
      case 'circle': return '●';
      case 'star': return '★';
      case 'lightning': return '⚡';
      case 'diamond': return '◆';
      case 'hexagon': return '⬡';
      default: return '●';
    }
  };

  const getColorPill = (color: string) => {
    switch (color) {
      case 'red':
        return 'bg-rose-500/20 text-rose-300 border-rose-500/50 shadow-[0_0_10px_rgba(244,63,94,0.3)]';
      case 'blue':
        return 'bg-blue-500/20 text-blue-300 border-blue-500/50 shadow-[0_0_10px_rgba(59,130,246,0.3)]';
      case 'green':
        return 'bg-emerald-500/20 text-emerald-300 border-emerald-500/50 shadow-[0_0_10px_rgba(16,185,129,0.3)]';
      case 'purple':
        return 'bg-purple-500/20 text-purple-300 border-purple-500/50 shadow-[0_0_10px_rgba(168,85,247,0.3)]';
      case 'orange':
        return 'bg-orange-500/20 text-orange-300 border-orange-500/50 shadow-[0_0_10px_rgba(249,115,22,0.3)]';
      case 'yellow':
        return 'bg-amber-500/20 text-amber-300 border-amber-500/50 shadow-[0_0_10px_rgba(245,158,11,0.3)]';
      case 'cyan':
        return 'bg-cyan-500/20 text-cyan-300 border-cyan-500/50 shadow-[0_0_10px_rgba(6,182,212,0.3)]';
      case 'magenta':
        return 'bg-pink-500/20 text-pink-300 border-pink-500/50 shadow-[0_0_10px_rgba(236,72,153,0.3)]';
      default:
        return 'bg-cyan-500/20 text-cyan-300 border-cyan-500/50';
    }
  };

  return (
    <div className="absolute inset-0 z-30 pointer-events-none flex flex-col justify-between items-center p-4 sm:p-8 select-none">
      {/* Top Briefing Banner */}
      <div className="flex flex-col items-center text-center max-w-2xl bg-slate-950/90 backdrop-blur-md border border-cyan-500/40 rounded-3xl p-5 sm:p-6 shadow-[0_0_50px_rgba(6,182,212,0.25)] pointer-events-auto">
        <div className="flex items-center gap-2">
          <span className="text-[10px] font-tech font-bold text-cyan-400 tracking-[0.25em] uppercase px-2.5 py-0.5 rounded-full bg-cyan-950/80 border border-cyan-500/30">
            DISTRICT {mission.id.toString().padStart(2, '0')} · {mission.sector}
          </span>
          {mission.gates.some((g) => g.isDecoy) && (
            <span className="text-[10px] font-tech font-bold text-rose-400 tracking-wider uppercase px-2 py-0.5 rounded bg-rose-950/80 border border-rose-500/40">
              ⚠️ Decoy Jammers
            </span>
          )}
          {mission.isBlackout && (
            <span className="text-[10px] font-tech font-bold text-amber-400 tracking-wider uppercase px-2 py-0.5 rounded bg-amber-950/80 border border-amber-500/40">
              ⚡ Radar Blackout
            </span>
          )}
        </div>

        <h2 className="text-2xl sm:text-3xl font-display font-black text-slate-100 mt-2">
          {mission.name}
        </h2>
        <p className="text-xs sm:text-sm font-tech text-slate-300 font-semibold mt-1.5 max-w-lg">
          {mission.briefing}
        </p>

        {/* Gate Sequence Memory Ribbon */}
        <div className="mt-4 flex flex-col items-center w-full">
          <div className="flex items-center gap-2 mb-2.5">
            <span className="w-8 h-[1px] bg-cyan-500/50" />
            <span className="text-[11px] font-tech text-cyan-400 uppercase tracking-widest font-black">
              Memorize Sequence ({trueSequence.length} Gates)
            </span>
            <span className="w-8 h-[1px] bg-cyan-500/50" />
          </div>

          <div className="flex flex-wrap items-center justify-center gap-2 w-full">
            {trueSequence.map((gate, i) => {
              const symIcon = getSymbolIcon(gate.symbol);
              const symName = gate.symbol ? gate.symbol.charAt(0).toUpperCase() + gate.symbol.slice(1) : '';
              const colorName = gate.color ? gate.color.charAt(0).toUpperCase() + gate.color.slice(1) : '';

              return (
                <div key={gate.id} className="flex items-center">
                  <div
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-display font-bold shadow-md ${getColorPill(
                      gate.color
                    )}`}
                  >
                    <span className="text-sm">{symIcon}</span>
                    <span className="tracking-wide">
                      {colorName} {symName}
                    </span>
                    {gate.isTimed && (
                      <span className="text-[9px] px-1 py-0.2 rounded bg-amber-500/30 text-amber-200">
                        ⏱️
                      </span>
                    )}
                    {gate.isQuestionGate && (
                      <span className="text-[9px] px-1 py-0.2 rounded bg-purple-500/30 text-purple-200">
                        ❓
                      </span>
                    )}
                  </div>
                  {i < trueSequence.length - 1 && (
                    <span className="mx-1 text-slate-500 text-xs font-bold">→</span>
                  )}
                </div>
              );
            })}
            <span className="mx-1 text-amber-400 text-xs font-bold">→</span>
            <div className="px-3.5 py-1.5 rounded-xl border border-amber-500/60 bg-amber-500/20 text-amber-300 text-xs font-display font-bold flex items-center gap-1.5 shadow-[0_0_12px_rgba(245,158,11,0.4)]">
              <span>🗼</span>
              <span>Signal Tower</span>
            </div>
          </div>
          <span className="text-[10px] font-tech text-slate-400 mt-2 italic">
            HUD will hide the full sequence during flight and only show the immediate next required gate.
          </span>
        </div>
      </div>

      {/* Center Countdown Pulse */}
      <div className="flex flex-col items-center justify-center my-auto">
        <span className="text-xs font-tech text-cyan-400 uppercase tracking-[0.3em] font-bold mb-1">
          LAUNCH SEQUENCE IN
        </span>
        <div className="text-7xl sm:text-8xl font-display font-black text-cyan-400 drop-shadow-[0_0_30px_rgba(6,182,212,0.8)] animate-pulse">
          {countdown > 0 ? countdown : 'GO!'}
        </div>
      </div>

      {/* Bottom Skip Button */}
      <div className="pointer-events-auto">
        <button
          onClick={() => {
            sound.playButtonClick();
            onLaunch();
          }}
          className="px-6 py-2.5 rounded-2xl bg-slate-900/90 hover:bg-slate-800 border border-slate-700 hover:border-cyan-400 text-xs font-display font-bold text-slate-200 hover:text-cyan-300 shadow-xl transition-all"
        >
          SKIP PREVIEW (LAUNCH NOW)
        </button>
      </div>
    </div>
  );
};

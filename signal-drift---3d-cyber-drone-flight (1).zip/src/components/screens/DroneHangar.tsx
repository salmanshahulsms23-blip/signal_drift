import React, { useState } from 'react';
import { UserProfile } from '../../types/game';
import {
  HANGAR_SKINS,
  HANGAR_UPGRADES,
  STARTER_COLORS,
} from '../../utils/storage';
import { sound } from '../../audio/soundEngine';

interface DroneHangarProps {
  profile: UserProfile;
  onUpdateProfile: (updated: UserProfile) => void;
  onClose: () => void;
}

export const DroneHangar: React.FC<DroneHangarProps> = ({
  profile,
  onUpdateProfile,
  onClose,
}) => {
  const [activeTab, setActiveTab] = useState<'cosmetics' | 'upgrades'>('cosmetics');
  const [purchaseMsg, setPurchaseMsg] = useState<string | null>(null);

  const showFeedback = (msg: string) => {
    setPurchaseMsg(msg);
    setTimeout(() => setPurchaseMsg(null), 2500);
  };

  // Cosmetic handlers
  const handleEquipSkin = (skinId: string) => {
    sound.playButtonClick();
    const updated: UserProfile = {
      ...profile,
      cosmetics: {
        ...profile.cosmetics,
        equippedSkin: skinId,
      },
    };
    onUpdateProfile(updated);
    showFeedback('Skin equipped successfully!');
  };

  const handleBuySkin = (skinId: string, price: number) => {
    if (profile.credits < price) {
      sound.playWrongGate();
      showFeedback('Insufficient Signal Credits!');
      return;
    }

    sound.playGateCleared(0);
    const updated: UserProfile = {
      ...profile,
      credits: profile.credits - price,
      cosmetics: {
        ...profile.cosmetics,
        purchasedSkins: [...profile.cosmetics.purchasedSkins, skinId],
        equippedSkin: skinId,
      },
    };
    onUpdateProfile(updated);
    showFeedback('Skin purchased and equipped!');
  };

  const handleEquipEngineColor = (colorId: string) => {
    sound.playButtonClick();
    const updated: UserProfile = {
      ...profile,
      cosmetics: {
        ...profile.cosmetics,
        equippedEngineColor: colorId,
      },
    };
    onUpdateProfile(updated);
    showFeedback('Engine color applied!');
  };

  // Upgrade handlers
  const handleBuyUpgrade = (upgradeId: string) => {
    const upgradeDef = HANGAR_UPGRADES.find((u) => u.id === upgradeId);
    if (!upgradeDef) return;

    const currentLvl = (profile.upgrades as any)[upgradeId] || 0;
    if (currentLvl >= upgradeDef.maxLevel) return;

    const cost = Math.round(upgradeDef.baseCost * Math.pow(upgradeDef.costMultiplier, currentLvl));
    if (profile.credits < cost) {
      sound.playWrongGate();
      showFeedback('Insufficient Signal Credits!');
      return;
    }

    sound.playGateCleared(currentLvl + 1);
    const updated: UserProfile = {
      ...profile,
      credits: profile.credits - cost,
      upgrades: {
        ...profile.upgrades,
        [upgradeId]: currentLvl + 1,
      },
    };
    onUpdateProfile(updated);
    showFeedback(`${upgradeDef.name} upgraded to Level ${currentLvl + 1}!`);
  };

  return (
    <div className="absolute inset-0 z-40 flex items-center justify-center p-4 select-none bg-slate-950/90 overflow-y-auto">
      <div className="w-full max-w-4xl bg-slate-950/95 border border-cyan-500/40 rounded-3xl p-6 sm:p-8 shadow-[0_0_50px_rgba(6,182,212,0.3)] flex flex-col my-auto max-h-[92vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <span className="text-3xl">🛸</span>
            <div className="flex flex-col">
              <span className="text-xs font-tech font-bold text-cyan-400 tracking-[0.25em] uppercase">
                AVIONICS & ARMORY
              </span>
              <h2 className="text-2xl sm:text-3xl font-display font-black text-slate-100">
                DRONE HANGAR
              </h2>
            </div>
          </div>

          <div className="flex items-center gap-4">
            {/* Live Credits Badge */}
            <div className="flex items-center gap-2 bg-slate-900 border border-amber-500/50 rounded-xl px-4 py-2">
              <span className="text-amber-400 text-lg">⚡</span>
              <div className="flex flex-col">
                <span className="text-[10px] font-tech text-slate-400 uppercase tracking-wider">
                  Credits Balance
                </span>
                <span className="text-sm font-display font-bold text-amber-300 tabular-nums">
                  {profile.credits.toLocaleString()} SC
                </span>
              </div>
            </div>

            <button
              onClick={() => {
                sound.playButtonClick();
                onClose();
              }}
              className="p-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-slate-100 transition-colors"
            >
              ✕
            </button>
          </div>
        </div>

        {/* Tab Switcher & Feedback Bar */}
        <div className="flex items-center justify-between mt-4">
          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                sound.playButtonClick();
                setActiveTab('cosmetics');
              }}
              className={`py-2 px-5 rounded-xl font-display font-bold text-xs tracking-wider transition-all ${
                activeTab === 'cosmetics'
                  ? 'bg-cyan-500 text-slate-950 shadow-[0_0_15px_rgba(6,182,212,0.4)]'
                  : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
              }`}
            >
              🎨 DRONE SKINS & FINISHES
            </button>

            <button
              onClick={() => {
                sound.playButtonClick();
                setActiveTab('upgrades');
              }}
              className={`py-2 px-5 rounded-xl font-display font-bold text-xs tracking-wider transition-all ${
                activeTab === 'upgrades'
                  ? 'bg-cyan-500 text-slate-950 shadow-[0_0_15px_rgba(6,182,212,0.4)]'
                  : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
              }`}
            >
              ⚡ PERFORMANCE UPGRADES
            </button>
          </div>

          {purchaseMsg && (
            <span className="text-xs font-tech font-bold text-emerald-400 bg-emerald-950/80 border border-emerald-500/50 px-3 py-1 rounded-lg animate-in fade-in">
              {purchaseMsg}
            </span>
          )}
        </div>

        {/* TAB 1: COSMETICS */}
        {activeTab === 'cosmetics' && (
          <div className="flex flex-col gap-6 py-4 overflow-y-auto">
            {/* Skins Grid */}
            <div className="flex flex-col gap-2.5">
              <h3 className="text-xs font-tech uppercase text-cyan-400 font-bold tracking-wider">
                Hull Skins ({profile.cosmetics.purchasedSkins.length} / {HANGAR_SKINS.length} Unlocked)
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
                {HANGAR_SKINS.map((skin) => {
                  const isPurchased = profile.cosmetics.purchasedSkins.includes(skin.id);
                  const isEquipped = profile.cosmetics.equippedSkin === skin.id;

                  return (
                    <div
                      key={skin.id}
                      className={`p-4 rounded-2xl border transition-all flex flex-col justify-between ${
                        isEquipped
                          ? 'bg-slate-900/90 border-cyan-500 shadow-[0_0_15px_rgba(6,182,212,0.25)]'
                          : 'bg-slate-950/70 border-slate-800 hover:border-slate-700'
                      }`}
                    >
                      <div>
                        <div className="flex items-center justify-between mb-2">
                          <span className="font-display font-bold text-sm text-slate-100">
                            {skin.name}
                          </span>
                          <span
                            className="w-4 h-4 rounded-full border border-slate-600 shadow"
                            style={{ backgroundColor: `#${skin.accentColor.toString(16).padStart(6, '0')}` }}
                          />
                        </div>
                        <p className="text-xs font-tech text-slate-400 min-h-[32px]">
                          {skin.description}
                        </p>
                      </div>

                      <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between">
                        {isPurchased ? (
                          <button
                            onClick={() => handleEquipSkin(skin.id)}
                            className={`w-full py-2 px-3 rounded-xl font-display font-bold text-xs tracking-wider transition-all ${
                              isEquipped
                                ? 'bg-cyan-950 text-cyan-300 border border-cyan-500/60'
                                : 'bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-700'
                            }`}
                          >
                            {isEquipped ? 'EQUIPPED ✓' : 'EQUIP SKIN'}
                          </button>
                        ) : (
                          <button
                            onClick={() => handleBuySkin(skin.id, skin.price)}
                            className="w-full py-2 px-3 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-display font-bold text-xs tracking-wider flex items-center justify-center gap-1.5 shadow"
                          >
                            <span>PURCHASE</span>
                            <span>({skin.price} SC)</span>
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Engine Light Finish */}
            <div className="flex flex-col gap-2.5 pt-4 border-t border-slate-800">
              <h3 className="text-xs font-tech uppercase text-cyan-400 font-bold tracking-wider">
                Engine Thruster Light Spectrum
              </h3>
              <div className="grid grid-cols-2 sm:grid-cols-6 gap-2.5">
                {STARTER_COLORS.map((col) => {
                  const isEquipped = profile.cosmetics.equippedEngineColor === col.id;
                  return (
                    <button
                      key={col.id}
                      onClick={() => handleEquipEngineColor(col.id)}
                      className={`p-3 rounded-xl border flex items-center gap-2 transition-all ${
                        isEquipped
                          ? 'bg-slate-850 border-cyan-400 shadow-md scale-102'
                          : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
                      }`}
                    >
                      <span
                        className="w-4 h-4 rounded-full shadow"
                        style={{ backgroundColor: col.hex }}
                      />
                      <span className="text-xs font-tech font-bold text-slate-200">
                        {col.label}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: UPGRADES */}
        {activeTab === 'upgrades' && (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 py-4 overflow-y-auto">
            {HANGAR_UPGRADES.map((upg) => {
              const currentLvl = (profile.upgrades as any)[upg.id] || 0;
              const isMax = currentLvl >= upg.maxLevel;
              const nextCost = Math.round(upg.baseCost * Math.pow(upg.costMultiplier, currentLvl));
              const canAfford = profile.credits >= nextCost;

              return (
                <div
                  key={upg.id}
                  className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-center justify-between mb-1.5">
                      <span className="font-display font-bold text-sm text-slate-100">
                        {upg.name}
                      </span>
                      <span className="text-xs font-tech text-cyan-400 font-bold">
                        Lvl {currentLvl} / {upg.maxLevel}
                      </span>
                    </div>

                    <p className="text-xs font-tech text-slate-400">
                      {upg.description}
                    </p>

                    {/* Progress Level Pips */}
                    <div className="flex items-center gap-1.5 mt-3">
                      {Array.from({ length: upg.maxLevel }).map((_, idx) => (
                        <div
                          key={idx}
                          className={`h-2 flex-1 rounded-full transition-all ${
                            idx < currentLvl
                              ? 'bg-cyan-400 shadow-[0_0_8px_rgba(6,182,212,0.6)]'
                              : 'bg-slate-800'
                          }`}
                        />
                      ))}
                    </div>
                  </div>

                  <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between">
                    {isMax ? (
                      <span className="text-xs font-tech text-emerald-400 font-bold uppercase w-full text-center py-2">
                        MAX LEVEL REACHED ✓
                      </span>
                    ) : (
                      <button
                        onClick={() => handleBuyUpgrade(upg.id)}
                        disabled={!canAfford}
                        className={`w-full py-2.5 px-3 rounded-xl font-display font-bold text-xs tracking-wider flex items-center justify-center gap-2 transition-all ${
                          canAfford
                            ? 'bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 shadow-md active:scale-98'
                            : 'bg-slate-900 text-slate-600 border border-slate-800 cursor-not-allowed'
                        }`}
                      >
                        <span>UPGRADE</span>
                        <span>({nextCost.toLocaleString()} SC)</span>
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* Footer */}
        <div className="flex items-center justify-between pt-3 border-t border-slate-800 text-xs font-tech text-slate-500">
          <span>All purchased cosmetics and performance upgrades auto-save to active profile: {profile.nickname}</span>
          <button
            onClick={() => {
              sound.playButtonClick();
              onClose();
            }}
            className="py-2 px-5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 font-display font-bold"
          >
            RETURN TO FLIGHT DESK
          </button>
        </div>
      </div>
    </div>
  );
};

import React from 'react';
import { MissionData } from '../../types/game';
import { sound } from '../../audio/soundEngine';

interface GameOverScreenProps {
  reason: string;
  mission: MissionData;
  onRestart: () => void;
  onOpenLevelSelect: () => void;
}

export const GameOverScreen: React.FC<GameOverScreenProps> = ({
  reason,
  mission,
  onRestart,
  onOpenLevelSelect,
}) => {
  const getTip = () => {
    if (reason.toLowerCase().includes('battery')) {
      return 'Pilot Advisory: Harvest glowing cyan energy crystals along the flight path to replenish battery power.';
    }
    if (reason.toLowerCase().includes('hull') || reason.toLowerCase().includes('collision')) {
      return 'Pilot Advisory: Counter-steer against crosswinds and watch building spires. Tap Space for emergency vertical lift.';
    }
    if (reason.toLowerCase().includes('time')) {
      return 'Pilot Advisory: Hold Shift to activate Turbo Overdrive during open city corridors to cut flight time.';
    }
    return 'Pilot Advisory: Study the colored gate sequence during the pre-flight briefing to avoid decoy penalties.';
  };

  return (
    <div className="absolute inset-0 z-30 flex items-center justify-center p-4 select-none bg-slate-950/75">
      <div className="w-full max-w-md bg-slate-950/95 border border-rose-500/40 rounded-3xl p-6 sm:p-8 shadow-[0_0_50px_rgba(244,63,94,0.25)] flex flex-col items-center text-center">
        {/* Warning Icon */}
        <div className="w-16 h-16 rounded-2xl bg-rose-500/10 border border-rose-500/40 flex items-center justify-center text-rose-500 mb-3 shadow-[0_0_20px_rgba(244,63,94,0.3)]">
          <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
          </svg>
        </div>

        <span className="text-xs font-tech font-bold text-rose-400 tracking-[0.3em] uppercase">
          TELEMETRY LOST
        </span>
        <h2 className="text-3xl font-display font-black text-slate-100 mt-1">
          MISSION FAILED
        </h2>

        {/* Cause */}
        <div className="mt-3 px-3 py-1.5 bg-rose-500/15 border border-rose-500/30 rounded-lg">
          <span className="text-sm font-display font-bold text-rose-300">
            {reason.toUpperCase()}
          </span>
        </div>

        {/* Advisory Tip */}
        <p className="text-xs font-tech text-slate-300 font-semibold mt-4 px-2 bg-slate-900/60 border border-slate-800 rounded-xl p-3">
          {getTip()}
        </p>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row items-center gap-3 w-full mt-6">
          <button
            onClick={() => {
              sound.playButtonClick();
              onRestart();
            }}
            className="w-full sm:flex-1 py-3.5 px-6 rounded-xl bg-gradient-to-r from-rose-500 to-amber-600 hover:from-rose-400 hover:to-amber-500 active:scale-95 text-slate-950 font-display font-bold text-sm tracking-wider shadow-[0_0_20px_rgba(244,63,94,0.4)] transition-all flex items-center justify-center gap-2"
          >
            <span>RESTART FLIGHT</span>
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
            </svg>
          </button>

          <button
            onClick={() => {
              sound.playButtonClick();
              onOpenLevelSelect();
            }}
            className="w-full sm:w-auto py-3.5 px-5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 hover:border-slate-500 active:scale-95 text-slate-300 font-display font-bold text-xs tracking-wider transition-all"
          >
            MISSION LOG
          </button>
        </div>
      </div>
    </div>
  );
};

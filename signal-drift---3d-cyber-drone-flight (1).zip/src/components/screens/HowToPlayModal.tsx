import React from 'react';
import { sound } from '../../audio/soundEngine';

interface HowToPlayModalProps {
  onClose: () => void;
}

export const HowToPlayModal: React.FC<HowToPlayModalProps> = ({ onClose }) => {
  return (
    <div className="absolute inset-0 z-50 flex items-center justify-center p-4 select-none bg-slate-950/80 overflow-y-auto">
      <div className="w-full max-w-2xl bg-slate-950/95 border border-cyan-500/40 rounded-3xl p-6 sm:p-8 shadow-[0_0_50px_rgba(6,182,212,0.25)] flex flex-col my-auto max-h-[92vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex flex-col">
            <h3 className="text-xl sm:text-2xl font-display font-black text-slate-100">
              FLIGHT ACADEMY
            </h3>
            <span className="text-xs font-tech text-cyan-400 uppercase tracking-widest">
              Avionics & Mission Protocol
            </span>
          </div>
          <button
            onClick={() => {
              sound.playButtonClick();
              onClose();
            }}
            className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-slate-100 transition-colors"
          >
            ✕
          </button>
        </div>

        {/* Content Sections */}
        <div className="flex flex-col gap-5 py-4">
          {/* 1. Core Mission Loop */}
          <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-4">
            <h4 className="text-sm font-display font-bold text-cyan-300 uppercase flex items-center gap-2 mb-2">
              <span>🎯</span> Mission Objective
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs font-tech text-slate-300">
              <div className="bg-slate-950/60 border border-slate-800/80 p-2.5 rounded-xl">
                <span className="text-cyan-400 font-bold block mb-1">1. Memorize</span>
                During the briefing, watch the gate route light up in sequence across the skyline.
              </div>
              <div className="bg-slate-950/60 border border-slate-800/80 p-2.5 rounded-xl">
                <span className="text-cyan-400 font-bold block mb-1">2. Navigate</span>
                Fly through the correct gates in the exact remembered order. Avoid fake decoy rings!
              </div>
              <div className="bg-slate-950/60 border border-slate-800/80 p-2.5 rounded-xl">
                <span className="text-amber-400 font-bold block mb-1">3. Restore</span>
                Reach the final Signal Tower apex to upload the telemetry packet and restore the district.
              </div>
            </div>
          </div>

          {/* 2. Controls Grid */}
          <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-4">
            <h4 className="text-sm font-display font-bold text-cyan-300 uppercase flex items-center gap-2 mb-3">
              <span>🎮</span> Flight Controls
            </h4>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-xs font-tech">
              <div className="bg-slate-950/70 border border-slate-800 p-2.5 rounded-xl flex flex-col">
                <span className="text-cyan-400 font-display font-bold">W / ↑ Up</span>
                <span className="text-slate-300">Throttle Forward</span>
              </div>
              <div className="bg-slate-950/70 border border-slate-800 p-2.5 rounded-xl flex flex-col">
                <span className="text-cyan-400 font-display font-bold">S / ↓ Down</span>
                <span className="text-slate-300">Air Brake / Reverse</span>
              </div>
              <div className="bg-slate-950/70 border border-slate-800 p-2.5 rounded-xl flex flex-col">
                <span className="text-cyan-400 font-display font-bold">A / D (← / →)</span>
                <span className="text-slate-300">Steer & Bank Turn</span>
              </div>
              <div className="bg-slate-950/70 border border-slate-800 p-2.5 rounded-xl flex flex-col">
                <span className="text-cyan-400 font-display font-bold">Space</span>
                <span className="text-slate-300">Vertical Ascend</span>
              </div>
              <div className="bg-slate-950/70 border border-slate-800 p-2.5 rounded-xl flex flex-col">
                <span className="text-cyan-400 font-display font-bold">C / Ctrl</span>
                <span className="text-slate-300">Dive Altitude</span>
              </div>
              <div className="bg-slate-950/70 border border-slate-800 p-2.5 rounded-xl flex flex-col">
                <span className="text-amber-400 font-display font-bold">Shift</span>
                <span className="text-slate-300">Turbo Overdrive</span>
              </div>
              <div className="bg-slate-950/70 border border-slate-800 p-2.5 rounded-xl flex flex-col col-span-2">
                <span className="text-slate-300 font-display font-bold">📱 Mobile Touch</span>
                <span className="text-slate-400">On-screen throttle, steering & boost buttons</span>
              </div>
            </div>
          </div>

          {/* 3. Tactical Elements & Hazards */}
          <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-4">
            <h4 className="text-sm font-display font-bold text-cyan-300 uppercase flex items-center gap-2 mb-2">
              <span>⚠️</span> City Hazards & Pickups
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs font-tech text-slate-300">
              <div className="flex items-start gap-2">
                <span className="text-base">⚡</span>
                <div>
                  <strong className="text-cyan-300">Energy Cells:</strong> Refuel 25% battery and add bonus score. Essential in high-drain districts!
                </div>
              </div>
              <div className="flex items-start gap-2">
                <span className="text-base">🌪️</span>
                <div>
                  <strong className="text-blue-300">Wind Corridors:</strong> Crosswinds push the drone sideways. Counter-steer into the wind to stay on course.
                </div>
              </div>
              <div className="flex items-start gap-2">
                <span className="text-base">🚚</span>
                <div>
                  <strong className="text-amber-300">Metro Drone Traffic:</strong> Automated delivery drones cross skyways. Time your flyby to avoid collisions.
                </div>
              </div>
              <div className="flex items-start gap-2">
                <span className="text-base">🚨</span>
                <div>
                  <strong className="text-rose-300">Decoy Gates & Lasers:</strong> Red/decoy gates penalize accuracy and score. Intermittent lasers cause hull damage.
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Dismiss Button */}
        <button
          onClick={() => {
            sound.playButtonClick();
            onClose();
          }}
          className="mt-2 w-full py-3 px-6 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 active:scale-95 text-slate-950 font-display font-bold text-sm tracking-wider shadow-lg transition-all"
        >
          READY FOR FLIGHT
        </button>
      </div>
    </div>
  );
};

import React from 'react';
import { MISSIONS } from '../../game/levels';
import { UserProfile } from '../../types/game';
import { sound } from '../../audio/soundEngine';

interface LevelSelectProps {
  profile: UserProfile;
  onSelectMission: (missionId: number) => void;
  onToggleUnlockAll: (enabled: boolean) => void;
  onBack: () => void;
}

export const LevelSelect: React.FC<LevelSelectProps> = ({
  profile,
  onSelectMission,
  onToggleUnlockAll,
  onBack,
}) => {
  const isUnlockAll = !!profile.testingUnlockedAll;

  // Total stars
  const totalStars = Object.values(profile.levelScores || {}).reduce(
    (acc, curr) => acc + (curr.stars || 0),
    0
  );

  return (
    <div className="absolute inset-0 z-30 flex flex-col justify-between p-4 sm:p-6 select-none bg-slate-950/95 overflow-y-auto">
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between w-full max-w-6xl mx-auto gap-3 pb-3 border-b border-slate-800">
        <div className="flex items-center gap-3 w-full sm:w-auto">
          <button
            onClick={() => {
              sound.playButtonClick();
              onBack();
            }}
            className="p-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 hover:text-cyan-400 transition-colors"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
            </svg>
          </button>
          <div className="flex flex-col">
            <h2 className="text-2xl sm:text-3xl font-display font-black text-slate-100 flex items-center gap-2">
              <span>MISSION DATABASE</span>
              <span className="text-xs font-tech font-bold px-2 py-0.5 rounded-full bg-cyan-950 border border-cyan-500/40 text-cyan-400">
                20 DISTRICTS
              </span>
            </h2>
            <span className="text-xs font-tech text-slate-400">
              Active Pilot: <strong className="text-cyan-300">{profile.nickname}</strong> · {profile.avatar}
            </span>
          </div>
        </div>

        {/* Global Progress & Testing Unlock All Toggle */}
        <div className="flex items-center gap-3 w-full sm:w-auto justify-between sm:justify-end">
          {/* Developer Test Toggle */}
          <button
            onClick={() => {
              sound.playButtonClick();
              onToggleUnlockAll(!isUnlockAll);
            }}
            className={`px-3 py-1.5 rounded-xl border text-xs font-tech font-bold flex items-center gap-2 transition-all ${
              isUnlockAll
                ? 'bg-amber-950/80 border-amber-500/60 text-amber-300 shadow-[0_0_12px_rgba(245,158,11,0.3)]'
                : 'bg-slate-900/90 border-slate-700 text-slate-400 hover:border-slate-500 hover:text-slate-200'
            }`}
            title="Unlock all missions for testing"
          >
            <span>{isUnlockAll ? '🔓 Testing: ALL UNLOCKED' : '🔒 Testing: Normal Progression'}</span>
          </button>

          {/* Global Stars Count */}
          <div className="flex items-center gap-2 bg-slate-900/80 border border-slate-800 rounded-xl px-3.5 py-1.5">
            <span className="text-amber-400 text-base">⭐</span>
            <span className="text-sm font-display font-bold text-slate-100 tabular-nums">
              {totalStars} / 60
            </span>
          </div>
        </div>
      </div>

      {/* 20 Missions Grid */}
      <div className="w-full max-w-6xl mx-auto grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 my-4 py-2">
        {MISSIONS.map((mission) => {
          const isUnlocked = isUnlockAll || mission.id <= profile.unlockedLevel;
          const scoreRecord = profile.levelScores[mission.id];
          const starsEarned = scoreRecord ? scoreRecord.stars : 0;
          const bestScore = scoreRecord ? scoreRecord.score : null;

          // Special Mechanic Badges
          const hasDecoys = mission.gates.some((g) => g.isDecoy);
          const isTimed = mission.gates.some((g) => g.isTimed);
          const hasQuestion = mission.gates.some((g) => g.isQuestionGate);
          const isMoving = mission.gates.some((g) => g.isMoving);
          const hasStorm = mission.hasStorm;
          const isBlackout = mission.isBlackout;
          const hasChaser = mission.hasChaser;

          return (
            <div
              key={mission.id}
              onClick={() => {
                if (isUnlocked) {
                  sound.playButtonClick();
                  onSelectMission(mission.id);
                }
              }}
              className={`rounded-2xl border p-3.5 flex flex-col justify-between transition-all ${
                isUnlocked
                  ? 'bg-slate-900/85 hover:bg-slate-850 border-slate-700/80 hover:border-cyan-500/60 cursor-pointer shadow-lg hover:shadow-[0_0_20px_rgba(6,182,212,0.25)] active:scale-[0.98]'
                  : 'bg-slate-950/60 border-slate-800/40 opacity-50 cursor-not-allowed'
              }`}
            >
              <div>
                {/* District Tag & Stars */}
                <div className="flex items-center justify-between mb-1.5">
                  <span className="px-2 py-0.5 text-[10px] font-display font-black bg-cyan-950/80 border border-cyan-500/40 text-cyan-400 rounded">
                    M{mission.id.toString().padStart(2, '0')}
                  </span>

                  {isUnlocked ? (
                    <div className="flex items-center gap-0.5">
                      {[1, 2, 3].map((s) => (
                        <span
                          key={s}
                          className={`text-xs ${
                            s <= starsEarned ? 'text-amber-400 drop-shadow' : 'text-slate-700'
                          }`}
                        >
                          ★
                        </span>
                      ))}
                    </div>
                  ) : (
                    <span className="text-[10px] font-tech text-slate-500">
                      🔒 LOCKED
                    </span>
                  )}
                </div>

                {/* Mission Name & Sector */}
                <h3 className="text-sm font-display font-bold text-slate-100 truncate">
                  {mission.name}
                </h3>
                <span className="text-[11px] font-tech text-cyan-400 block truncate mt-0.5">
                  {mission.sector}
                </span>

                {/* Mechanic Badges */}
                <div className="flex flex-wrap gap-1 mt-2">
                  <span className="text-[9px] font-tech px-1.5 py-0.5 rounded bg-slate-800/80 text-slate-300">
                    {mission.gates.filter((g) => !g.isDecoy).length} Gates
                  </span>
                  {hasDecoys && (
                    <span className="text-[9px] font-tech px-1.5 py-0.5 rounded bg-rose-950/80 border border-rose-500/40 text-rose-300">
                      Decoys
                    </span>
                  )}
                  {isTimed && (
                    <span className="text-[9px] font-tech px-1.5 py-0.5 rounded bg-amber-950/80 border border-amber-500/40 text-amber-300">
                      Timed
                    </span>
                  )}
                  {hasQuestion && (
                    <span className="text-[9px] font-tech px-1.5 py-0.5 rounded bg-purple-950/80 border border-purple-500/40 text-purple-300">
                      Question
                    </span>
                  )}
                  {isMoving && (
                    <span className="text-[9px] font-tech px-1.5 py-0.5 rounded bg-blue-950/80 border border-blue-500/40 text-blue-300">
                      Moving
                    </span>
                  )}
                  {hasStorm && (
                    <span className="text-[9px] font-tech px-1.5 py-0.5 rounded bg-cyan-950/80 border border-cyan-500/40 text-cyan-300">
                      Storm
                    </span>
                  )}
                  {isBlackout && (
                    <span className="text-[9px] font-tech px-1.5 py-0.5 rounded bg-red-950/80 border border-red-500/40 text-red-300">
                      Blackout
                    </span>
                  )}
                  {hasChaser && (
                    <span className="text-[9px] font-tech px-1.5 py-0.5 rounded bg-orange-950/80 border border-orange-500/40 text-orange-300">
                      Chaser
                    </span>
                  )}
                </div>
              </div>

              {/* Best Score or Unlock Requirement */}
              <div className="mt-3 pt-2 border-t border-slate-800/80 flex items-center justify-between text-[11px] font-tech">
                {isUnlocked ? (
                  <>
                    <span className="text-slate-400">Best:</span>
                    <span className="font-display font-bold text-cyan-400 tabular-nums">
                      {bestScore ? bestScore.toLocaleString() : '---'}
                    </span>
                  </>
                ) : (
                  <span className="text-slate-500 text-[10px]">
                    Requires M{mission.id - 1} clearance
                  </span>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Footer hint */}
      <div className="w-full max-w-6xl mx-auto flex flex-col sm:flex-row items-center justify-between text-xs font-tech text-slate-500 pt-2 border-t border-slate-800/60">
        <span>Restoring all 20 towers unlocks the legendary Signal Master cosmetic frame.</span>
        <span className="text-cyan-500/80">Use the testing toggle above to jump to any mission anytime.</span>
      </div>
    </div>
  );
};

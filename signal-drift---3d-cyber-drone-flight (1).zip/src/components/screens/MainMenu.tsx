import React from 'react';
import { UserProfile } from '../../types/game';
import { getRankTitle, getXPProgressInLevel, HANGAR_SKINS } from '../../utils/storage';
import { sound } from '../../audio/soundEngine';

interface MainMenuProps {
  profile: UserProfile;
  onPlayCampaign: () => void;
  onOpenLevelSelect: () => void;
  onOpenHowToPlay: () => void;
  onOpenAchievements: () => void;
  onOpenSettings: () => void;
  onOpenPilotSelect: () => void;
  onOpenHangar: () => void;
}

export const MainMenu: React.FC<MainMenuProps> = ({
  profile,
  onPlayCampaign,
  onOpenLevelSelect,
  onOpenHowToPlay,
  onOpenAchievements,
  onOpenSettings,
  onOpenPilotSelect,
  onOpenHangar,
}) => {
  const rank = getRankTitle(profile.level);
  const xpProg = getXPProgressInLevel(profile.xp);
  const equippedSkinObj = HANGAR_SKINS.find((s) => s.id === profile.cosmetics?.equippedSkin) || HANGAR_SKINS[0];

  return (
    <div className="absolute inset-0 pointer-events-none z-30 flex flex-col justify-between items-center p-4 sm:p-8 select-none">
      {/* Top Pilot Profile Ribbon */}
      <div className="pointer-events-auto flex flex-col sm:flex-row items-center justify-between w-full max-w-5xl bg-slate-950/85 backdrop-blur-md border border-slate-800/90 rounded-2xl px-4 py-3 sm:px-6 sm:py-3.5 shadow-2xl gap-3">
        {/* Pilot Info Lockup */}
        <div className="flex items-center gap-3.5 w-full sm:w-auto justify-between sm:justify-start">
          <div className="flex items-center gap-3">
            <div className="relative">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-slate-900 to-slate-800 border border-cyan-500/50 flex items-center justify-center text-2xl shadow-[0_0_15px_rgba(6,182,212,0.3)]">
                {profile.avatar || '⚡'}
              </div>
              <div className="absolute -bottom-1 -right-1 px-1.5 py-0.2 rounded-full bg-cyan-500 text-[10px] font-display font-black text-slate-950">
                Lv.{profile.level}
              </div>
            </div>

            <div className="flex flex-col">
              <div className="flex items-center gap-2">
                <span className="text-base font-display font-black text-slate-100 tracking-wide">
                  {profile.nickname}
                </span>
                <span className="text-[10px] font-tech uppercase text-cyan-400 font-bold px-2 py-0.5 rounded bg-cyan-950/60 border border-cyan-500/30">
                  {rank}
                </span>
              </div>
              <div className="flex items-center gap-2 text-xs font-tech text-slate-400 mt-0.5">
                <span>XP: {xpProg.current} / {xpProg.max}</span>
                <span className="text-slate-600">·</span>
                <span className="text-cyan-300 font-semibold">{equippedSkinObj.name}</span>
              </div>
            </div>
          </div>

          <button
            onClick={() => {
              sound.playButtonClick();
              onOpenPilotSelect();
            }}
            className="px-2.5 py-1.5 rounded-xl bg-slate-900/90 hover:bg-slate-850 border border-slate-700/80 hover:border-cyan-500/60 text-[11px] font-tech font-bold text-slate-300 hover:text-cyan-300 transition-colors flex items-center gap-1 sm:hidden"
            title="Switch Pilot Profile"
          >
            <span>🔄 Switch</span>
          </button>
        </div>

        {/* Action Pills & Economy Ribbon */}
        <div className="flex items-center gap-2.5 sm:gap-3 w-full sm:w-auto justify-between sm:justify-end">
          {/* Signal Credits Display */}
          <div className="flex items-center gap-2 px-3.5 py-1.5 rounded-xl bg-slate-900/90 border border-amber-500/40 shadow-inner">
            <span className="text-amber-400 text-sm">💠</span>
            <div className="flex flex-col">
              <span className="text-[9px] font-tech text-slate-400 uppercase tracking-widest leading-none">
                Credits
              </span>
              <span className="text-sm font-display font-black text-amber-300 tabular-nums leading-tight">
                {profile.credits.toLocaleString()}
              </span>
            </div>
          </div>

          {/* Hangar Button */}
          <button
            onClick={() => {
              sound.playButtonClick();
              onOpenHangar();
            }}
            className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-cyan-950 to-blue-950 hover:from-cyan-900 hover:to-blue-900 border border-cyan-500/50 hover:border-cyan-400 text-xs font-display font-bold text-cyan-200 tracking-wider transition-all shadow-[0_0_15px_rgba(6,182,212,0.2)] flex items-center gap-1.5 active:scale-95"
            title="Open Drone Hangar"
          >
            <span>🛸</span>
            <span>HANGAR</span>
          </button>

          {/* Switch Pilot Button (Desktop) */}
          <button
            onClick={() => {
              sound.playButtonClick();
              onOpenPilotSelect();
            }}
            className="hidden sm:flex px-3 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 hover:border-cyan-500/60 text-xs font-tech font-bold text-slate-300 hover:text-cyan-300 transition-colors items-center gap-1.5"
            title="Switch Active Pilot"
          >
            <span>👤</span>
            <span>Switch</span>
          </button>

          {/* Settings Button */}
          <button
            onClick={() => {
              sound.playButtonClick();
              onOpenSettings();
            }}
            className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 hover:border-cyan-500/50 text-slate-300 hover:text-cyan-400 transition-colors"
            title="Settings"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
            </svg>
          </button>
        </div>
      </div>

      {/* Center Hero Title Lockup */}
      <div className="flex flex-col items-center text-center my-auto">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-12 h-[2px] bg-gradient-to-r from-transparent via-cyan-400 to-cyan-500" />
          <span className="text-xs sm:text-sm font-tech font-bold text-cyan-400 tracking-[0.35em] uppercase">
            3D Cyber Drone Flight
          </span>
          <div className="w-12 h-[2px] bg-gradient-to-l from-transparent via-cyan-400 to-cyan-500" />
        </div>

        <h1 className="text-5xl sm:text-7xl md:text-8xl font-display font-black tracking-tight text-transparent bg-clip-text bg-gradient-to-b from-white via-cyan-100 to-cyan-500 drop-shadow-[0_10px_25px_rgba(6,182,212,0.4)]">
          SIGNAL DRIFT
        </h1>

        <p className="max-w-lg mt-3 text-sm sm:text-base font-tech text-slate-300 font-semibold tracking-wide drop-shadow px-2">
          A global blackout severed the skyway grid. Fly the remembered gate sequences, harvest energy, and restore the metropolis Signal Towers.
        </p>

        {/* Action Buttons */}
        <div className="pointer-events-auto flex flex-col sm:flex-row items-center gap-3.5 mt-8 w-full max-w-md">
          {/* Main Launch Button */}
          <button
            onClick={() => {
              sound.playButtonClick();
              onPlayCampaign();
            }}
            className="w-full sm:flex-1 py-4 px-6 rounded-2xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 active:scale-95 text-slate-950 font-display font-black text-lg tracking-wider shadow-[0_0_25px_rgba(6,182,212,0.5)] transition-all flex items-center justify-center gap-2"
          >
            <span>LAUNCH MISSION {profile.unlockedLevel}</span>
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M14 5l7 7m0 0l-7 7m7-7H3" />
            </svg>
          </button>

          {/* Missions Menu Button */}
          <button
            onClick={() => {
              sound.playButtonClick();
              onOpenLevelSelect();
            }}
            className="w-full sm:w-auto py-4 px-6 rounded-2xl bg-slate-950/85 hover:bg-slate-900 border border-slate-700 hover:border-cyan-500/60 active:scale-95 text-slate-200 font-display font-bold text-sm tracking-wider shadow-xl transition-all"
          >
            MISSION LOG (20)
          </button>
        </div>

        {/* Secondary Navigation Row */}
        <div className="pointer-events-auto flex items-center gap-3 mt-4">
          <button
            onClick={() => {
              sound.playButtonClick();
              onOpenHowToPlay();
            }}
            className="px-4 py-2 rounded-xl bg-slate-900/80 hover:bg-slate-800 border border-slate-800 hover:border-slate-600 text-xs font-tech font-semibold text-slate-300 hover:text-cyan-300 transition-colors"
          >
            📖 Flight Academy
          </button>
          <button
            onClick={() => {
              sound.playButtonClick();
              onOpenAchievements();
            }}
            className="px-4 py-2 rounded-xl bg-slate-900/80 hover:bg-slate-800 border border-slate-800 hover:border-slate-600 text-xs font-tech font-semibold text-slate-300 hover:text-amber-300 transition-colors"
          >
            🏆 Achievements ({profile.achievements.length}/9)
          </button>
        </div>
      </div>

      {/* Bottom Flat Control Hint Line */}
      <div className="flex flex-wrap items-center justify-center gap-2 text-xs font-tech text-slate-400 bg-slate-950/70 border border-slate-800/80 rounded-full px-4 py-1.5 shadow-lg max-w-2xl text-center">
        <span className="text-cyan-400">WASD / Arrows</span> Move & Steer ·{' '}
        <span className="text-cyan-400">Space</span> Lift ·{' '}
        <span className="text-cyan-400">S / Down</span> Descend ·{' '}
        <span className="text-cyan-400">Shift</span> Boost (6s) ·{' '}
        <span className="text-cyan-400">Esc</span> Pause
      </div>
    </div>
  );
};

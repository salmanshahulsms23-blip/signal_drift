import React from 'react';
import { GameSettings, MissionData, UserProfile } from '../../types/game';
import { sound } from '../../audio/soundEngine';

interface PauseMenuProps {
  mission: MissionData;
  settings: GameSettings;
  profile: UserProfile;
  onResume: () => void;
  onRestart: () => void;
  onOpenLevelSelect: () => void;
  onSwitchPilot: () => void;
  onUpdateSettings: (settings: GameSettings) => void;
}

export const PauseMenu: React.FC<PauseMenuProps> = ({
  mission,
  settings,
  profile,
  onResume,
  onRestart,
  onOpenLevelSelect,
  onSwitchPilot,
  onUpdateSettings,
}) => {
  const toggleSound = () => {
    const updated = { ...settings, sound: !settings.sound };
    onUpdateSettings(updated);
    sound.updateSettings(updated.sound, updated.soundVolume, updated.music, updated.musicVolume);
    sound.playButtonClick();
  };

  const toggleMusic = () => {
    const updated = { ...settings, music: !settings.music };
    onUpdateSettings(updated);
    sound.updateSettings(updated.sound, updated.soundVolume, updated.music, updated.musicVolume);
    sound.playButtonClick();
  };

  return (
    <div className="absolute inset-0 z-40 flex items-center justify-center p-4 select-none bg-slate-950/80 backdrop-blur-sm">
      <div className="w-full max-w-sm bg-slate-950/95 border border-cyan-500/40 rounded-3xl p-6 sm:p-7 shadow-[0_0_40px_rgba(6,182,212,0.25)] flex flex-col items-center text-center">
        <span className="text-xs font-tech font-bold text-cyan-400 tracking-[0.3em] uppercase">
          FLIGHT SUSPENDED
        </span>
        <h2 className="text-3xl font-display font-black text-slate-100 mt-1">
          PAUSED
        </h2>
        <span className="text-xs font-tech text-slate-400 uppercase tracking-widest mt-0.5">
          M{mission.id.toString().padStart(2, '0')} · {mission.name}
        </span>

        {/* Active Pilot Indicator */}
        <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-900/80 border border-slate-800 my-3 text-xs font-tech">
          <span className="text-sm">{profile.avatar}</span>
          <span className="text-slate-200 font-bold">{profile.nickname}</span>
          <span className="text-cyan-400">Lv.{profile.level}</span>
        </div>

        {/* Quick Audio Toggles */}
        <div className="flex items-center gap-2.5 my-2 w-full">
          <button
            onClick={toggleSound}
            className={`flex-1 py-2 px-3 rounded-xl border text-xs font-tech font-bold flex items-center justify-center gap-1.5 transition-colors ${
              settings.sound
                ? 'bg-cyan-950/80 border-cyan-500/50 text-cyan-300'
                : 'bg-slate-900 border-slate-800 text-slate-500'
            }`}
          >
            <span>{settings.sound ? '🔊 SFX: ON' : '🔈 SFX: OFF'}</span>
          </button>
          <button
            onClick={toggleMusic}
            className={`flex-1 py-2 px-3 rounded-xl border text-xs font-tech font-bold flex items-center justify-center gap-1.5 transition-colors ${
              settings.music
                ? 'bg-cyan-950/80 border-cyan-500/50 text-cyan-300'
                : 'bg-slate-900 border-slate-800 text-slate-500'
            }`}
          >
            <span>{settings.music ? '🎵 BGM: ON' : '🔇 BGM: OFF'}</span>
          </button>
        </div>

        {/* Navigation Buttons */}
        <div className="flex flex-col gap-2.5 w-full mt-3">
          <button
            onClick={() => {
              sound.playButtonClick();
              onResume();
            }}
            className="w-full py-3.5 px-6 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 active:scale-95 text-slate-950 font-display font-bold text-sm tracking-wider shadow-[0_0_20px_rgba(6,182,212,0.4)] transition-all"
          >
            RESUME FLIGHT
          </button>

          <button
            onClick={() => {
              sound.playButtonClick();
              onRestart();
            }}
            className="w-full py-3 px-6 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 hover:border-slate-500 active:scale-95 text-slate-200 font-display font-bold text-xs tracking-wider transition-all"
          >
            RESTART MISSION
          </button>

          <button
            onClick={() => {
              sound.playButtonClick();
              onOpenLevelSelect();
            }}
            className="w-full py-3 px-6 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 hover:border-slate-500 active:scale-95 text-slate-300 font-display font-bold text-xs tracking-wider transition-all"
          >
            MISSION LOG
          </button>

          <button
            onClick={() => {
              sound.playButtonClick();
              onSwitchPilot();
            }}
            className="w-full py-2.5 px-6 rounded-xl bg-slate-900/60 hover:bg-slate-800 border border-slate-800 hover:border-cyan-500/50 text-cyan-400 font-tech font-bold text-xs tracking-wider transition-all"
          >
            🔄 SWITCH PILOT PROFILE
          </button>
        </div>
      </div>
    </div>
  );
};

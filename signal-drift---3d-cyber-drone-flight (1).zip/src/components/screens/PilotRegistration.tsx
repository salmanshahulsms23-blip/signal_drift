import React, { useState } from 'react';
import { AVATARS, STARTER_COLORS } from '../../utils/storage';
import { sound } from '../../audio/soundEngine';

interface PilotRegistrationProps {
  onComplete: (nickname: string, avatar: string, starterColor: string) => void;
  onCancel?: () => void;
  allowCancel?: boolean;
}

export const PilotRegistration: React.FC<PilotRegistrationProps> = ({
  onComplete,
  onCancel,
  allowCancel = false,
}) => {
  const [nickname, setNickname] = useState('');
  const [selectedAvatar, setSelectedAvatar] = useState(AVATARS[0].icon);
  const [selectedColor, setSelectedColor] = useState(STARTER_COLORS[0].id);
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanNick = nickname.trim();
    if (cleanNick.length < 3) {
      setError('Nickname must be at least 3 characters.');
      sound.playWrongGate();
      return;
    }
    if (cleanNick.length > 16) {
      setError('Nickname must be 16 characters or fewer.');
      sound.playWrongGate();
      return;
    }

    sound.playButtonClick();
    onComplete(cleanNick, selectedAvatar, selectedColor);
  };

  return (
    <div className="absolute inset-0 z-50 flex items-center justify-center p-4 select-none bg-slate-950/90 overflow-y-auto">
      <div className="w-full max-w-xl bg-slate-950/95 border border-cyan-500/40 rounded-3xl p-6 sm:p-8 shadow-[0_0_50px_rgba(6,182,212,0.3)] flex flex-col my-auto max-h-[95vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex flex-col">
            <span className="text-xs font-tech font-bold text-cyan-400 tracking-[0.3em] uppercase">
              METROPOLIS FLIGHT CORPS
            </span>
            <h2 className="text-2xl sm:text-3xl font-display font-black text-slate-100 mt-0.5">
              PILOT REGISTRATION
            </h2>
          </div>
          {allowCancel && onCancel && (
            <button
              onClick={() => {
                sound.playButtonClick();
                onCancel();
              }}
              className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-slate-100 transition-colors"
            >
              ✕
            </button>
          )}
        </div>

        <form onSubmit={handleSubmit} className="flex flex-col gap-5 py-4">
          {/* Nickname input */}
          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-tech uppercase text-slate-300 font-bold tracking-wider">
              Pilot Nickname (3–16 Characters) <span className="text-cyan-400">*</span>
            </label>
            <input
              type="text"
              value={nickname}
              onChange={(e) => {
                setNickname(e.target.value);
                if (error) setError('');
              }}
              placeholder="e.g. AeroGhost, Valkyrie9"
              maxLength={16}
              className="w-full py-3 px-4 bg-slate-900/90 border border-slate-700 focus:border-cyan-400 focus:outline-none rounded-xl text-slate-100 font-display font-bold text-sm tracking-wide shadow-inner"
              autoFocus
            />
            {error && (
              <span className="text-xs font-tech text-rose-400 font-semibold">{error}</span>
            )}
          </div>

          {/* 12 Futuristic Avatars */}
          <div className="flex flex-col gap-2">
            <label className="text-xs font-tech uppercase text-slate-300 font-bold tracking-wider">
              Select Avatar Insignia
            </label>
            <div className="grid grid-cols-4 sm:grid-cols-6 gap-2.5">
              {AVATARS.map((av) => (
                <button
                  type="button"
                  key={av.id}
                  onClick={() => {
                    sound.playButtonClick();
                    setSelectedAvatar(av.icon);
                  }}
                  className={`py-3 px-2 rounded-2xl border flex flex-col items-center justify-center gap-1 transition-all ${
                    selectedAvatar === av.icon
                      ? 'bg-cyan-950/80 border-cyan-400 shadow-[0_0_15px_rgba(6,182,212,0.4)] scale-105'
                      : 'bg-slate-900/70 border-slate-800 hover:border-slate-600 text-slate-400'
                  }`}
                >
                  <span className="text-2xl">{av.icon}</span>
                  <span className="text-[10px] font-tech text-slate-300 truncate w-full text-center">
                    {av.label.split(' ')[0]}
                  </span>
                </button>
              ))}
            </div>
          </div>

          {/* Starter Drone Color Choice */}
          <div className="flex flex-col gap-2">
            <label className="text-xs font-tech uppercase text-slate-300 font-bold tracking-wider">
              Starter Drone Core Finish
            </label>
            <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
              {STARTER_COLORS.map((col) => (
                <button
                  type="button"
                  key={col.id}
                  onClick={() => {
                    sound.playButtonClick();
                    setSelectedColor(col.id);
                  }}
                  className={`py-2 px-3 rounded-xl border flex items-center justify-center gap-2 transition-all ${
                    selectedColor === col.id
                      ? 'bg-slate-850 border-cyan-400 shadow-md scale-102'
                      : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <span
                    className="w-3.5 h-3.5 rounded-full shadow"
                    style={{ backgroundColor: col.hex }}
                  />
                  <span className="text-xs font-tech font-bold text-slate-200">{col.label.split(' ')[0]}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Required Privacy Notice */}
          <div className="p-3 rounded-xl bg-slate-900/50 border border-slate-800/80 text-[11px] font-tech text-slate-400 flex items-center gap-2">
            <span className="text-cyan-400 text-base">🔒</span>
            <span>Your game progress is saved only in this browser on this device.</span>
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            className="w-full py-4 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 active:scale-95 text-slate-950 font-display font-black text-sm tracking-wider shadow-[0_0_20px_rgba(6,182,212,0.4)] transition-all flex items-center justify-center gap-2 mt-2"
          >
            <span>COMMISSION PILOT PROFILE</span>
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M14 5l7 7m0 0l-7 7m7-7H3" />
            </svg>
          </button>
        </form>
      </div>
    </div>
  );
};

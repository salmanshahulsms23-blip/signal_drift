import React, { useState } from 'react';
import { ProfileMeta } from '../../types/game';
import { sound } from '../../audio/soundEngine';

interface PilotSelectProps {
  profiles: ProfileMeta[];
  activeProfileId: string | null;
  onSelectProfile: (id: string) => void;
  onCreateNewPilot: () => void;
  onEditNickname: (id: string, newNickname: string) => void;
  onDeleteProfile: (id: string) => void;
  onClose: () => void;
}

export const PilotSelect: React.FC<PilotSelectProps> = ({
  profiles,
  activeProfileId,
  onSelectProfile,
  onCreateNewPilot,
  onEditNickname,
  onDeleteProfile,
  onClose,
}) => {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editNick, setEditNick] = useState<string>('');
  const [deletingId, setDeletingId] = useState<string | null>(null);

  const startEdit = (p: ProfileMeta) => {
    setEditingId(p.id);
    setEditNick(p.nickname);
  };

  const saveEdit = (id: string) => {
    const clean = editNick.trim();
    if (clean.length >= 3 && clean.length <= 16) {
      onEditNickname(id, clean);
      sound.playButtonClick();
      setEditingId(null);
    } else {
      sound.playWrongGate();
    }
  };

  const confirmDelete = (id: string) => {
    sound.playCollision();
    onDeleteProfile(id);
    setDeletingId(null);
  };

  return (
    <div className="absolute inset-0 z-50 flex items-center justify-center p-4 select-none bg-slate-950/90 overflow-y-auto">
      <div className="w-full max-w-2xl bg-slate-950/95 border border-cyan-500/40 rounded-3xl p-6 sm:p-8 shadow-[0_0_50px_rgba(6,182,212,0.3)] flex flex-col my-auto max-h-[92vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex flex-col">
            <span className="text-xs font-tech font-bold text-cyan-400 tracking-[0.3em] uppercase">
              LOCAL MULTI-PROFILE STORAGE
            </span>
            <h2 className="text-2xl sm:text-3xl font-display font-black text-slate-100 mt-0.5">
              SELECT PILOT
            </h2>
          </div>
          <button
            onClick={() => {
              sound.playButtonClick();
              onClose();
            }}
            className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-slate-100 transition-colors"
          >
            ✕
          </button>
        </div>

        {/* Profile Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 py-4 overflow-y-auto pr-1">
          {profiles.map((p) => {
            const isActive = p.id === activeProfileId;
            const isEditing = editingId === p.id;

            return (
              <div
                key={p.id}
                className={`p-4 rounded-2xl border transition-all flex flex-col justify-between ${
                  isActive
                    ? 'bg-slate-900/90 border-cyan-500 shadow-[0_0_20px_rgba(6,182,212,0.25)]'
                    : 'bg-slate-950/70 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div>
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-xl bg-slate-800 border border-slate-700 flex items-center justify-center text-2xl shadow">
                        {p.avatar}
                      </div>

                      <div className="flex flex-col">
                        {isEditing ? (
                          <div className="flex items-center gap-1.5">
                            <input
                              type="text"
                              value={editNick}
                              onChange={(e) => setEditNick(e.target.value)}
                              maxLength={16}
                              className="w-28 py-0.5 px-2 bg-slate-950 border border-cyan-400 rounded text-xs text-white font-display font-bold"
                              autoFocus
                            />
                            <button
                              onClick={() => saveEdit(p.id)}
                              className="text-xs text-cyan-400 hover:text-cyan-200"
                            >
                              ✓
                            </button>
                            <button
                              onClick={() => setEditingId(null)}
                              className="text-xs text-slate-400 hover:text-slate-200"
                            >
                              ✕
                            </button>
                          </div>
                        ) : (
                          <div className="flex items-center gap-1.5">
                            <span className="font-display font-bold text-slate-100 text-base">
                              {p.nickname}
                            </span>
                            <button
                              onClick={() => startEdit(p)}
                              className="text-slate-500 hover:text-cyan-400 text-xs"
                              title="Edit Nickname"
                            >
                              ✏️
                            </button>
                          </div>
                        )}
                        <span className="text-xs font-tech text-cyan-400 font-bold">
                          Level {p.level || 1} Pilot
                        </span>
                      </div>
                    </div>

                    {isActive && (
                      <span className="text-[10px] font-tech font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-500/50">
                        ACTIVE
                      </span>
                    )}
                  </div>

                  {/* Profile Stats Overview */}
                  <div className="grid grid-cols-2 gap-2 mt-3 pt-2.5 border-t border-slate-800/80 text-xs font-tech">
                    <div>
                      <span className="text-slate-500 block text-[10px] uppercase">Sector Cleared</span>
                      <span className="text-slate-200 font-display font-bold">
                        District {p.unlockedLevel || 1} / 20
                      </span>
                    </div>
                    <div>
                      <span className="text-slate-500 block text-[10px] uppercase">Signal Credits</span>
                      <span className="text-amber-400 font-display font-bold">
                        {(p.credits || 0).toLocaleString()} ⚡
                      </span>
                    </div>
                  </div>
                </div>

                {/* Card Action Buttons */}
                <div className="flex items-center gap-2 mt-4 pt-2.5 border-t border-slate-800/80">
                  <button
                    onClick={() => {
                      sound.playButtonClick();
                      onSelectProfile(p.id);
                    }}
                    className={`flex-1 py-2 px-3 rounded-xl font-display font-bold text-xs tracking-wider transition-all ${
                      isActive
                        ? 'bg-slate-800 text-cyan-300 border border-cyan-500/50'
                        : 'bg-cyan-500 hover:bg-cyan-400 text-slate-950 shadow-md'
                    }`}
                  >
                    {isActive ? 'PLAYING AS PILOT' : 'SWITCH & PLAY'}
                  </button>

                  <button
                    onClick={() => setDeletingId(p.id)}
                    className="p-2 rounded-xl bg-slate-900 hover:bg-rose-950/60 border border-slate-800 hover:border-rose-500/60 text-slate-500 hover:text-rose-400 transition-colors"
                    title="Delete Pilot Profile"
                  >
                    🗑️
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Footer Actions */}
        <div className="flex items-center justify-between pt-3 border-t border-slate-800 mt-2">
          <button
            onClick={() => {
              sound.playButtonClick();
              onCreateNewPilot();
            }}
            className="py-3 px-5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-display font-bold text-xs tracking-wider shadow-lg flex items-center gap-2 transition-all active:scale-95"
          >
            <span>+ CREATE NEW PILOT</span>
          </button>

          <span className="text-xs font-tech text-slate-500">
            {profiles.length} Profiles Registered
          </span>
        </div>

        {/* Delete Confirmation Modal */}
        {deletingId && (
          <div className="absolute inset-0 z-50 bg-slate-950/85 flex items-center justify-center p-4 rounded-3xl">
            <div className="bg-slate-900 border border-rose-500/60 rounded-2xl p-5 max-w-sm w-full flex flex-col items-center text-center shadow-2xl">
              <span className="text-3xl mb-2">⚠️</span>
              <h4 className="text-base font-display font-bold text-slate-100">
                DELETE PILOT PROFILE?
              </h4>
              <p className="text-xs font-tech text-slate-300 mt-2">
                This will permanently remove this pilot's progress, unlocked sectors, credits, and hangar upgrades. Other pilot profiles will remain safe.
              </p>
              <div className="flex items-center gap-2 w-full mt-4">
                <button
                  onClick={() => confirmDelete(deletingId)}
                  className="flex-1 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-display font-bold text-xs shadow"
                >
                  CONFIRM DELETE
                </button>
                <button
                  onClick={() => setDeletingId(null)}
                  className="flex-1 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-tech font-bold text-xs"
                >
                  CANCEL
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

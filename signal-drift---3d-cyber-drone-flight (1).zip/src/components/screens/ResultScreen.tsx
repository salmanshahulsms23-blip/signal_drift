import React, { useEffect, useState } from 'react';
import confetti from 'canvas-confetti';
import { MissionData, MissionResult, UserProfile } from '../../types/game';
import { getRankTitle, getXPProgressInLevel } from '../../utils/storage';
import { sound } from '../../audio/soundEngine';

interface ResultScreenProps {
  result: MissionResult;
  mission: MissionData;
  profile: UserProfile;
  onNextMission: () => void;
  onRetryMission: () => void;
  onOpenLevelSelect: () => void;
  onOpenHangar: () => void;
}

export const ResultScreen: React.FC<ResultScreenProps> = ({
  result,
  mission,
  profile,
  onNextMission,
  onRetryMission,
  onOpenLevelSelect,
  onOpenHangar,
}) => {
  const [revealedStars, setRevealedStars] = useState<number>(0);
  const [xpDisplay, setXpDisplay] = useState<number>(0);
  const [creditsDisplay, setCreditsDisplay] = useState<number>(0);

  useEffect(() => {
    // Star sequence reveal
    const t1 = setTimeout(() => {
      setRevealedStars(1);
      sound.playButtonClick();
    }, 400);

    const t2 = setTimeout(() => {
      if (result.stars >= 2) {
        setRevealedStars(2);
        sound.playButtonClick();
      }
    }, 900);

    const t3 = setTimeout(() => {
      if (result.stars >= 3) {
        setRevealedStars(3);
        sound.playButtonClick();
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 },
          colors: ['#00f0ff', '#ff00aa', '#f59e0b'],
        });
      }
    }, 1400);

    // XP count-up animation
    let currentXp = 0;
    const targetXp = result.xpEarned;
    const xpStep = Math.max(10, Math.floor(targetXp / 30));
    const xpTimer = setInterval(() => {
      currentXp = Math.min(targetXp, currentXp + xpStep);
      setXpDisplay(currentXp);
      if (currentXp >= targetXp) {
        clearInterval(xpTimer);
      }
    }, 30);

    // Credits count-up animation
    let currentCred = 0;
    const targetCred = result.creditsEarned || 150;
    const credStep = Math.max(5, Math.floor(targetCred / 25));
    const credTimer = setInterval(() => {
      currentCred = Math.min(targetCred, currentCred + credStep);
      setCreditsDisplay(currentCred);
      if (currentCred >= targetCred) {
        clearInterval(credTimer);
      }
    }, 30);

    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
      clearTimeout(t3);
      clearInterval(xpTimer);
      clearInterval(credTimer);
    };
  }, [result]);

  const xpProgress = getXPProgressInLevel(profile.xp);
  const rank = getRankTitle(profile.level);
  const hasNextLevel = mission.id < 20;
  const isFinalMissionCleared = mission.id === 20;

  return (
    <div className="absolute inset-0 z-30 flex items-center justify-center p-4 select-none bg-slate-950/75 backdrop-blur-sm overflow-y-auto">
      <div className="w-full max-w-xl bg-slate-950/95 border border-cyan-500/40 rounded-3xl p-6 sm:p-8 shadow-[0_0_50px_rgba(6,182,212,0.25)] flex flex-col items-center text-center my-auto">
        {/* Victory Header */}
        <span className="text-xs font-tech font-bold text-cyan-400 tracking-[0.3em] uppercase">
          {isFinalMissionCleared ? 'METROPOLIS GRID RESTORED' : 'SIGNAL TOWER RESTORED'}
        </span>
        <h2 className="text-3xl sm:text-4xl font-display font-black text-transparent bg-clip-text bg-gradient-to-r from-cyan-300 via-white to-blue-300 mt-1">
          {isFinalMissionCleared ? 'VICTORY: APEX DRIFTER' : 'MISSION COMPLETE'}
        </h2>
        <span className="text-xs font-tech text-slate-400 uppercase tracking-widest mt-0.5">
          M{mission.id.toString().padStart(2, '0')} · {mission.name}
        </span>

        {/* 3-Star Rating Display */}
        <div className="flex items-center gap-3 my-4">
          {[1, 2, 3].map((starNum) => {
            const isEarned = starNum <= result.stars;
            const isRevealed = starNum <= revealedStars;
            return (
              <div
                key={starNum}
                className={`transition-all duration-300 transform ${
                  isRevealed && isEarned
                    ? 'scale-110 text-amber-400 drop-shadow-[0_0_15px_rgba(251,191,36,0.8)]'
                    : 'scale-90 text-slate-700'
                }`}
              >
                <svg className="w-11 h-11 fill-current" viewBox="0 0 24 24">
                  <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" />
                </svg>
              </div>
            );
          })}
        </div>

        {/* Score & Key Stats Grid */}
        <div className="w-full grid grid-cols-2 sm:grid-cols-4 gap-2.5 my-2">
          {/* Total Score */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-2.5 flex flex-col">
            <span className="text-[10px] font-tech text-slate-400 uppercase tracking-wider">
              Score
            </span>
            <span className="text-lg font-display font-bold text-cyan-400 tabular-nums">
              {result.score.toLocaleString()}
            </span>
          </div>

          {/* Accuracy */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-2.5 flex flex-col">
            <span className="text-[10px] font-tech text-slate-400 uppercase tracking-wider">
              Accuracy
            </span>
            <span
              className={`text-lg font-display font-bold tabular-nums ${
                result.accuracy === 100 ? 'text-emerald-400' : 'text-slate-200'
              }`}
            >
              {result.accuracy}%
            </span>
          </div>

          {/* Battery */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-2.5 flex flex-col">
            <span className="text-[10px] font-tech text-slate-400 uppercase tracking-wider">
              Battery Left
            </span>
            <span className="text-lg font-display font-bold text-amber-400 tabular-nums">
              {result.batteryRemaining}%
            </span>
          </div>

          {/* Time */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-2.5 flex flex-col">
            <span className="text-[10px] font-tech text-slate-400 uppercase tracking-wider">
              Flight Time
            </span>
            <span className="text-lg font-display font-bold text-slate-200 tabular-nums">
              {result.timeElapsed}s
            </span>
          </div>
        </div>

        {/* Rewards Ribbon: XP & Signal Credits */}
        <div className="w-full grid grid-cols-1 sm:grid-cols-2 gap-2.5 my-2.5">
          {/* Signal Credits Reward */}
          <div className="bg-slate-900/80 border border-amber-500/40 rounded-2xl p-3 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <span className="text-2xl">💠</span>
              <div className="flex flex-col text-left">
                <span className="text-[10px] font-tech text-slate-400 uppercase tracking-wider">
                  Credits Rewarded
                </span>
                <span className="text-base font-display font-black text-amber-300 tabular-nums">
                  +{creditsDisplay} Credits
                </span>
              </div>
            </div>
            <button
              onClick={() => {
                sound.playButtonClick();
                onOpenHangar();
              }}
              className="px-2.5 py-1 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/50 text-[10px] font-tech font-bold text-amber-300"
            >
              Spend in Hangar →
            </button>
          </div>

          {/* Pilot XP Reward */}
          <div className="bg-slate-900/80 border border-cyan-500/40 rounded-2xl p-3 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <span className="text-2xl">⚡</span>
              <div className="flex flex-col text-left">
                <span className="text-[10px] font-tech text-slate-400 uppercase tracking-wider">
                  Pilot Experience
                </span>
                <span className="text-base font-display font-black text-cyan-300 tabular-nums">
                  +{xpDisplay} XP
                </span>
              </div>
            </div>
            <span className="text-[11px] font-tech text-cyan-400 font-bold">
              Lv.{profile.level} {rank}
            </span>
          </div>
        </div>

        {/* XP Progress Bar */}
        <div className="w-full bg-slate-900/60 border border-slate-800 rounded-xl p-2.5 mb-3 flex flex-col gap-1">
          <div className="h-1.5 w-full bg-slate-800 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-cyan-500 to-blue-500 rounded-full transition-all duration-300"
              style={{ width: `${Math.round(xpProgress.ratio * 100)}%` }}
            />
          </div>
          <div className="flex justify-between text-[10px] font-tech text-slate-400">
            <span>{profile.nickname}</span>
            <span>{xpProgress.current} / {xpProgress.max} XP to next level</span>
          </div>
        </div>

        {/* New Achievements Toast */}
        {result.newAchievements && result.newAchievements.length > 0 && (
          <div className="w-full bg-amber-500/10 border border-amber-500/40 rounded-xl p-2.5 mb-3 flex items-center justify-center gap-2">
            <span className="text-base">🏆</span>
            <span className="text-xs font-tech font-bold text-amber-300 uppercase tracking-wider">
              Achievement Unlocked: {result.newAchievements.join(', ')}
            </span>
          </div>
        )}

        {/* Navigation Action Buttons */}
        <div className="flex flex-col sm:flex-row items-center gap-3 w-full mt-2">
          {hasNextLevel ? (
            <button
              onClick={() => {
                sound.playButtonClick();
                onNextMission();
              }}
              className="w-full sm:flex-1 py-3.5 px-6 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 active:scale-95 text-slate-950 font-display font-bold text-sm tracking-wider shadow-[0_0_20px_rgba(6,182,212,0.4)] transition-all flex items-center justify-center gap-2"
            >
              <span>NEXT MISSION ({mission.id + 1})</span>
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M14 5l7 7m0 0l-7 7m7-7H3" />
              </svg>
            </button>
          ) : (
            <button
              onClick={() => {
                sound.playButtonClick();
                onOpenLevelSelect();
              }}
              className="w-full sm:flex-1 py-3.5 px-6 rounded-xl bg-gradient-to-r from-amber-500 to-orange-600 text-slate-950 font-display font-bold text-sm tracking-wider shadow-xl transition-all"
            >
              ALL 20 DISTRICTS RESTORED!
            </button>
          )}

          <button
            onClick={() => {
              sound.playButtonClick();
              onRetryMission();
            }}
            className="w-full sm:w-auto py-3.5 px-5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 hover:border-slate-500 active:scale-95 text-slate-200 font-display font-bold text-xs tracking-wider transition-all"
          >
            REPLAY
          </button>

          <button
            onClick={() => {
              sound.playButtonClick();
              onOpenLevelSelect();
            }}
            className="w-full sm:w-auto py-3.5 px-5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 hover:border-slate-500 active:scale-95 text-slate-300 font-display font-bold text-xs tracking-wider transition-all"
          >
            MISSION LOG
          </button>
        </div>
      </div>
    </div>
  );
};

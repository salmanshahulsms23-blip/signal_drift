import React, { useState } from 'react';
import { GameSettings } from '../../types/game';
import { sound } from '../../audio/soundEngine';

interface SettingsModalProps {
  settings: GameSettings;
  onSave: (settings: GameSettings) => void;
  onResetProgress: () => void;
  onClose: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  settings,
  onSave,
  onResetProgress,
  onClose,
}) => {
  const [current, setCurrent] = useState<GameSettings>({ ...settings });
  const [showResetConfirm, setShowResetConfirm] = useState(false);

  const updateField = <K extends keyof GameSettings>(key: K, value: GameSettings[K]) => {
    const next = { ...current, [key]: value };
    setCurrent(next);
    onSave(next);
    sound.updateSettings(next.sound, next.soundVolume, next.music, next.musicVolume);
  };

  return (
    <div className="absolute inset-0 z-50 flex items-center justify-center p-4 select-none bg-slate-950/80">
      <div className="w-full max-w-md bg-slate-950/95 border border-cyan-500/40 rounded-3xl p-6 sm:p-7 shadow-[0_0_40px_rgba(6,182,212,0.25)] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex flex-col">
            <h3 className="text-xl font-display font-black text-slate-100">
              FLIGHT SETTINGS
            </h3>
            <span className="text-xs font-tech text-cyan-400 uppercase tracking-widest">
              Audio, Visuals & Avionics
            </span>
          </div>
          <button
            onClick={() => {
              sound.playButtonClick();
              onClose();
            }}
            className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-slate-100 transition-colors"
          >
            ✕
          </button>
        </div>

        {/* Settings Body */}
        <div className="flex flex-col gap-4 py-4">
          {/* Sound FX Toggle */}
          <div className="flex items-center justify-between">
            <div className="flex flex-col">
              <span className="text-sm font-tech font-bold text-slate-200">
                Sound Effects (SFX)
              </span>
              <span className="text-xs font-tech text-slate-400">
                Engine hum, gate chimes, boost roar
              </span>
            </div>
            <button
              onClick={() => updateField('sound', !current.sound)}
              className={`w-13 h-7 rounded-full p-1 transition-colors ${
                current.sound ? 'bg-cyan-500' : 'bg-slate-800'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-slate-950 shadow-md transition-transform ${
                  current.sound ? 'translate-x-6' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          {/* Music Toggle */}
          <div className="flex items-center justify-between">
            <div className="flex flex-col">
              <span className="text-sm font-tech font-bold text-slate-200">
                Cyber Synth Soundtrack
              </span>
              <span className="text-xs font-tech text-slate-400">
                Procedural generative ambient electronic music
              </span>
            </div>
            <button
              onClick={() => updateField('music', !current.music)}
              className={`w-13 h-7 rounded-full p-1 transition-colors ${
                current.music ? 'bg-cyan-500' : 'bg-slate-800'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-slate-950 shadow-md transition-transform ${
                  current.music ? 'translate-x-6' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          {/* Graphics Quality */}
          <div className="flex flex-col gap-1.5">
            <span className="text-sm font-tech font-bold text-slate-200">
              Visual Rendering Quality
            </span>
            <div className="grid grid-cols-3 gap-2">
              {(['low', 'medium', 'high'] as const).map((q) => (
                <button
                  key={q}
                  onClick={() => updateField('graphics', q)}
                  className={`py-2 px-3 rounded-xl border text-xs font-display font-bold uppercase transition-all ${
                    current.graphics === q
                      ? 'bg-cyan-950 border-cyan-500 text-cyan-300 shadow-[0_0_12px_rgba(6,182,212,0.3)]'
                      : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {q}
                </button>
              ))}
            </div>
          </div>

          {/* Touch Controls Forced */}
          <div className="flex items-center justify-between">
            <div className="flex flex-col">
              <span className="text-sm font-tech font-bold text-slate-200">
                On-Screen Touch Controls
              </span>
              <span className="text-xs font-tech text-slate-400">
                Show virtual flight pedals and buttons
              </span>
            </div>
            <button
              onClick={() => updateField('touchControls', !current.touchControls)}
              className={`w-13 h-7 rounded-full p-1 transition-colors ${
                current.touchControls ? 'bg-cyan-500' : 'bg-slate-800'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-slate-950 shadow-md transition-transform ${
                  current.touchControls ? 'translate-x-6' : 'translate-x-0'
                }`}
              />
            </button>
          </div>
        </div>

        {/* Danger Zone: Reset Progress */}
        <div className="pt-4 border-t border-slate-800 flex flex-col gap-2">
          {!showResetConfirm ? (
            <button
              onClick={() => setShowResetConfirm(true)}
              className="py-2.5 px-4 rounded-xl bg-slate-900 hover:bg-rose-950/40 border border-slate-800 hover:border-rose-500/40 text-xs font-tech font-bold text-slate-400 hover:text-rose-400 transition-colors"
            >
              ⚠️ Reset Career Progress
            </button>
          ) : (
            <div className="flex items-center gap-2">
              <button
                onClick={() => {
                  onResetProgress();
                  setShowResetConfirm(false);
                  onClose();
                }}
                className="flex-1 py-2 px-3 rounded-xl bg-rose-600 hover:bg-rose-500 text-xs font-display font-bold text-white shadow-lg"
              >
                CONFIRM RESET
              </button>
              <button
                onClick={() => setShowResetConfirm(false)}
                className="py-2 px-4 rounded-xl bg-slate-900 text-xs font-tech font-bold text-slate-300"
              >
                CANCEL
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

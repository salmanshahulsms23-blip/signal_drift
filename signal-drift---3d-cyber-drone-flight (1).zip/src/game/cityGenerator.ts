import * as THREE from 'three';
import { GateData, HazardData, GateSymbol, GateColor } from '../types/game';

// Shared geometries and materials for optimal performance
const sharedMaterials = {
  buildingBase: new THREE.MeshStandardMaterial({
    color: 0x111625,
    roughness: 0.7,
    metalness: 0.5,
  }),
  buildingTrimCyan: new THREE.MeshStandardMaterial({
    color: 0x00f0ff,
    emissive: 0x00d0ee,
    emissiveIntensity: 1.2,
    roughness: 0.3,
  }),
  buildingTrimMagenta: new THREE.MeshStandardMaterial({
    color: 0xff0077,
    emissive: 0xdd0066,
    emissiveIntensity: 1.2,
    roughness: 0.3,
  }),
  buildingTrimAmber: new THREE.MeshStandardMaterial({
    color: 0xffaa00,
    emissive: 0xdd8800,
    emissiveIntensity: 1.2,
    roughness: 0.3,
  }),
  cloud: new THREE.MeshStandardMaterial({
    color: 0x1a233a,
    roughness: 0.9,
    metalness: 0.1,
    transparent: true,
    opacity: 0.75,
  }),
};

export interface CityEnvironment {
  group: THREE.Group;
  collisionBoxes: THREE.Box3[];
  cloudPuffs: THREE.Mesh[];
  skyMesh: THREE.Mesh;
  starsParticles: THREE.Points;
  rainParticles?: THREE.Points;
  update: (delta: number) => void;
}

export function createCityEnvironment(skyTheme: string, hasStorm: boolean = false): CityEnvironment {
  const group = new THREE.Group();
  const collisionBoxes: THREE.Box3[] = [];
  const cloudPuffs: THREE.Mesh[] = [];

  // 1. PROCEDURAL GRADIENT SKY DOME
  const skyGeo = new THREE.SphereGeometry(600, 32, 16);
  skyGeo.scale(-1, 1, 1);

  const colors = getSkyColors(skyTheme);
  const count = skyGeo.attributes.position.count;
  const colorAttr = new Float32Array(count * 3);
  const pos = skyGeo.attributes.position;

  for (let i = 0; i < count; i++) {
    const y = pos.getY(i) / 600;
    const factor = Math.max(0, Math.min(1, (y + 0.1) * 0.9));

    const r = colors.horizon.r + (colors.zenith.r - colors.horizon.r) * factor;
    const g = colors.horizon.g + (colors.zenith.g - colors.horizon.g) * factor;
    const b = colors.horizon.b + (colors.zenith.b - colors.horizon.b) * factor;

    colorAttr[i * 3] = r;
    colorAttr[i * 3 + 1] = g;
    colorAttr[i * 3 + 2] = b;
  }
  skyGeo.setAttribute('color', new THREE.BufferAttribute(colorAttr, 3));

  const skyMat = new THREE.MeshBasicMaterial({
    vertexColors: true,
    side: THREE.BackSide,
    depthWrite: false,
  });
  const skyMesh = new THREE.Mesh(skyGeo, skyMat);
  group.add(skyMesh);

  // 2. PROCEDURAL STARS / SPACE DUST
  const starCount = 650;
  const starGeo = new THREE.BufferGeometry();
  const starPos = new Float32Array(starCount * 3);
  const starColors = new Float32Array(starCount * 3);

  for (let i = 0; i < starCount; i++) {
    const phi = Math.random() * Math.PI * 2;
    const theta = Math.acos(Math.random() * 0.8 + 0.1);
    const radius = 550;

    starPos[i * 3] = radius * Math.sin(theta) * Math.cos(phi);
    starPos[i * 3 + 1] = radius * Math.cos(theta);
    starPos[i * 3 + 2] = radius * Math.sin(theta) * Math.sin(phi);

    const isCyan = Math.random() > 0.6;
    starColors[i * 3] = isCyan ? 0.4 : 1.0;
    starColors[i * 3 + 1] = isCyan ? 0.9 : 0.95;
    starColors[i * 3 + 2] = 1.0;
  }
  starGeo.setAttribute('position', new THREE.BufferAttribute(starPos, 3));
  starGeo.setAttribute('color', new THREE.BufferAttribute(starColors, 3));

  const starMat = new THREE.PointsMaterial({
    size: 2.2,
    vertexColors: true,
    transparent: true,
    opacity: hasStorm ? 0.3 : 0.85,
    depthWrite: false,
  });
  const starsParticles = new THREE.Points(starGeo, starMat);
  group.add(starsParticles);

  // 3. LOW-POLY CLOUD SEA
  const cloudGroup = new THREE.Group();
  cloudGroup.position.set(0, -8, -100);

  const puffGeo = new THREE.DodecahedronGeometry(18, 1);
  for (let i = 0; i < 45; i++) {
    const puff = new THREE.Mesh(puffGeo, sharedMaterials.cloud);
    const x = (Math.random() - 0.5) * 600;
    const y = -12 + (Math.random() - 0.5) * 8;
    const z = (Math.random() - 0.5) * 600;
    puff.position.set(x, y, z);
    const scale = 0.8 + Math.random() * 1.5;
    puff.scale.set(scale * 1.8, scale * 0.6, scale * 1.8);
    puff.rotation.set(Math.random(), Math.random(), Math.random());
    cloudGroup.add(puff);
    cloudPuffs.push(puff);
  }
  group.add(cloudGroup);

  // 4. STORM PARTICLES (for storm run)
  let rainParticles: THREE.Points | undefined;
  if (hasStorm) {
    const rainCount = 450;
    const rainGeo = new THREE.BufferGeometry();
    const rainPos = new Float32Array(rainCount * 3);
    for (let i = 0; i < rainCount; i++) {
      rainPos[i * 3] = (Math.random() - 0.5) * 250;
      rainPos[i * 3 + 1] = Math.random() * 120;
      rainPos[i * 3 + 2] = (Math.random() - 0.5) * 350;
    }
    rainGeo.setAttribute('position', new THREE.BufferAttribute(rainPos, 3));
    const rainMat = new THREE.PointsMaterial({
      color: 0x93c5fd,
      size: 1.8,
      transparent: true,
      opacity: 0.6,
      depthWrite: false,
    });
    rainParticles = new THREE.Points(rainGeo, rainMat);
    group.add(rainParticles);
  }

  // 5. PROCEDURAL HIGH-TECH SKYSCRAPERS & TOWERS
  const buildingSpecs = generateCityLayout();

  buildingSpecs.forEach((spec) => {
    const bGroup = new THREE.Group();
    bGroup.position.set(spec.x, spec.y, spec.z);

    const towerGeo = spec.isHex
      ? new THREE.CylinderGeometry(spec.width * 0.6, spec.width * 0.7, spec.height, 6)
      : new THREE.BoxGeometry(spec.width, spec.height, spec.depth || spec.width);

    const towerMat = new THREE.MeshStandardMaterial({
      color: spec.color || 0x111726,
      roughness: 0.65,
      metalness: 0.6,
    });
    const towerMesh = new THREE.Mesh(towerGeo, towerMat);
    towerMesh.position.y = spec.height / 2;
    towerMesh.castShadow = true;
    towerMesh.receiveShadow = true;
    bGroup.add(towerMesh);

    // Glowing Neon Accent Bands
    if (spec.accentColor) {
      const bandCount = Math.floor(spec.height / 18);
      for (let b = 1; b < bandCount; b++) {
        const bandGeo = spec.isHex
          ? new THREE.CylinderGeometry(spec.width * 0.61, spec.width * 0.61, 0.4, 6)
          : new THREE.BoxGeometry(spec.width * 1.02, 0.4, (spec.depth || spec.width) * 1.02);
        const bandMat = spec.accentColor === 'magenta' 
          ? sharedMaterials.buildingTrimMagenta 
          : spec.accentColor === 'amber'
          ? sharedMaterials.buildingTrimAmber
          : sharedMaterials.buildingTrimCyan;
        const bandMesh = new THREE.Mesh(bandGeo, bandMat);
        bandMesh.position.y = b * 18;
        bGroup.add(bandMesh);
      }
    }

    // Rooftop Antenna / Spire
    const spireGeo = new THREE.CylinderGeometry(0.2, 0.6, spec.spireHeight || 12, 4);
    const spireMat = new THREE.MeshStandardMaterial({
      color: 0x334155,
      metalness: 0.9,
      roughness: 0.2,
    });
    const spireMesh = new THREE.Mesh(spireGeo, spireMat);
    spireMesh.position.y = spec.height + (spec.spireHeight || 12) / 2;
    bGroup.add(spireMesh);

    const tipGeo = new THREE.SphereGeometry(0.6, 6, 6);
    const tipMat = spec.accentColor === 'magenta' ? sharedMaterials.buildingTrimMagenta : sharedMaterials.buildingTrimCyan;
    const tipMesh = new THREE.Mesh(tipGeo, tipMat);
    tipMesh.position.y = spec.height + (spec.spireHeight || 12);
    bGroup.add(tipMesh);

    group.add(bGroup);

    const bBox = new THREE.Box3();
    bBox.setFromCenterAndSize(
      new THREE.Vector3(spec.x, spec.y + spec.height / 2, spec.z),
      new THREE.Vector3(spec.width * 0.9, spec.height, (spec.depth || spec.width) * 0.9)
    );
    collisionBoxes.push(bBox);
  });

  let elapsed = 0;
  const update = (delta: number) => {
    elapsed += delta;
    cloudPuffs.forEach((puff, idx) => {
      puff.position.x += Math.sin(elapsed * 0.2 + idx) * 0.05;
      puff.rotation.y += 0.002;
    });
    starsParticles.rotation.y = elapsed * 0.001;

    if (rainParticles) {
      const pArr = rainParticles.geometry.attributes.position.array as Float32Array;
      for (let i = 1; i < pArr.length; i += 3) {
        pArr[i] -= delta * 90;
        if (pArr[i] < 0) pArr[i] = 120;
      }
      rainParticles.geometry.attributes.position.needsUpdate = true;
    }
  };

  return {
    group,
    collisionBoxes,
    cloudPuffs,
    skyMesh,
    starsParticles,
    rainParticles,
    update,
  };
}

function getSkyColors(theme: string) {
  switch (theme) {
    case 'dawn':
      return {
        horizon: new THREE.Color(0xfb923c),
        zenith: new THREE.Color(0x0f172a),
      };
    case 'dusk':
      return {
        horizon: new THREE.Color(0xc026d3),
        zenith: new THREE.Color(0x090d16),
      };
    case 'neon_storm':
      return {
        horizon: new THREE.Color(0x06b6d4),
        zenith: new THREE.Color(0x1e1b4b),
      };
    case 'aurora':
      return {
        horizon: new THREE.Color(0x10b981),
        zenith: new THREE.Color(0x1e1035),
      };
    case 'solar':
      return {
        horizon: new THREE.Color(0xf59e0b),
        zenith: new THREE.Color(0x1c1917),
      };
    case 'midnight':
    default:
      return {
        horizon: new THREE.Color(0x0284c7),
        zenith: new THREE.Color(0x030712),
      };
  }
}

interface BuildingSpec {
  x: number;
  y: number;
  z: number;
  width: number;
  height: number;
  depth?: number;
  isHex?: boolean;
  color?: number;
  accentColor?: 'cyan' | 'magenta' | 'amber';
  spireHeight?: number;
}

function generateCityLayout(): BuildingSpec[] {
  return [
    { x: -55, y: -5, z: 40, width: 22, height: 55, depth: 22, accentColor: 'cyan', spireHeight: 18 },
    { x: 55, y: -5, z: 40, width: 24, height: 50, depth: 20, accentColor: 'magenta', spireHeight: 14 },
    { x: -75, y: -5, z: 0, width: 26, height: 70, isHex: true, accentColor: 'cyan', spireHeight: 22 },
    { x: 75, y: -5, z: 0, width: 28, height: 65, depth: 25, accentColor: 'amber', spireHeight: 16 },

    { x: -60, y: -5, z: -50, width: 25, height: 80, isHex: true, accentColor: 'magenta', spireHeight: 25 },
    { x: 60, y: -5, z: -50, width: 25, height: 75, depth: 22, accentColor: 'cyan', spireHeight: 20 },
    { x: -85, y: -5, z: -100, width: 30, height: 95, depth: 30, accentColor: 'cyan', spireHeight: 30 },
    { x: 85, y: -5, z: -100, width: 32, height: 90, isHex: true, accentColor: 'amber', spireHeight: 28 },

    { x: -65, y: -5, z: -160, width: 28, height: 110, isHex: true, accentColor: 'cyan', spireHeight: 35 },
    { x: 65, y: -5, z: -160, width: 30, height: 105, depth: 28, accentColor: 'magenta', spireHeight: 32 },
    { x: -75, y: -5, z: -220, width: 32, height: 125, depth: 32, accentColor: 'amber', spireHeight: 40 },
    { x: 75, y: -5, z: -220, width: 34, height: 120, isHex: true, accentColor: 'cyan', spireHeight: 38 },

    { x: -140, y: -5, z: -120, width: 45, height: 150, depth: 45, accentColor: 'cyan', spireHeight: 45 },
    { x: 140, y: -5, z: -120, width: 45, height: 145, depth: 45, accentColor: 'magenta', spireHeight: 45 },
    { x: -130, y: -5, z: -250, width: 50, height: 180, depth: 50, accentColor: 'cyan', spireHeight: 50 },
    { x: 130, y: -5, z: -250, width: 50, height: 175, depth: 50, accentColor: 'amber', spireHeight: 50 },
  ];
}

// 6. ENERGY GATE MESH BUILDER
export interface GateMeshObject {
  group: THREE.Group;
  data: GateData;
  innerRing: THREE.Mesh;
  halo: THREE.Mesh;
  particles: THREE.Points;
  beaconLight: THREE.PointLight;
  beamCylinder: THREE.Mesh;
  symbolMesh: THREE.Group;
  timerRing?: THREE.Mesh;
  passed: boolean;
  timedSecondsLeft: number;
  update: (delta: number, isTarget: boolean, isPreview: boolean) => void;
  triggerPassEffect: (isCorrect: boolean) => void;
  teleportTo: (newPos: [number, number, number]) => void;
}

export function createEnergyGate(data: GateData): GateMeshObject {
  const group = new THREE.Group();
  group.position.set(data.position[0], data.position[1], data.position[2]);
  group.rotation.y = data.rotationY;

  const hexColor = getHexForGateColor(data.color);

  // Outer structural ring / hex arch
  const outerArchGeo = new THREE.TorusGeometry(data.radius, 0.45, 8, 32);
  const outerMat = new THREE.MeshStandardMaterial({
    color: 0x1e293b,
    metalness: 0.9,
    roughness: 0.25,
  });
  const outerMesh = new THREE.Mesh(outerArchGeo, outerMat);
  group.add(outerMesh);

  // Glowing Energy Core Ring
  const innerRingGeo = new THREE.TorusGeometry(data.radius * 0.95, 0.25, 8, 32);
  const innerMat = new THREE.MeshStandardMaterial({
    color: hexColor,
    emissive: hexColor,
    emissiveIntensity: 1.5,
    roughness: 0.1,
    metalness: 0.8,
  });
  const innerRing = new THREE.Mesh(innerRingGeo, innerMat);
  group.add(innerRing);

  // Translucent glowing forcefield membrane
  const haloGeo = new THREE.CircleGeometry(data.radius * 0.94, 24);
  const haloMat = new THREE.MeshBasicMaterial({
    color: hexColor,
    transparent: true,
    opacity: 0.18,
    side: THREE.DoubleSide,
    depthWrite: false,
  });
  const halo = new THREE.Mesh(haloGeo, haloMat);
  group.add(halo);

  // Vertical sky beacon pillar
  const beamGeo = new THREE.CylinderGeometry(0.8, 1.4, 280, 8);
  beamGeo.translate(0, 140, 0);
  const beamMat = new THREE.MeshBasicMaterial({
    color: hexColor,
    transparent: true,
    opacity: 0.35,
    side: THREE.DoubleSide,
    depthWrite: false,
  });
  const beamCylinder = new THREE.Mesh(beamGeo, beamMat);
  beamCylinder.visible = false;
  group.add(beamCylinder);

  // Point light inside gate
  const beaconLight = new THREE.PointLight(hexColor, 2.0, 30);
  group.add(beaconLight);

  // Orbiting digital energy particles
  const pCount = 36;
  const pGeo = new THREE.BufferGeometry();
  const pPos = new Float32Array(pCount * 3);
  for (let i = 0; i < pCount; i++) {
    const angle = (i / pCount) * Math.PI * 2;
    pPos[i * 3] = Math.cos(angle) * data.radius;
    pPos[i * 3 + 1] = Math.sin(angle) * data.radius;
    pPos[i * 3 + 2] = (Math.random() - 0.5) * 1.5;
  }
  pGeo.setAttribute('position', new THREE.BufferAttribute(pPos, 3));
  const pMat = new THREE.PointsMaterial({
    size: 1.2,
    color: hexColor,
    transparent: true,
    opacity: 0.8,
    depthWrite: false,
  });
  const particles = new THREE.Points(pGeo, pMat);
  group.add(particles);

  // 3D Procedural Symbol Icon (Triangle, Circle, Star, Lightning, Diamond, Hexagon)
  const symbolMesh = createGateSymbol(data.symbol || 'circle', hexColor, data.isDecoy);
  symbolMesh.position.set(0, data.radius + 2.5, 0);
  group.add(symbolMesh);

  // Circular Timer Ring for Timed Gates
  let timerRing: THREE.Mesh | undefined;
  if (data.isTimed) {
    const tRingGeo = new THREE.TorusGeometry(data.radius * 1.08, 0.22, 6, 32);
    const tRingMat = new THREE.MeshBasicMaterial({
      color: 0xfacc15,
      transparent: true,
      opacity: 0.85,
    });
    timerRing = new THREE.Mesh(tRingGeo, tRingMat);
    timerRing.visible = false;
    group.add(timerRing);
  }

  let passed = false;
  let pulseTimer = 0;
  let timedSecondsLeft = data.timeLimit || 10;
  let moveT = Math.random();
  let moveDir = 1;
  const basePos = new THREE.Vector3(...data.position);

  const update = (delta: number, isTarget: boolean, isPreview: boolean) => {
    pulseTimer += delta * 3;
    particles.rotation.z += delta * 1.5;
    symbolMesh.rotation.y += delta * 1.5;

    // Moving gate support
    if (data.isMoving && data.moveStart && data.moveEnd) {
      const startV = new THREE.Vector3(...data.moveStart);
      const endV = new THREE.Vector3(...data.moveEnd);
      const dist = Math.max(1, startV.distanceTo(endV));
      moveT += delta * ((data.moveSpeed || 12) / dist) * moveDir;
      if (moveT >= 1) { moveT = 1; moveDir = -1; }
      else if (moveT <= 0) { moveT = 0; moveDir = 1; }
      group.position.lerpVectors(startV, endV, moveT);
      data.position = [group.position.x, group.position.y, group.position.z];
    }

    // Decoy visual glitch/unstable signal distortion
    if (data.isDecoy) {
      const glitch = Math.sin(Date.now() * 0.05);
      if (glitch > 0.8) {
        group.position.x = basePos.x + (Math.random() - 0.5) * 0.5;
        group.position.y = basePos.y + (Math.random() - 0.5) * 0.5;
        innerMat.emissiveIntensity = 2.8;
      } else {
        group.position.x = basePos.x;
        group.position.y = basePos.y;
        innerMat.emissiveIntensity = 0.9;
      }
    }

    // Timed gate circular countdown ring
    if (data.isTimed && timerRing) {
      if (isTarget && !passed) {
        timerRing.visible = true;
        timedSecondsLeft = Math.max(0, timedSecondsLeft - delta);
        const ratio = timedSecondsLeft / (data.timeLimit || 10);
        timerRing.scale.set(ratio, ratio, 1);
        (timerRing.material as THREE.MeshBasicMaterial).color.setHex(ratio < 0.3 ? 0xef4444 : 0xfacc15);
      } else {
        timerRing.visible = false;
      }
    }

    if (passed) {
      innerMat.emissiveIntensity = 0.3;
      haloMat.opacity = 0.05;
      beamCylinder.visible = false;
      beaconLight.intensity = 0.3;
      if (timerRing) timerRing.visible = false;
      return;
    }

    if (isPreview) {
      beamCylinder.visible = true;
      beamCylinder.scale.x = 1.0 + Math.sin(pulseTimer * 1.5) * 0.15;
      beamCylinder.scale.z = beamCylinder.scale.x;
      innerMat.emissiveIntensity = 2.0;
      haloMat.opacity = 0.35;
      beaconLight.intensity = 3.5;
      symbolMesh.visible = true;
    } else if (isTarget) {
      beamCylinder.visible = true;
      beamCylinder.scale.x = 0.8 + Math.sin(pulseTimer * 2) * 0.1;
      beamCylinder.scale.z = beamCylinder.scale.x;
      innerMat.emissiveIntensity = 1.8 + Math.sin(pulseTimer * 4) * 0.4;
      haloMat.opacity = 0.25 + Math.sin(pulseTimer * 4) * 0.1;
      beaconLight.intensity = 2.5;
      symbolMesh.visible = true;
    } else {
      beamCylinder.visible = false;
      innerMat.emissiveIntensity = 0.9;
      haloMat.opacity = 0.12;
      beaconLight.intensity = 1.0;
      symbolMesh.visible = true;
    }
  };

  const triggerPassEffect = (isCorrect: boolean) => {
    passed = isCorrect;
    const effectColor = isCorrect ? 0x00ff88 : 0xff2244;
    innerMat.color.setHex(effectColor);
    innerMat.emissive.setHex(effectColor);
    innerMat.emissiveIntensity = 4.0;
    beaconLight.color.setHex(effectColor);
    beaconLight.intensity = 5.0;

    setTimeout(() => {
      if (isCorrect) {
        innerMat.emissiveIntensity = 0.25;
        haloMat.opacity = 0.05;
        beaconLight.intensity = 0.4;
      } else {
        innerMat.color.setHex(hexColor);
        innerMat.emissive.setHex(hexColor);
        innerMat.emissiveIntensity = 1.0;
        beaconLight.color.setHex(hexColor);
        beaconLight.intensity = 1.0;
      }
    }, 600);
  };

  const teleportTo = (newPos: [number, number, number]) => {
    group.position.set(...newPos);
    basePos.set(...newPos);
    data.position = [...newPos];
    timedSecondsLeft = data.timeLimit || 10;
  };

  return {
    group,
    data,
    innerRing,
    halo,
    particles,
    beamCylinder,
    beaconLight,
    symbolMesh,
    timerRing,
    passed,
    timedSecondsLeft,
    update,
    triggerPassEffect,
    teleportTo,
  };
}

export function getHexForGateColor(color: GateColor | string): number {
  switch (color) {
    case 'red': return 0xef4444;
    case 'blue': return 0x3b82f6;
    case 'green': return 0x10b981;
    case 'purple': return 0xa855f7;
    case 'orange': return 0xf97316;
    case 'yellow': return 0xeab308;
    case 'cyan': return 0x06b6d4;
    case 'magenta': return 0xec4899;
    case 'amber': return 0xf59e0b;
    case 'emerald': return 0x10b981;
    case 'violet': return 0x8b5cf6;
    default: return 0x06b6d4;
  }
}

// Procedural 3D Holographic Gate Symbols (Triangle, Circle, Star, Lightning, Diamond, Hexagon)
function createGateSymbol(symbol: GateSymbol, hexColor: number, isDecoy?: boolean): THREE.Group {
  const g = new THREE.Group();
  const mat = new THREE.MeshStandardMaterial({
    color: hexColor,
    emissive: hexColor,
    emissiveIntensity: isDecoy ? 2.5 : 1.8,
    roughness: 0.2,
    metalness: 0.8,
  });

  if (symbol === 'triangle') {
    // 3-sided prism
    const geo = new THREE.CylinderGeometry(1.6, 1.6, 0.4, 3);
    geo.rotateZ(Math.PI / 2);
    const m = new THREE.Mesh(geo, mat);
    g.add(m);
  } else if (symbol === 'circle') {
    // Torus ring
    const geo = new THREE.TorusGeometry(1.3, 0.28, 8, 24);
    const m = new THREE.Mesh(geo, mat);
    g.add(m);
  } else if (symbol === 'diamond') {
    // Rotated square prism
    const geo = new THREE.BoxGeometry(1.7, 1.7, 0.4);
    geo.rotateZ(Math.PI / 4);
    const m = new THREE.Mesh(geo, mat);
    g.add(m);
  } else if (symbol === 'hexagon') {
    // 6-sided cylinder
    const geo = new THREE.CylinderGeometry(1.5, 1.5, 0.4, 6);
    geo.rotateX(Math.PI / 2);
    const m = new THREE.Mesh(geo, mat);
    g.add(m);
  } else if (symbol === 'star') {
    // 5-pointed star from grouped diamond prisms
    for (let i = 0; i < 5; i++) {
      const geo = new THREE.ConeGeometry(0.7, 2.0, 4);
      geo.rotateZ((i * Math.PI * 2) / 5);
      const m = new THREE.Mesh(geo, mat);
      g.add(m);
    }
  } else if (symbol === 'lightning') {
    // 3-segment lightning zig-zag
    const b1 = new THREE.BoxGeometry(0.35, 1.3, 0.35);
    b1.rotateZ(Math.PI / 6);
    const m1 = new THREE.Mesh(b1, mat);
    m1.position.set(-0.35, 0.45, 0);

    const b2 = new THREE.BoxGeometry(0.35, 1.3, 0.35);
    b2.rotateZ(-Math.PI / 6);
    const m2 = new THREE.Mesh(b2, mat);
    m2.position.set(0.35, -0.45, 0);

    g.add(m1);
    g.add(m2);
  }

  return g;
}

// 7. SIGNAL TOWER BUILDER (Master Destination)
export interface SignalTowerObject {
  group: THREE.Group;
  antennaRings: THREE.Mesh[];
  beaconLight: THREE.PointLight;
  skyBeam: THREE.Mesh;
  shockwaveRing: THREE.Mesh;
  uplinkZone: THREE.Box3;
  isActivated: boolean;
  update: (delta: number, isUplinkReady: boolean) => void;
  activate: () => void;
}

export function createSignalTower(position: [number, number, number]): SignalTowerObject {
  const group = new THREE.Group();
  group.position.set(position[0], 0, position[2]);

  const towerHeight = position[1] + 25;

  const baseGeo = new THREE.CylinderGeometry(8, 14, towerHeight * 0.6, 8);
  const towerMat = new THREE.MeshStandardMaterial({
    color: 0x0f172a,
    roughness: 0.6,
    metalness: 0.8,
  });
  const baseMesh = new THREE.Mesh(baseGeo, towerMat);
  baseMesh.position.y = towerHeight * 0.3;
  baseMesh.castShadow = true;
  group.add(baseMesh);

  const upperGeo = new THREE.CylinderGeometry(3.5, 8, towerHeight * 0.4, 8);
  const upperMesh = new THREE.Mesh(upperGeo, towerMat);
  upperMesh.position.y = towerHeight * 0.8;
  upperMesh.castShadow = true;
  group.add(upperMesh);

  const platformGeo = new THREE.CylinderGeometry(9, 7, 3, 12);
  const platMat = new THREE.MeshStandardMaterial({
    color: 0x1e293b,
    metalness: 0.9,
    roughness: 0.2,
  });
  const platMesh = new THREE.Mesh(platformGeo, platMat);
  platMesh.position.y = towerHeight;
  group.add(platMesh);

  const targetRingGeo = new THREE.TorusGeometry(8.5, 0.5, 8, 32);
  targetRingGeo.rotateX(Math.PI / 2);
  const targetRingMat = new THREE.MeshStandardMaterial({
    color: 0x00f0ff,
    emissive: 0x00d0ee,
    emissiveIntensity: 1.5,
  });
  const targetRing = new THREE.Mesh(targetRingGeo, targetRingMat);
  targetRing.position.y = towerHeight + 0.8;
  group.add(targetRing);

  const antennaRings: THREE.Mesh[] = [];
  [12, 9, 6].forEach((r, idx) => {
    const aGeo = new THREE.TorusGeometry(r, 0.35, 6, 24);
    aGeo.rotateX(Math.PI / 2);
    const aMat = new THREE.MeshStandardMaterial({
      color: idx % 2 === 0 ? 0x00f0ff : 0xff00aa,
      emissive: idx % 2 === 0 ? 0x00ccee : 0xee0099,
      emissiveIntensity: 1.2,
    });
    const aMesh = new THREE.Mesh(aGeo, aMat);
    aMesh.position.y = towerHeight + 5 + idx * 4;
    group.add(aMesh);
    antennaRings.push(aMesh);
  });

  const skyBeamGeo = new THREE.CylinderGeometry(2.5, 6.0, 500, 16);
  skyBeamGeo.translate(0, 250, 0);
  const skyBeamMat = new THREE.MeshBasicMaterial({
    color: 0x00f0ff,
    transparent: true,
    opacity: 0.2,
    side: THREE.DoubleSide,
    depthWrite: false,
  });
  const skyBeam = new THREE.Mesh(skyBeamGeo, skyBeamMat);
  skyBeam.position.y = towerHeight + 15;
  group.add(skyBeam);

  const shockGeo = new THREE.RingGeometry(2, 4, 32);
  shockGeo.rotateX(Math.PI / 2);
  const shockMat = new THREE.MeshBasicMaterial({
    color: 0x00ffff,
    transparent: true,
    opacity: 0,
    side: THREE.DoubleSide,
    depthWrite: false,
  });
  const shockwaveRing = new THREE.Mesh(shockGeo, shockMat);
  shockwaveRing.position.y = towerHeight + 2;
  group.add(shockwaveRing);

  const beaconLight = new THREE.PointLight(0x00f0ff, 2.0, 80);
  beaconLight.position.y = towerHeight + 16;
  group.add(beaconLight);

  const uplinkZone = new THREE.Box3();
  const zoneCenter = new THREE.Vector3(position[0], towerHeight + 4, position[2]);
  uplinkZone.setFromCenterAndSize(zoneCenter, new THREE.Vector3(20, 16, 20));

  let isActivated = false;
  let animTime = 0;
  let shockwaveScale = 1;

  const update = (delta: number, isUplinkReady: boolean) => {
    animTime += delta;

    antennaRings.forEach((ring, idx) => {
      const speed = isActivated ? 6.0 : isUplinkReady ? 2.5 : 0.8;
      ring.rotation.y += delta * speed * (idx % 2 === 0 ? 1 : -1);
    });

    if (isActivated) {
      targetRingMat.emissiveIntensity = 4.0;
      skyBeamMat.opacity = 0.85;
      skyBeam.scale.x = 2.8 + Math.sin(animTime * 15) * 0.4;
      skyBeam.scale.z = skyBeam.scale.x;
      beaconLight.intensity = 8.5;

      shockwaveScale += delta * 45;
      shockwaveRing.scale.set(shockwaveScale, shockwaveScale, shockwaveScale);
      shockMat.opacity = Math.max(0, 1 - shockwaveScale / 45);
    } else if (isUplinkReady) {
      targetRingMat.emissiveIntensity = 2.2 + Math.sin(animTime * 6) * 0.8;
      skyBeamMat.opacity = 0.45 + Math.sin(animTime * 4) * 0.15;
      beaconLight.intensity = 4.0;
    } else {
      targetRingMat.emissiveIntensity = 0.8;
      skyBeamMat.opacity = 0.1;
      beaconLight.intensity = 1.0;
    }
  };

  const activate = () => {
    isActivated = true;
    shockwaveScale = 1;
    shockMat.opacity = 0.9;
  };

  return {
    group,
    antennaRings,
    beaconLight,
    skyBeam,
    shockwaveRing,
    uplinkZone,
    isActivated,
    update,
    activate,
  };
}

// 8. ENERGY CELL PICKUP BUILDER
export interface EnergyCellObject {
  group: THREE.Group;
  position: [number, number, number];
  collected: boolean;
  box: THREE.Box3;
  update: (delta: number) => void;
  collect: () => void;
}

export function createEnergyCell(pos: [number, number, number]): EnergyCellObject {
  const group = new THREE.Group();
  group.position.set(pos[0], pos[1], pos[2]);

  const crystalGeo = new THREE.OctahedronGeometry(1.2, 0);
  const crystalMat = new THREE.MeshStandardMaterial({
    color: 0x00f0ff,
    emissive: 0x00d0ee,
    emissiveIntensity: 1.8,
    roughness: 0.1,
    metalness: 0.9,
  });
  const crystal1 = new THREE.Mesh(crystalGeo, crystalMat);
  group.add(crystal1);

  const crystal2 = new THREE.Mesh(crystalGeo, crystalMat);
  crystal2.scale.set(0.65, 0.65, 0.65);
  group.add(crystal2);

  const haloGeo = new THREE.SphereGeometry(2.0, 12, 12);
  const haloMat = new THREE.MeshBasicMaterial({
    color: 0x00f0ff,
    transparent: true,
    opacity: 0.22,
    depthWrite: false,
  });
  const halo = new THREE.Mesh(haloGeo, haloMat);
  group.add(halo);

  const pLight = new THREE.PointLight(0x00f0ff, 1.2, 10);
  group.add(pLight);

  const box = new THREE.Box3();
  box.setFromCenterAndSize(new THREE.Vector3(...pos), new THREE.Vector3(3.5, 3.5, 3.5));

  let collected = false;
  let t = Math.random() * 10;

  const update = (delta: number) => {
    if (collected) return;
    t += delta;
    crystal1.rotation.y += delta * 2;
    crystal1.rotation.x += delta * 1.5;
    crystal2.rotation.y -= delta * 2.5;

    group.position.y = pos[1] + Math.sin(t * 3) * 0.4;
    box.setFromCenterAndSize(group.position, new THREE.Vector3(3.5, 3.5, 3.5));
  };

  const collect = () => {
    collected = true;
    group.visible = false;
  };

  return {
    group,
    position: pos,
    collected,
    box,
    update,
    collect,
  };
}

// 9. HAZARD OBJECT BUILDER
export interface HazardMeshObject {
  group: THREE.Group;
  data: HazardData;
  box: THREE.Box3;
  update: (delta: number, dronePos?: THREE.Vector3) => void;
}

export function createHazardMesh(data: HazardData): HazardMeshObject {
  const group = new THREE.Group();
  const box = new THREE.Box3();

  if (data.type === 'patrol_drone') {
    const bodyGeo = new THREE.BoxGeometry(3.5, 1.2, 3.5);
    const bodyMat = new THREE.MeshStandardMaterial({
      color: 0x334155,
      metalness: 0.8,
      roughness: 0.3,
    });
    const body = new THREE.Mesh(bodyGeo, bodyMat);
    group.add(body);

    const strobeGeo = new THREE.SphereGeometry(0.4, 8, 8);
    const strobeMat = new THREE.MeshBasicMaterial({ color: 0xff1133 });
    const strobe = new THREE.Mesh(strobeGeo, strobeMat);
    strobe.position.y = 0.8;
    group.add(strobe);

    const hazardLight = new THREE.PointLight(0xff1133, 1.8, 15);
    hazardLight.position.y = 0.8;
    group.add(hazardLight);

    let patrolT = Math.random();
    let forward = true;
    const start = new THREE.Vector3(...(data.patrolStart || [data.position[0] - 30, data.position[1], data.position[2]]));
    const end = new THREE.Vector3(...(data.patrolEnd || [data.position[0] + 30, data.position[1], data.position[2]]));
    const speed = (data.speed || 15) / Math.max(1, start.distanceTo(end));

    const update = (delta: number) => {
      if (forward) {
        patrolT += delta * speed;
        if (patrolT >= 1) { patrolT = 1; forward = false; }
      } else {
        patrolT -= delta * speed;
        if (patrolT <= 0) { patrolT = 0; forward = true; }
      }

      group.position.lerpVectors(start, end, patrolT);
      hazardLight.intensity = Math.sin(Date.now() * 0.015) > 0 ? 2.5 : 0.2;
      box.setFromCenterAndSize(group.position, new THREE.Vector3(4.5, 2.5, 4.5));
    };

    return { group, data, box, update };
  } else if (data.type === 'security_chaser') {
    // Security Chaser Drone (Mission 19)
    const bodyGeo = new THREE.CylinderGeometry(1.6, 2.0, 1.2, 6);
    const bodyMat = new THREE.MeshStandardMaterial({
      color: 0x450a0a,
      metalness: 0.9,
      roughness: 0.2,
    });
    const body = new THREE.Mesh(bodyGeo, bodyMat);
    group.add(body);

    const redBeacon = new THREE.PointLight(0xef4444, 2.5, 20);
    redBeacon.position.y = 0.8;
    group.add(redBeacon);

    group.position.set(...data.position);
    const chaserSpeed = data.speed || 18;

    const update = (delta: number, dronePos?: THREE.Vector3) => {
      if (dronePos) {
        const toDrone = new THREE.Vector3().copy(dronePos).sub(group.position);
        const dist = toDrone.length();
        if (dist > 3) {
          toDrone.normalize();
          group.position.addScaledVector(toDrone, chaserSpeed * delta);
          group.lookAt(dronePos);
        }
      }
      redBeacon.intensity = 2.0 + Math.sin(Date.now() * 0.02) * 1.0;
      box.setFromCenterAndSize(group.position, new THREE.Vector3(4.0, 3.0, 4.0));
    };

    return { group, data, box, update };
  } else if (data.type === 'laser_beam') {
    const startPos = new THREE.Vector3(...data.position);
    const endPos = new THREE.Vector3(...(data.laserEnd || [data.position[0], data.position[1], data.position[2] - 30]));
    const dist = startPos.distanceTo(endPos);

    const beamGeo = new THREE.CylinderGeometry(0.3, 0.3, dist, 8);
    beamGeo.translate(0, dist / 2, 0);
    beamGeo.rotateX(Math.PI / 2);

    const beamMat = new THREE.MeshBasicMaterial({
      color: 0xff0044,
      transparent: true,
      opacity: 0.85,
    });
    const beamMesh = new THREE.Mesh(beamGeo, beamMat);
    group.position.copy(startPos);
    group.lookAt(endPos);
    group.add(beamMesh);

    let cycle = 0;
    const period = data.cyclePeriod || 3.0;

    const update = (delta: number) => {
      cycle += delta;
      const isFiring = (cycle % period) > (period * 0.4);
      beamMesh.visible = isFiring;
      if (isFiring) {
        const mid = new THREE.Vector3().lerpVectors(startPos, endPos, 0.5);
        box.setFromCenterAndSize(mid, new THREE.Vector3(2.5, 2.5, dist));
      } else {
        box.makeEmpty();
      }
    };

    return { group, data, box, update };
  } else if (data.type === 'wind_zone') {
    const size = data.size || [40, 20, 40];
    group.position.set(...data.position);

    const pCount = 80;
    const pGeo = new THREE.BufferGeometry();
    const pPos = new Float32Array(pCount * 3);
    for (let i = 0; i < pCount; i++) {
      pPos[i * 3] = (Math.random() - 0.5) * size[0];
      pPos[i * 3 + 1] = (Math.random() - 0.5) * size[1];
      pPos[i * 3 + 2] = (Math.random() - 0.5) * size[2];
    }
    pGeo.setAttribute('position', new THREE.BufferAttribute(pPos, 3));
    const pMat = new THREE.PointsMaterial({
      size: 1.5,
      color: 0x38bdf8,
      transparent: true,
      opacity: 0.65,
      depthWrite: false,
    });
    const particles = new THREE.Points(pGeo, pMat);
    group.add(particles);

    box.setFromCenterAndSize(group.position, new THREE.Vector3(...size));

    const force = data.windForce || [12, 0, 0];
    const update = (delta: number) => {
      const positions = pGeo.attributes.position.array as Float32Array;
      for (let i = 0; i < pCount; i++) {
        positions[i * 3] += force[0] * delta * 2.5;
        if (Math.abs(positions[i * 3]) > size[0] / 2) {
          positions[i * 3] = -Math.sign(force[0]) * (size[0] / 2);
        }
      }
      pGeo.attributes.position.needsUpdate = true;
    };

    return { group, data, box, update };
  } else {
    const size = data.size || [6, 6, 6];
    group.position.set(...data.position);

    const dGeo = new THREE.DodecahedronGeometry(size[0] / 2, 0);
    const dMat = new THREE.MeshStandardMaterial({
      color: 0x475569,
      metalness: 0.8,
      roughness: 0.4,
    });
    const dMesh = new THREE.Mesh(dGeo, dMat);
    group.add(dMesh);

    box.setFromCenterAndSize(group.position, new THREE.Vector3(...size));

    const update = (delta: number) => {
      dMesh.rotation.x += delta * 0.8;
      dMesh.rotation.y += delta * 1.2;
    };

    return { group, data, box, update };
  }
}

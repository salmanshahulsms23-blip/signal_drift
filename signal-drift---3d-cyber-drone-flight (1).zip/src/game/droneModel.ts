import * as THREE from 'three';

export interface DroneObject {
  group: THREE.Group;
  rotors: THREE.Mesh[];
  thrusterGlows: THREE.Mesh[];
  thrusterLight: THREE.PointLight;
  headlight: THREE.SpotLight;
  headlightTarget: THREE.Object3D;
  update: (delta: number, throttle: number, isBoosting: boolean) => void;
  setCosmetics: (skinId: string, engineColorName: string) => void;
}

const SKIN_CONFIGS: Record<string, { hull: number; accent: number }> = {
  starter: { hull: 0x181e29, accent: 0x00f0ff },
  neon_scout: { hull: 0x111827, accent: 0xec4899 },
  solar_glider: { hull: 0x27272a, accent: 0xf59e0b },
  phantom_wing: { hull: 0x09090b, accent: 0xef4444 },
  aurora_runner: { hull: 0x064e3b, accent: 0x10b981 },
  quantum_drift: { hull: 0x0f172a, accent: 0x06b6d4 },
  signal_master: { hull: 0x1e1b4b, accent: 0xa855f7 },
};

const ENGINE_COLORS: Record<string, number> = {
  cyan: 0x00f0ff,
  magenta: 0xff00aa,
  amber: 0xf59e0b,
  emerald: 0x10b981,
  violet: 0x8b5cf6,
  crimson: 0xef4444,
};

export function createDroneModel(initialSkin: string = 'starter', initialEngineColor: string = 'cyan'): DroneObject {
  const group = new THREE.Group();

  const skinConf = SKIN_CONFIGS[initialSkin] || SKIN_CONFIGS.starter;
  let activeEngineHex = ENGINE_COLORS[initialEngineColor] || 0x00f0ff;

  // Materials with varied roughness and metalness for authentic PBR composite look
  const carbonHullMat = new THREE.MeshStandardMaterial({
    color: skinConf.hull,
    metalness: 0.85,
    roughness: 0.25,
  });

  const darkTrimMat = new THREE.MeshStandardMaterial({
    color: 0x0a0d14,
    metalness: 0.6,
    roughness: 0.6,
  });

  const neonAccentMat = new THREE.MeshStandardMaterial({
    color: skinConf.accent,
    emissive: skinConf.accent,
    emissiveIntensity: 1.5,
    roughness: 0.2,
    metalness: 0.8,
  });

  const thrusterMat = new THREE.MeshStandardMaterial({
    color: activeEngineHex,
    emissive: activeEngineHex,
    emissiveIntensity: 1.8,
    roughness: 0.2,
    metalness: 0.8,
  });

  const visorMat = new THREE.MeshPhysicalMaterial({
    color: 0x002233,
    emissive: 0x005577,
    emissiveIntensity: 0.8,
    metalness: 0.95,
    roughness: 0.1,
    clearcoat: 1.0,
    clearcoatRoughness: 0.1,
  });

  const rotorMat = new THREE.MeshStandardMaterial({
    color: 0x334155,
    metalness: 0.7,
    roughness: 0.4,
  });

  // 1. PRIMARY SILHOUETTE: Central Fuselage Core
  const hullGeo = new THREE.CylinderGeometry(0.55, 0.75, 0.45, 8);
  hullGeo.rotateY(Math.PI / 8);
  hullGeo.scale(1.2, 0.9, 1.8);
  const hullMesh = new THREE.Mesh(hullGeo, carbonHullMat);
  hullMesh.castShadow = true;
  hullMesh.receiveShadow = true;
  group.add(hullMesh);

  // Upper cowl / spine
  const spineGeo = new THREE.BoxGeometry(0.45, 0.18, 1.4);
  const spineMesh = new THREE.Mesh(spineGeo, darkTrimMat);
  spineMesh.position.set(0, 0.22, -0.1);
  spineMesh.castShadow = true;
  group.add(spineMesh);

  // 2. ACCENT: Front Cockpit Visor / Optical Sensor Dome
  const visorGeo = new THREE.ConeGeometry(0.35, 0.6, 6);
  visorGeo.rotateX(-Math.PI / 2);
  const visorMesh = new THREE.Mesh(visorGeo, visorMat);
  visorMesh.position.set(0, 0.1, -0.95);
  visorMesh.scale.set(1.1, 0.7, 1.1);
  group.add(visorMesh);

  // Visor glowing scanner strip
  const scannerGeo = new THREE.BoxGeometry(0.3, 0.04, 0.1);
  const scannerMesh = new THREE.Mesh(scannerGeo, neonAccentMat);
  scannerMesh.position.set(0, 0.12, -1.02);
  group.add(scannerMesh);

  // 3. SECONDARY READ: 4 Quadcopter Diagonal Boom Arms
  const armLength = 1.4;
  const armAngle = 0.65;
  const armCoords = [
    { x: -armLength * Math.sin(armAngle), z: -armLength * Math.cos(armAngle), isFront: true },
    { x: armLength * Math.sin(armAngle), z: -armLength * Math.cos(armAngle), isFront: true },
    { x: -armLength * Math.sin(armAngle), z: armLength * Math.cos(armAngle), isFront: false },
    { x: armLength * Math.sin(armAngle), z: armLength * Math.cos(armAngle), isFront: false },
  ];

  const rotors: THREE.Mesh[] = [];

  armCoords.forEach((coord) => {
    // Boom arm tube/strut
    const armGeo = new THREE.CylinderGeometry(0.045, 0.055, armLength, 6);
    armGeo.rotateZ(Math.PI / 2);
    const armMesh = new THREE.Mesh(armGeo, darkTrimMat);
    armMesh.position.set(coord.x * 0.5, 0.02, coord.z * 0.5);
    armMesh.lookAt(coord.x, 0.02, coord.z);
    armMesh.rotateY(Math.PI / 2);
    armMesh.castShadow = true;
    group.add(armMesh);

    // Motor Hub / Nacelle
    const nacelleGeo = new THREE.CylinderGeometry(0.14, 0.16, 0.22, 10);
    const nacelleMesh = new THREE.Mesh(nacelleGeo, carbonHullMat);
    nacelleMesh.position.set(coord.x, 0.06, coord.z);
    nacelleMesh.castShadow = true;
    group.add(nacelleMesh);

    // Motor ring accent
    const ringGeo = new THREE.TorusGeometry(0.15, 0.02, 6, 16);
    ringGeo.rotateX(Math.PI / 2);
    const ringMesh = new THREE.Mesh(ringGeo, neonAccentMat);
    ringMesh.position.set(coord.x, 0.15, coord.z);
    group.add(ringMesh);

    // Rotor Blades (cross shape with 3 beveled blades)
    const rotorGroup = new THREE.Group();
    rotorGroup.position.set(coord.x, 0.18, coord.z);

    const bladeGeo = new THREE.BoxGeometry(0.75, 0.015, 0.08);
    const blade1 = new THREE.Mesh(bladeGeo, rotorMat);
    const blade2 = new THREE.Mesh(bladeGeo, rotorMat);
    blade2.rotateY(Math.PI / 2);

    rotorGroup.add(blade1);
    rotorGroup.add(blade2);

    group.add(rotorGroup);
    rotors.push(rotorGroup as unknown as THREE.Mesh);
  });

  // 4. ACCENT: Dual Rear Plasma Thruster Cones
  const thrusterGlows: THREE.Mesh[] = [];
  [-0.26, 0.26].forEach((xOff) => {
    const housingGeo = new THREE.CylinderGeometry(0.12, 0.15, 0.35, 8);
    housingGeo.rotateX(Math.PI / 2);
    const housing = new THREE.Mesh(housingGeo, darkTrimMat);
    housing.position.set(xOff, 0.02, 0.95);
    housing.castShadow = true;
    group.add(housing);

    // Inner glowing jet cone
    const jetGeo = new THREE.ConeGeometry(0.1, 0.35, 8);
    jetGeo.rotateX(-Math.PI / 2);
    const jetGlow = new THREE.Mesh(jetGeo, thrusterMat);
    jetGlow.position.set(xOff, 0.02, 1.08);
    group.add(jetGlow);
    thrusterGlows.push(jetGlow);
  });

  // 5. ACCENT: Landing Skids
  [-0.45, 0.45].forEach((xOff) => {
    const skidGeo = new THREE.CylinderGeometry(0.03, 0.03, 1.2, 6);
    skidGeo.rotateX(Math.PI / 2);
    const skid = new THREE.Mesh(skidGeo, darkTrimMat);
    skid.position.set(xOff, -0.32, -0.05);
    group.add(skid);

    const strutFGeo = new THREE.CylinderGeometry(0.025, 0.025, 0.3, 6);
    const strutF = new THREE.Mesh(strutFGeo, darkTrimMat);
    strutF.position.set(xOff, -0.16, -0.4);
    group.add(strutF);

    const strutR = new THREE.Mesh(strutFGeo, darkTrimMat);
    strutR.position.set(xOff, -0.16, 0.3);
    group.add(strutR);
  });

  // Dynamic Lighting attached to drone
  const thrusterLight = new THREE.PointLight(activeEngineHex, 1.2, 12);
  thrusterLight.position.set(0, 0, 1.4);
  group.add(thrusterLight);

  const headlight = new THREE.SpotLight(0xecfeff, 3.5, 45, Math.PI / 5, 0.3, 1.0);
  headlight.position.set(0, 0.1, -1.0);
  const headlightTarget = new THREE.Object3D();
  headlightTarget.position.set(0, -0.5, -20);
  group.add(headlight);
  group.add(headlightTarget);
  headlight.target = headlightTarget;

  // Propeller spin & thruster pulsation update
  let rotorAngle = 0;
  const update = (delta: number, throttle: number, isBoosting: boolean) => {
    const baseRotorSpeed = 25;
    const activeSpeed = baseRotorSpeed + throttle * 45 + (isBoosting ? 65 : 0);
    rotorAngle += activeSpeed * delta;

    rotors.forEach((rotor, idx) => {
      const dir = idx % 2 === 0 ? 1 : -1;
      rotor.rotation.y = rotorAngle * dir;
    });

    // Pulse thruster glows and light when boosting
    const boostScale = isBoosting ? 2.4 + Math.sin(Date.now() * 0.03) * 0.4 : 1.0;
    thrusterGlows.forEach((glow) => {
      glow.scale.set(boostScale, boostScale, isBoosting ? 2.8 : 1.0);
    });

    thrusterLight.intensity = isBoosting ? 3.8 : 1.0;
  };

  const setCosmetics = (skinId: string, engineColorName: string) => {
    const conf = SKIN_CONFIGS[skinId] || SKIN_CONFIGS.starter;
    const hex = ENGINE_COLORS[engineColorName] || 0x00f0ff;
    activeEngineHex = hex;

    carbonHullMat.color.setHex(conf.hull);
    neonAccentMat.color.setHex(conf.accent);
    neonAccentMat.emissive.setHex(conf.accent);

    thrusterMat.color.setHex(hex);
    thrusterMat.emissive.setHex(hex);
    thrusterLight.color.setHex(hex);
  };

  return {
    group,
    rotors,
    thrusterGlows,
    thrusterLight,
    headlight,
    headlightTarget,
    update,
    setCosmetics,
  };
}

import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import {
  MissionData,
  LiveFlightStats,
  DroneUpgrades,
  DroneCosmetics,
  TurboState,
} from '../types/game';
import { createDroneModel, DroneObject } from './droneModel';
import {
  createCityEnvironment,
  CityEnvironment,
  createEnergyGate,
  GateMeshObject,
  createSignalTower,
  SignalTowerObject,
  createEnergyCell,
  EnergyCellObject,
  createHazardMesh,
  HazardMeshObject,
} from './cityGenerator';
import { sound } from '../audio/soundEngine';

// Pre-allocated reusable math helpers (Zero Garbage Collection in render loop)
const _v1 = new THREE.Vector3();
const _v2 = new THREE.Vector3();
const _v3 = new THREE.Vector3();

export interface InputState {
  forward: boolean;
  backward: boolean;
  left: boolean;
  right: boolean;
  up: boolean;
  down: boolean;
  boost: boolean;
}

export class GameSceneManager {
  private container: HTMLDivElement;
  private renderer!: THREE.WebGLRenderer;
  private scene!: THREE.Scene;
  private camera!: THREE.PerspectiveCamera;
  private isSoftwareGl: boolean = false;
  private animFrameId: number = 0;
  private isDestroyed: boolean = false;

  // Scene Components
  private cityEnv: CityEnvironment | null = null;
  private drone: DroneObject | null = null;
  private gates: GateMeshObject[] = [];
  private signalTower: SignalTowerObject | null = null;
  private energyCells: EnergyCellObject[] = [];
  private hazards: HazardMeshObject[] = [];

  // Lighting
  private dirLight!: THREE.DirectionalLight;
  private hemiLight!: THREE.HemisphereLight;

  // Drone Kinematics
  private dronePos: THREE.Vector3 = new THREE.Vector3(0, 20, 60);
  private droneVel: THREE.Vector3 = new THREE.Vector3();
  private droneYaw: number = Math.PI;
  private dronePitch: number = 0;
  private droneRoll: number = 0;

  // Flight Parameters
  private readonly maxSpeed: number = 44;
  private readonly boostMultiplier: number = 1.75;
  private baseAccel: number = 65;
  private readonly drag: number = 0.92;
  private readonly turnRate: number = 2.4;

  // Upgrades & Cosmetics configuration
  private upgrades: DroneUpgrades = {
    acceleration: 0,
    batteryCapacity: 0,
    turboEfficiency: 0,
    windResistance: 0,
    hullShield: 0,
    turboRecharge: 0,
  };
  private cosmetics: DroneCosmetics = {
    equippedSkin: 'starter',
    equippedEngineColor: 'cyan',
    equippedPropellerStyle: 'standard',
    equippedBoostTrail: 'cyan_plasma',
    purchasedSkins: ['starter'],
    purchasedEngineColors: ['cyan'],
    purchasedPropellers: ['standard'],
    purchasedTrails: ['cyan_plasma'],
  };

  // Turbo Boost Unlimited System (6s max active, 3s cooldown)
  private turboState: TurboState = 'ready';
  private turboActiveRemaining: number = 6.0;
  private turboCooldownRemaining: number = 0;
  private maxTurboDuration: number = 6.0;
  private baseTurboCooldown: number = 3.0;

  // Game Loop State
  private currentMission: MissionData | null = null;
  private isPlaying: boolean = false;
  private isPreviewMode: boolean = false;
  private previewTimeElapsed: number = 0;
  private currentGateTargetIndex: number = 0;
  private wrongGatesCount: number = 0;
  private collisionCount: number = 0;
  private shieldActive: boolean = false;
  private battery: number = 100;
  private maxBattery: number = 100;
  private health: number = 100;
  private score: number = 0;
  private streak: number = 0;
  private creditsEarned: number = 0;
  private elapsedTime: number = 0;
  private isTowerActivated: boolean = false;

  // Special Mechanics State
  private isQuestionPaused: boolean = false;
  private activeQuestionGateObj: GateMeshObject | null = null;
  private questionTimerRemaining: number | null = null;
  private isBlackoutActive: boolean = false;

  // Camera Shake & FX
  private cameraShake: number = 0;
  private targetFOV: number = 62;

  // Input
  public input: InputState = {
    forward: false,
    backward: false,
    left: false,
    right: false,
    up: false,
    down: false,
    boost: false,
  };

  // Callbacks
  private onStatsUpdate: ((stats: LiveFlightStats) => void) | null = null;
  private onMissionWin: ((score: number, battery: number, time: number, accuracy: number, cells: number, credits: number) => void) | null = null;
  private onMissionFail: ((reason: string) => void) | null = null;

  constructor(container: HTMLDivElement) {
    this.container = container;
    this.initWebGL();
    this.initInputListeners();
    this.startLoop();
  }

  private initWebGL() {
    this.isSoftwareGl = (() => {
      const gl = document.createElement('canvas').getContext('webgl2');
      if (!gl) return true;
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
      const gpu = String(gl.getParameter(param));
      gl.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    })();

    const width = this.container.clientWidth || window.innerWidth;
    const height = this.container.clientHeight || window.innerHeight;

    this.renderer = new THREE.WebGLRenderer({
      antialias: !this.isSoftwareGl,
      powerPreference: 'high-performance',
      alpha: false,
    });
    this.renderer.setSize(width, height);
    this.renderer.setPixelRatio(this.isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.15;
    this.renderer.shadowMap.enabled = !this.isSoftwareGl;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    this.container.appendChild(this.renderer.domElement);

    this.scene = new THREE.Scene();
    this.camera = new THREE.PerspectiveCamera(62, width / height, 0.5, 900);
    this.camera.position.set(0, 30, 80);

    const pmremGenerator = new THREE.PMREMGenerator(this.renderer);
    this.scene.environment = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
    pmremGenerator.dispose();

    this.hemiLight = new THREE.HemisphereLight(0x38bdf8, 0x0f172a, 0.7);
    this.scene.add(this.hemiLight);

    this.dirLight = new THREE.DirectionalLight(0xfff7ed, 1.8);
    this.dirLight.position.set(60, 120, 80);
    this.dirLight.castShadow = !this.isSoftwareGl;
    if (this.dirLight.shadow) {
      this.dirLight.shadow.mapSize.width = 1024;
      this.dirLight.shadow.mapSize.height = 1024;
      this.dirLight.shadow.camera.near = 10;
      this.dirLight.shadow.camera.far = 400;
      const d = 120;
      this.dirLight.shadow.camera.left = -d;
      this.dirLight.shadow.camera.right = d;
      this.dirLight.shadow.camera.top = d;
      this.dirLight.shadow.camera.bottom = -d;
      this.dirLight.shadow.bias = -0.0005;
      this.dirLight.shadow.normalBias = 0.02;
    }
    this.scene.add(this.dirLight);

    this.scene.fog = new THREE.FogExp2(0x0f172a, 0.0035);

    this.drone = createDroneModel(this.cosmetics.equippedSkin, this.cosmetics.equippedEngineColor);
    this.scene.add(this.drone.group);

    window.addEventListener('resize', this.handleResize);
  }

  private handleResize = () => {
    if (!this.container || !this.renderer || !this.camera) return;
    const w = this.container.clientWidth || window.innerWidth;
    const h = this.container.clientHeight || window.innerHeight;
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(w, h);
  };

  private initInputListeners() {
    window.addEventListener('keydown', this.handleKeyDown);
    window.addEventListener('keyup', this.handleKeyUp);
    window.addEventListener('blur', this.handleBlur);
  }

  private handleKeyDown = (e: KeyboardEvent) => {
    switch (e.code) {
      case 'KeyW':
      case 'ArrowUp':
        this.input.forward = true;
        break;
      case 'KeyS':
      case 'ArrowDown':
        // PART 6: S and Down Arrow = descend
        this.input.down = true;
        break;
      case 'KeyA':
      case 'ArrowLeft':
        this.input.left = true;
        break;
      case 'KeyD':
      case 'ArrowRight':
        this.input.right = true;
        break;
      case 'Space':
        this.input.up = true;
        break;
      case 'KeyC':
      case 'ControlLeft':
      case 'ControlRight':
        this.input.down = true;
        break;
      case 'ShiftLeft':
      case 'ShiftRight':
        this.input.boost = true;
        break;
    }
  };

  private handleKeyUp = (e: KeyboardEvent) => {
    switch (e.code) {
      case 'KeyW':
      case 'ArrowUp':
        this.input.forward = false;
        break;
      case 'KeyS':
      case 'ArrowDown':
        this.input.down = false;
        break;
      case 'KeyA':
      case 'ArrowLeft':
        this.input.left = false;
        break;
      case 'KeyD':
      case 'ArrowRight':
        this.input.right = false;
        break;
      case 'Space':
        this.input.up = false;
        break;
      case 'KeyC':
      case 'ControlLeft':
      case 'ControlRight':
        this.input.down = false;
        break;
      case 'ShiftLeft':
      case 'ShiftRight':
        this.input.boost = false;
        break;
    }
  };

  private handleBlur = () => {
    this.input.forward = false;
    this.input.backward = false;
    this.input.left = false;
    this.input.right = false;
    this.input.up = false;
    this.input.down = false;
    this.input.boost = false;
  };

  // --- CONFIGURATION UPDATES ---

  public updateProfileEquipment(upgrades: DroneUpgrades, cosmetics: DroneCosmetics) {
    this.upgrades = upgrades;
    this.cosmetics = cosmetics;

    // Apply Acceleration upgrade (+15% per tier)
    this.baseAccel = 65 * (1 + (upgrades.acceleration || 0) * 0.15);

    // Apply Battery Capacity (+15% per tier)
    this.maxBattery = 100 * (1 + (upgrades.batteryCapacity || 0) * 0.15);
    this.battery = this.maxBattery;

    // Apply Shield
    this.shieldActive = (upgrades.hullShield || 0) > 0;

    // Apply Turbo Recharge upgrade
    this.baseTurboCooldown = 3.0 * Math.max(0.6, 1 - (upgrades.turboRecharge || 0) * 0.08);

    // Apply 3D Cosmetics to Drone Model
    if (this.drone) {
      this.drone.setCosmetics(cosmetics.equippedSkin, cosmetics.equippedEngineColor);
    }
  }

  // --- MISSION LIFECYCLE ---

  public loadMission(mission: MissionData) {
    this.currentMission = mission;
    this.clearLevelObjects();

    this.cityEnv = createCityEnvironment(mission.skyTheme, mission.hasStorm);
    this.scene.add(this.cityEnv.group);

    this.gates = mission.gates.map((g) => {
      const gateObj = createEnergyGate({ ...g });
      this.scene.add(gateObj.group);
      return gateObj;
    });

    this.signalTower = createSignalTower(mission.towerPosition);
    this.scene.add(this.signalTower.group);

    this.energyCells = mission.energyCells.map((pos) => {
      const cellObj = createEnergyCell(pos);
      this.scene.add(cellObj.group);
      return cellObj;
    });

    this.hazards = mission.hazards.map((h) => {
      const hObj = createHazardMesh(h);
      this.scene.add(hObj.group);
      return hObj;
    });

    // Reset Flight State
    this.dronePos.set(...mission.droneStart);
    this.droneVel.set(0, 0, 0);
    this.droneYaw = mission.droneStartRotY;
    this.dronePitch = 0;
    this.droneRoll = 0;

    if (this.drone) {
      this.drone.group.position.copy(this.dronePos);
      this.drone.group.rotation.set(0, this.droneYaw, 0);
    }

    this.camera.position.set(
      this.dronePos.x + Math.sin(this.droneYaw) * 16,
      this.dronePos.y + 6,
      this.dronePos.z + Math.cos(this.droneYaw) * 16
    );
    this.camera.lookAt(this.dronePos);

    // Reset gameplay trackers
    this.currentGateTargetIndex = 0;
    this.wrongGatesCount = 0;
    this.collisionCount = 0;
    this.shieldActive = (this.upgrades.hullShield || 0) > 0;
    this.maxBattery = 100 * (1 + (this.upgrades.batteryCapacity || 0) * 0.15);
    this.battery = this.maxBattery;
    this.health = 100;
    this.score = 0;
    this.streak = 0;
    this.creditsEarned = 0;
    this.elapsedTime = 0;
    this.isTowerActivated = false;
    this.isPreviewMode = false;
    this.previewTimeElapsed = 0;
    this.isPlaying = false;
    this.isQuestionPaused = false;
    this.activeQuestionGateObj = null;
    this.questionTimerRemaining = null;
    this.isBlackoutActive = !!mission.isBlackout;

    // Reset Turbo
    this.turboState = 'ready';
    this.turboActiveRemaining = this.maxTurboDuration;
    this.turboCooldownRemaining = 0;
  }

  public setMenuMode() {
    this.isPreviewMode = false;
    this.isPlaying = false;
    sound.stopEngine();
  }

  public startPreview() {
    this.isPreviewMode = true;
    this.previewTimeElapsed = 0;
    this.isPlaying = false;
  }

  public startGameplay() {
    this.isPreviewMode = false;
    this.isPlaying = true;

    // Check for Gate Swap mechanic (Mission 17)
    if (this.currentMission?.hasGateSwap) {
      this.executeGateSwap();
    }

    sound.startEngine();
  }

  private executeGateSwap() {
    const swapA = this.gates.find((g) => g.data.id === 'm17_g2');
    const swapB = this.gates.find((g) => g.data.id === 'm17_g4');
    if (swapA && swapB) {
      const posA = [...swapA.data.position] as [number, number, number];
      const posB = [...swapB.data.position] as [number, number, number];
      swapA.teleportTo(posB);
      swapB.teleportTo(posA);
      sound.playWrongGate();
    }
  }

  public pauseGameplay() {
    this.isPlaying = false;
    sound.stopEngine();
  }

  public resumeGameplay() {
    if (!this.isQuestionPaused) {
      this.isPlaying = true;
      sound.startEngine();
    }
  }

  public setCallbacks(
    onStats: (stats: LiveFlightStats) => void,
    onWin: (score: number, battery: number, time: number, accuracy: number, cells: number, credits: number) => void,
    onFail: (reason: string) => void
  ) {
    this.onStatsUpdate = onStats;
    this.onMissionWin = onWin;
    this.onMissionFail = onFail;
  }

  private clearLevelObjects() {
    if (this.cityEnv) {
      this.scene.remove(this.cityEnv.group);
      this.cityEnv = null;
    }
    this.gates.forEach((g) => this.scene.remove(g.group));
    this.gates = [];
    if (this.signalTower) {
      this.scene.remove(this.signalTower.group);
      this.signalTower = null;
    }
    this.energyCells.forEach((c) => this.scene.remove(c.group));
    this.energyCells = [];
    this.hazards.forEach((h) => this.scene.remove(h.group));
    this.hazards = [];
  }

  // --- RENDER & SIMULATION LOOP ---
  private startLoop() {
    let lastTime = performance.now();

    const tick = (now: number) => {
      if (this.isDestroyed) return;

      const rawDelta = (now - lastTime) / 1000;
      lastTime = now;
      const delta = Math.min(rawDelta, 0.05);

      this.updateSimulation(delta);
      this.renderer.render(this.scene, this.camera);

      this.animFrameId = requestAnimationFrame(tick);
    };

    this.animFrameId = requestAnimationFrame(tick);
  }

  private updateSimulation(delta: number) {
    if (this.cityEnv) {
      this.cityEnv.update(delta);
    }

    this.hazards.forEach((h) => h.update(delta, this.dronePos));
    this.energyCells.forEach((c) => c.update(delta));

    // Update Gates
    this.gates.forEach((g, idx) => {
      if (g && g.data) {
        const isTarget = idx === this.currentGateTargetIndex;
        g.update(delta, isTarget, this.isPreviewMode);
      }
    });

    // Update Signal Tower
    if (this.signalTower) {
      const nonDecoys = this.gates.filter((g) => g && g.data && !g.data.isDecoy);
      const isAllGatesPassed = this.currentGateTargetIndex >= nonDecoys.length;
      this.signalTower.update(delta, isAllGatesPassed);
    }

    if (this.isPreviewMode) {
      this.updatePreviewCamera(delta);
      return;
    }

    if (!this.isPlaying || this.isQuestionPaused) {
      if (!this.isQuestionPaused) {
        this.updateMenuOrbitCamera(delta);
      }
      return;
    }

    // --- ACTIVE FLIGHT PHYSICS ---
    this.elapsedTime += delta;

    // Check Blackout Threshold
    if (this.currentMission?.isBlackout) {
      const threshold = this.currentMission.blackoutGateThreshold || 3;
      this.isBlackoutActive = this.currentGateTargetIndex < threshold;
    }

    // --- TURBO BOOST SYSTEM (Part 5) ---
    // Max 6s active, 3s cooldown, unlimited use
    let isBoosting = false;
    if (this.turboState === 'ready') {
      if (this.input.boost && this.battery > 5) {
        this.turboState = 'active';
        this.turboActiveRemaining = this.maxTurboDuration;
        isBoosting = true;
        sound.playBoost();
      }
    } else if (this.turboState === 'active') {
      if (this.input.boost && this.turboActiveRemaining > 0 && this.battery > 5) {
        isBoosting = true;
        this.turboActiveRemaining -= delta;
        if (this.turboActiveRemaining <= 0) {
          // Reached 6s limit: stop and enter cooldown
          this.turboState = 'cooldown';
          this.turboCooldownRemaining = this.baseTurboCooldown;
        }
      } else {
        // Player released boost early: enters cooldown immediately
        this.turboState = 'cooldown';
        this.turboCooldownRemaining = this.baseTurboCooldown;
      }
    } else if (this.turboState === 'cooldown') {
      this.turboCooldownRemaining -= delta;
      if (this.turboCooldownRemaining <= 0) {
        this.turboState = 'ready';
        this.turboActiveRemaining = this.maxTurboDuration;
      }
    }

    // A. Drone Steering & Rotation
    if (this.input.left) {
      this.droneYaw += this.turnRate * delta;
      this.droneRoll = THREE.MathUtils.damp(this.droneRoll, 0.45, 12, delta);
    } else if (this.input.right) {
      this.droneYaw -= this.turnRate * delta;
      this.droneRoll = THREE.MathUtils.damp(this.droneRoll, -0.45, 12, delta);
    } else {
      this.droneRoll = THREE.MathUtils.damp(this.droneRoll, 0, 10, delta);
    }

    if (this.input.forward) {
      this.dronePitch = THREE.MathUtils.damp(this.dronePitch, 0.28, 10, delta);
    } else {
      this.dronePitch = THREE.MathUtils.damp(this.dronePitch, 0, 8, delta);
    }

    // B. Thrust Acceleration
    const heading = _v1.set(-Math.sin(this.droneYaw), 0, -Math.cos(this.droneYaw));
    if (this.input.forward) {
      this.droneVel.addScaledVector(heading, this.baseAccel * delta);
    }

    // Vertical lift & descent (PART 6: S/Down Arrow = descend, Space = lift)
    if (this.input.up) {
      this.droneVel.y += (this.baseAccel * 0.75) * delta;
    } else if (this.input.down) {
      this.droneVel.y -= (this.baseAccel * 0.75) * delta;
    }

    // Apply drag/air friction
    this.droneVel.x *= Math.pow(this.drag, delta * 60);
    this.droneVel.y *= Math.pow(0.88, delta * 60);
    this.droneVel.z *= Math.pow(this.drag, delta * 60);

    // Limit maximum velocity
    const speedLimit = this.maxSpeed * (isBoosting ? this.boostMultiplier : 1.0);
    if (this.droneVel.length() > speedLimit) {
      this.droneVel.normalize().multiplyScalar(speedLimit);
    }

    // C. Wind Hazard Influence (mitigated by windResistance upgrade)
    const windResistanceMult = Math.max(0.2, 1 - (this.upgrades.windResistance || 0) * 0.2);
    this.hazards.forEach((h) => {
      if (h.data.type === 'wind_zone' && h.box.containsPoint(this.dronePos)) {
        const force = h.data.windForce || [12, 0, 0];
        this.droneVel.x += force[0] * delta * windResistanceMult;
        this.droneVel.y += force[1] * delta * windResistanceMult;
        this.droneVel.z += force[2] * delta * windResistanceMult;
      }
    });

    // Move drone
    this.dronePos.addScaledVector(this.droneVel, delta);

    // Altitude boundaries (clamped smoothly between y = 4 and y = 180)
    if (this.dronePos.y < 4) {
      this.dronePos.y = 4;
      this.droneVel.y = 0;
    }
    if (this.dronePos.y > 180) {
      this.dronePos.y = 180;
      this.droneVel.y = 0;
    }

    // Update drone mesh transformations
    if (this.drone) {
      this.drone.group.position.copy(this.dronePos);
      this.drone.group.rotation.set(0, 0, 0);
      this.drone.group.rotateY(this.droneYaw);
      this.drone.group.rotateX(this.dronePitch);
      this.drone.group.rotateZ(this.droneRoll);

      const currentSpeed = this.droneVel.length();
      const throttleRatio = currentSpeed / this.maxSpeed;
      this.drone.update(delta, throttleRatio, isBoosting);

      sound.updateEnginePitch(throttleRatio, isBoosting);
    }

    // D. Battery Drain Calculation (with turbo efficiency upgrade)
    const turboEfficiencyMult = Math.max(0.3, 1 - (this.upgrades.turboEfficiency || 0) * 0.15);
    const drainRate = (this.currentMission?.batteryDrainRate || 1.0) * (isBoosting ? 2.5 * turboEfficiencyMult : 1.0);
    this.battery = Math.max(0, this.battery - drainRate * delta);
    if (this.battery <= 0) {
      this.handleGameOver('Battery Exhausted');
      return;
    }

    // E. Timer Check
    const timeLimit = this.currentMission?.timeLimit || 90;
    if (this.elapsedTime >= timeLimit) {
      this.handleGameOver('Time Limit Reached');
      return;
    }

    // F. Collisions Detection
    this.checkCollisions(delta);

    // G. Energy Gate Check
    this.checkEnergyGates();

    // H. Timed Gate Timeout Check (Missions 8-10, 20)
    this.checkTimedGateExpiration();

    // I. Energy Cell Pickups Check
    this.checkEnergyCells();

    // J. Signal Tower Uplink Check
    this.checkSignalTower();

    // K. Chase Camera Follow
    this.updateChaseCamera(delta, isBoosting);

    // L. Broadcast live stats
    this.broadcastStats(timeLimit, isBoosting);
  }

  // --- COLLISION RESOLUTION ---
  private checkCollisions(delta: number) {
    const droneSphere = new THREE.Sphere(this.dronePos, 1.8);

    if (this.cityEnv) {
      for (const box of this.cityEnv.collisionBoxes) {
        if (box.intersectsSphere(droneSphere)) {
          this.triggerCollisionImpact('Building Impact');
          break;
        }
      }
    }

    for (const h of this.hazards) {
      if (!h.box.isEmpty() && h.box.intersectsSphere(droneSphere)) {
        if (h.data.type === 'patrol_drone') {
          this.triggerCollisionImpact('Patrol Drone Collision');
        } else if (h.data.type === 'security_chaser') {
          this.triggerCollisionImpact('Security Drone Intercept');
        } else if (h.data.type === 'laser_beam') {
          this.triggerCollisionImpact('Defense Laser Damage');
        } else if (h.data.type === 'floating_debris') {
          this.triggerCollisionImpact('Debris Collision');
        }
        break;
      }
    }
  }

  private triggerCollisionImpact(reason: string) {
    this.collisionCount++;

    // Check if Shield absorbs the hit
    if (this.shieldActive) {
      this.shieldActive = false;
      this.cameraShake = 0.8;
      sound.playGateCleared(0);
      this.droneVel.multiplyScalar(-0.4);
      return;
    }

    this.cameraShake = 1.4;
    this.health = Math.max(0, this.health - 22);
    this.score = Math.max(0, this.score - 150);
    this.streak = 0;

    this.droneVel.multiplyScalar(-0.6);
    this.dronePos.addScaledVector(this.droneVel, 0.1);

    sound.playCollision();

    if (this.health <= 0) {
      this.handleGameOver('Hull Critical: Structural Failure');
    }
  }

  // --- GATE SEQUENCE CHECK ---
  private checkEnergyGates() {
    if (!this.gates || this.gates.length === 0) return;
    const nonDecoyGates = this.gates.filter((g) => g && g.data && !g.data.isDecoy);

    this.gates.forEach((gateObj) => {
      if (!gateObj || !gateObj.data || gateObj.passed) return;

      const gatePos = _v1.set(...gateObj.data.position);
      const dist = this.dronePos.distanceTo(gatePos);

      if (dist < gateObj.data.radius + 1.2) {
        const gateNormal = _v2.set(0, 0, 1).applyAxisAngle(_v3.set(0, 1, 0), gateObj.data.rotationY);
        const relPos = _v3.copy(this.dronePos).sub(gatePos);
        const planeDist = Math.abs(relPos.dot(gateNormal));

        if (planeDist < 2.5) {
          const expectedTarget = nonDecoyGates[this.currentGateTargetIndex];

          if (gateObj === expectedTarget) {
            // Check if this is a QUESTION GATE (Missions 11-13, 20)
            if (gateObj.data.isQuestionGate && gateObj.data.question) {
              this.triggerQuestionGate(gateObj);
              return;
            }

            // Normal gate cleared in sequence!
            gateObj.triggerPassEffect(true);
            this.currentGateTargetIndex++;
            this.streak++;
            const gatePoints = 500 + this.streak * 150;
            this.score += gatePoints;
            this.creditsEarned += 25;
            sound.playGateCleared(this.currentGateTargetIndex);

            if (this.currentGateTargetIndex >= nonDecoyGates.length) {
              sound.playCountdownBeep(true);
            }
          } else {
            // Wrong gate or decoy hit!
            gateObj.triggerPassEffect(false);
            this.wrongGatesCount++;
            this.streak = 0;
            this.score = Math.max(0, this.score - 250);
            this.cameraShake = 0.8;
            sound.playWrongGate();
          }
        }
      }
    });
  }

  // --- QUESTION GATE HANDLER (Missions 11-13, 20) ---
  private triggerQuestionGate(gateObj: GateMeshObject) {
    this.isQuestionPaused = true;
    this.activeQuestionGateObj = gateObj;
    this.droneVel.set(0, 0, 0);
    sound.stopEngine();

    if (gateObj.data.question?.timeLimit) {
      this.questionTimerRemaining = gateObj.data.question.timeLimit;
    } else {
      this.questionTimerRemaining = null;
    }
  }

  public submitQuestionAnswer(selectedIndex: number) {
    if (!this.activeQuestionGateObj || !this.activeQuestionGateObj.data.question) return;

    const q = this.activeQuestionGateObj.data.question;
    const isCorrect = selectedIndex === q.correctIndex;

    this.activeQuestionGateObj.triggerPassEffect(isCorrect);

    if (isCorrect) {
      this.score += 650;
      this.creditsEarned += 100;
      this.currentGateTargetIndex++;
      this.streak++;
      sound.playGateCleared(this.currentGateTargetIndex);
    } else {
      this.score = Math.max(0, this.score - 200);
      this.battery = Math.max(5, this.battery - 12);
      this.currentGateTargetIndex++;
      sound.playWrongGate();
    }

    this.isQuestionPaused = false;
    this.activeQuestionGateObj = null;
    this.questionTimerRemaining = null;
    sound.startEngine();
  }

  // --- TIMED GATE TIMEOUT CHECK (Missions 8-10, 20) ---
  private checkTimedGateExpiration() {
    const nonDecoyGates = this.gates.filter((g) => g && g.data && !g.data.isDecoy);
    const activeTarget = nonDecoyGates[this.currentGateTargetIndex];

    if (activeTarget && activeTarget.data.isTimed && !activeTarget.passed) {
      if (activeTarget.timedSecondsLeft <= 0) {
        // Timed out: teleport gate to fair relocation target or jitter, apply short score penalty
        this.score = Math.max(0, this.score - 200);
        sound.playWrongGate();
        const fallbackTarget = activeTarget.data.teleportTarget || [
          activeTarget.data.position[0] + 15,
          activeTarget.data.position[1] + 4,
          activeTarget.data.position[2] - 25,
        ];
        activeTarget.teleportTo(fallbackTarget as [number, number, number]);
      }
    }
  }

  // --- ENERGY CELL PICKUPS ---
  private checkEnergyCells() {
    this.energyCells.forEach((cell) => {
      if (cell.collected) return;

      const cellPos = _v1.set(...cell.position);
      if (this.dronePos.distanceTo(cellPos) < 3.2) {
        cell.collect();
        this.battery = Math.min(this.maxBattery, this.battery + 28);
        this.score += 350;
        this.creditsEarned += 25;
        sound.playEnergyPickup();
      }
    });
  }

  // --- SIGNAL TOWER UPLINK ---
  private checkSignalTower() {
    if (!this.signalTower || this.isTowerActivated) return;

    const nonDecoyGates = this.gates.filter((g) => g && g.data && !g.data.isDecoy);
    const isAllGatesPassed = this.currentGateTargetIndex >= nonDecoyGates.length;

    if (isAllGatesPassed && this.signalTower.uplinkZone.containsPoint(this.dronePos)) {
      this.isTowerActivated = true;
      this.signalTower.activate();
      sound.playTowerActivation();

      setTimeout(() => {
        sound.playMissionSuccess();
        const accuracy = Math.round(
          (nonDecoyGates.length / (nonDecoyGates.length + this.wrongGatesCount)) * 100
        );
        const collectedCells = this.energyCells.filter((c) => c.collected).length;
        const totalCredits = this.creditsEarned + (accuracy === 100 ? 150 : 75) + 100;

        this.onMissionWin?.(
          this.score,
          Math.round((this.battery / this.maxBattery) * 100),
          Math.round(this.elapsedTime),
          accuracy,
          collectedCells,
          totalCredits
        );
      }, 1400);
    }
  }

  // --- CHASE CAMERA ---
  private updateChaseCamera(delta: number, isBoosting: boolean) {
    const camDist = isBoosting ? 13.5 : 11.0;
    const camHeight = isBoosting ? 4.2 : 3.6;

    const backOffset = _v1.set(
      Math.sin(this.droneYaw) * camDist,
      camHeight,
      Math.cos(this.droneYaw) * camDist
    );

    const targetCamPos = _v2.copy(this.dronePos).add(backOffset);

    this.camera.position.x = THREE.MathUtils.damp(this.camera.position.x, targetCamPos.x, 14, delta);
    this.camera.position.y = THREE.MathUtils.damp(this.camera.position.y, targetCamPos.y, 14, delta);
    this.camera.position.z = THREE.MathUtils.damp(this.camera.position.z, targetCamPos.z, 14, delta);

    if (this.cameraShake > 0) {
      this.camera.position.x += (Math.random() - 0.5) * this.cameraShake;
      this.camera.position.y += (Math.random() - 0.5) * this.cameraShake;
      this.cameraShake = Math.max(0, this.cameraShake - delta * 3.5);
    }

    this.targetFOV = isBoosting ? 74 : 62;
    this.camera.fov = THREE.MathUtils.damp(this.camera.fov, this.targetFOV, 8, delta);
    this.camera.updateProjectionMatrix();

    const lookTarget = _v3.copy(this.dronePos).addScaledVector(
      _v1.set(-Math.sin(this.droneYaw), 0.2, -Math.cos(this.droneYaw)),
      8.0
    );
    this.camera.lookAt(lookTarget);
  }

  // --- CINEMATIC MODES ---
  private updatePreviewCamera(delta: number) {
    this.previewTimeElapsed += delta;
    if (!this.gates || this.gates.length === 0) return;

    const nonDecoyGates = this.gates.filter((g) => g && g.data && !g.data.isDecoy);
    if (nonDecoyGates.length === 0) return;

    const totalGates = nonDecoyGates.length;
    const duration = Math.max(1, this.currentMission?.previewDuration || 4);
    const progress = Math.min(0.999, Math.max(0, this.previewTimeElapsed / duration));
    const gateIdx = Math.min(totalGates - 1, Math.max(0, Math.floor(progress * totalGates)));
    const targetGate = nonDecoyGates[gateIdx];

    if (!targetGate || !targetGate.data || !targetGate.data.position) return;

    const focusPos = _v1.set(...targetGate.data.position);
    const camPos = _v2.copy(focusPos).add(_v3.set(0, 12, 35));

    this.camera.position.lerp(camPos, delta * 3.5);
    this.camera.lookAt(focusPos);
  }

  private updateMenuOrbitCamera(delta: number) {
    const t = performance.now() * 0.0003;
    const radius = 90;
    this.camera.position.set(Math.sin(t) * radius, 38 + Math.cos(t * 1.5) * 8, Math.cos(t) * radius);
    this.camera.lookAt(0, 25, -50);
  }

  private handleGameOver(reason: string) {
    this.isPlaying = false;
    sound.stopEngine();
    sound.playMissionFailed();
    this.onMissionFail?.(reason);
  }

  private broadcastStats(timeLimit: number, isBoosting: boolean) {
    if (!this.onStatsUpdate) return;

    const nonDecoyGates = this.gates.filter((g) => g && g.data && !g.data.isDecoy);
    const totalGates = nonDecoyGates.length;
    const isAllGatesPassed = this.currentGateTargetIndex >= totalGates;

    let targetPos = new THREE.Vector3();
    let targetName = '';
    let timedSecondsLeft: number | null = null;
    let nextReq: { index: number; color: any; symbol: any; label: string } | null = null;

    if (!isAllGatesPassed) {
      const nextGate = nonDecoyGates[this.currentGateTargetIndex];
      if (nextGate) {
        targetPos.set(...nextGate.data.position);
        targetName = nextGate.data.label || `${nextGate.data.color} ${nextGate.data.symbol}`;
        nextReq = {
          index: this.currentGateTargetIndex + 1,
          color: nextGate.data.color,
          symbol: nextGate.data.symbol,
          label: targetName,
        };
        if (nextGate.data.isTimed) {
          timedSecondsLeft = Math.round(nextGate.timedSecondsLeft);
        }
      }
    } else if (this.signalTower) {
      targetPos.set(
        this.signalTower.group.position.x,
        this.signalTower.uplinkZone.max.y,
        this.signalTower.group.position.z
      );
      targetName = 'Restore Signal Tower';
    }

    const distToTarget = this.dronePos.distanceTo(targetPos);

    const toTarget = _v1.copy(targetPos).sub(this.dronePos);
    const targetAngle = Math.atan2(toTarget.x, toTarget.z);
    let relativeAngle = (targetAngle - this.droneYaw) * (180 / Math.PI);
    while (relativeAngle > 180) relativeAngle -= 360;
    while (relativeAngle < -180) relativeAngle += 360;

    const stats: LiveFlightStats = {
      battery: Math.round((this.battery / this.maxBattery) * 100),
      health: Math.round(this.health),
      shieldActive: this.shieldActive,
      score: this.score,
      creditsEarnedThisFlight: this.creditsEarned,
      currentGateIndex: this.currentGateTargetIndex,
      totalGates,
      correctSequence: nonDecoyGates.map((g, i) => ({
        index: i + 1,
        color: g.data.color,
        symbol: g.data.symbol,
        label: g.data.label || `${g.data.color} ${g.data.symbol}`,
      })),
      nextGateRequirement: nextReq,
      wrongGatesHit: this.wrongGatesCount,
      collisionsCount: this.collisionCount,
      cellsCollected: this.energyCells.filter((c) => c.collected).length,
      totalCells: this.energyCells.length,
      elapsedTime: Math.round(this.elapsedTime),
      timeRemaining: Math.max(0, Math.round(timeLimit - this.elapsedTime)),
      speed: Math.round(this.droneVel.length() * 3.6),
      altitude: Math.round(this.dronePos.y),
      isBoosting,
      turboState: this.turboState,
      turboTimeRemaining: Number(this.turboActiveRemaining.toFixed(1)),
      turboCooldownRemaining: Number(this.turboCooldownRemaining.toFixed(1)),
      streak: this.streak,
      nextTargetName: targetName,
      nextTargetDistance: Math.round(distToTarget),
      compassAngle: Math.round(relativeAngle),
      isBlackout: this.isBlackoutActive,
      towerActive: isAllGatesPassed,
      missionStatusText: isAllGatesPassed ? 'TRANSMITTER UNLOCKED - FLY TO TOWER APEX' : 'FLY THROUGH GATES IN SEQUENCE',
      timedGateSecondsLeft: timedSecondsLeft,
      activeQuestionGate: this.isQuestionPaused && this.activeQuestionGateObj?.data.question
        ? {
            question: this.activeQuestionGateObj.data.question.question,
            options: this.activeQuestionGateObj.data.question.options,
            correctIndex: this.activeQuestionGateObj.data.question.correctIndex,
            explanation: this.activeQuestionGateObj.data.question.explanation,
            timeRemaining: this.questionTimerRemaining !== null ? Math.round(this.questionTimerRemaining) : undefined,
          }
        : null,
    };

    this.onStatsUpdate(stats);
  }

  public updateGraphicsQuality(quality: 'low' | 'medium' | 'high') {
    if (!this.renderer) return;
    if (quality === 'low') {
      this.renderer.shadowMap.enabled = false;
      this.renderer.setPixelRatio(1);
    } else if (quality === 'medium') {
      this.renderer.shadowMap.enabled = !this.isSoftwareGl;
      this.renderer.setPixelRatio(1.2);
    } else {
      this.renderer.shadowMap.enabled = !this.isSoftwareGl;
      this.renderer.setPixelRatio(this.isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    }
  }

  public destroy() {
    this.isDestroyed = true;
    cancelAnimationFrame(this.animFrameId);
    window.removeEventListener('keydown', this.handleKeyDown);
    window.removeEventListener('keyup', this.handleKeyUp);
    window.removeEventListener('blur', this.handleBlur);
    window.removeEventListener('resize', this.handleResize);

    sound.stopEngine();
    this.clearLevelObjects();
    this.renderer.dispose();

    if (this.container && this.renderer.domElement) {
      this.container.removeChild(this.renderer.domElement);
    }
  }
}

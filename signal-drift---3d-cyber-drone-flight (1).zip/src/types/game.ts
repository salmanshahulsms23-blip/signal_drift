export type ScreenMode = 
  | 'registration'
  | 'pilot_select'
  | 'hangar'
  | 'splash' 
  | 'main_menu' 
  | 'level_select' 
  | 'briefing' 
  | 'playing' 
  | 'paused' 
  | 'victory' 
  | 'failed';

export type GateColor = 'red' | 'blue' | 'green' | 'purple' | 'orange' | 'yellow' | 'cyan' | 'magenta' | 'amber' | 'emerald' | 'violet';

export type GateSymbol = 'triangle' | 'circle' | 'star' | 'lightning' | 'diamond' | 'hexagon';

export interface GateQuestion {
  question: string;
  options: [string, string, string]; // exactly 3 options
  correctIndex: number;
  explanation?: string;
  timeLimit?: number; // for mission 13
}

export interface GateData {
  id: string;
  index: number; // 1-based order in sequence
  position: [number, number, number];
  rotationY: number; // orientation in radians
  radius: number;
  color: GateColor;
  symbol: GateSymbol;
  label?: string; // e.g. "Red Triangle"
  isDecoy?: boolean;
  // Special Mechanics
  isTimed?: boolean; // Mission 8-10, 20
  timeLimit?: number; // seconds (default 10)
  teleportTarget?: [number, number, number];
  isQuestionGate?: boolean; // Mission 11-13, 20
  question?: GateQuestion;
  isMoving?: boolean; // Mission 14, 20
  moveStart?: [number, number, number];
  moveEnd?: [number, number, number];
  moveSpeed?: number;
  swapWithId?: string; // Mission 17
}

export interface EnergyCellData {
  id: string;
  position: [number, number, number];
  collected: boolean;
}

export type HazardType = 'patrol_drone' | 'security_chaser' | 'laser_beam' | 'wind_zone' | 'floating_debris';

export interface HazardData {
  id: string;
  type: HazardType;
  position: [number, number, number];
  size?: [number, number, number];
  // For patrol drones:
  patrolStart?: [number, number, number];
  patrolEnd?: [number, number, number];
  speed?: number;
  // For wind zones:
  windForce?: [number, number, number];
  // For lasers:
  laserEnd?: [number, number, number];
  cyclePeriod?: number;
}

export interface MissionData {
  id: number;
  name: string;
  sector: string;
  briefing: string;
  droneStart: [number, number, number];
  droneStartRotY: number;
  gates: GateData[];
  energyCells: [number, number, number][];
  hazards: HazardData[];
  towerPosition: [number, number, number];
  timeLimit: number; // in seconds
  previewDuration: number; // in seconds
  batteryDrainRate: number; // % per second base
  skyTheme: 'dawn' | 'dusk' | 'midnight' | 'neon_storm' | 'aurora' | 'solar';
  starScores: [number, number, number]; // 1, 2, 3 stars
  // Special mission flags
  isBlackout?: boolean; // Mission 16
  blackoutGateThreshold?: number; // unblackout after this gate
  hasGateSwap?: boolean; // Mission 17
  hasStorm?: boolean; // Mission 15
  hasChaser?: boolean; // Mission 19
}

export interface LevelProgress {
  stars: number;
  score: number;
  accuracy: number;
  bestTime: number;
  completed: boolean;
}

export interface DroneCosmetics {
  equippedSkin: string;
  equippedEngineColor: string;
  equippedPropellerStyle: string;
  equippedBoostTrail: string;
  purchasedSkins: string[];
  purchasedEngineColors: string[];
  purchasedPropellers: string[];
  purchasedTrails: string[];
}

export interface DroneUpgrades {
  acceleration: number; // 0-5
  batteryCapacity: number; // 0-5
  turboEfficiency: number; // 0-5
  windResistance: number; // 0-5
  hullShield: number; // 0 or 1
  turboRecharge: number; // 0-5
}

export interface GameSettings {
  sound: boolean;
  soundVolume: number;
  music: boolean;
  musicVolume: number;
  graphics: 'low' | 'medium' | 'high';
  invertPitch: boolean;
  touchControls: boolean;
}

export interface ProfileMeta {
  id: string;
  nickname: string;
  avatar: string;
  starterColor: string;
  createdAt: number;
  level: number;
  credits: number;
  unlockedLevel: number;
}

export interface UserProfile {
  id: string;
  nickname: string;
  avatar: string;
  starterColor: string;
  createdAt: number;
  credits: number;
  xp: number;
  level: number;
  unlockedLevel: number;
  testingUnlockedAll?: boolean;
  levelScores: Record<number, LevelProgress>;
  achievements: string[];
  totalMissionsCompleted: number;
  totalGatesCleared: number;
  totalEnergyCells: number;
  cosmetics: DroneCosmetics;
  upgrades: DroneUpgrades;
  settings: GameSettings;
}

// Deprecated alias for backwards compatibility
export type PlayerStats = UserProfile;

export type TurboState = 'ready' | 'active' | 'cooldown';

export interface LiveFlightStats {
  battery: number;
  health: number;
  shieldActive: boolean;
  score: number;
  creditsEarnedThisFlight: number;
  currentGateIndex: number; // index of next gate to hit (0 to gates.length)
  totalGates: number;
  correctSequence: { index: number; color: GateColor; symbol: GateSymbol; label: string }[];
  nextGateRequirement: { index: number; color: GateColor; symbol: GateSymbol; label: string } | null;
  wrongGatesHit: number;
  collisionsCount: number;
  cellsCollected: number;
  totalCells: number;
  elapsedTime: number;
  timeRemaining: number;
  speed: number;
  altitude: number;
  isBoosting: boolean;
  turboState: TurboState;
  turboTimeRemaining: number; // 0 to 6
  turboCooldownRemaining: number; // 0 to 3
  streak: number;
  nextTargetName: string;
  nextTargetDistance: number;
  compassAngle: number; // degrees relative to drone heading
  isBlackout: boolean; // hide compass/minimap
  towerActive: boolean;
  missionStatusText: string;
  // Special Mechanics State
  timedGateSecondsLeft: number | null;
  activeQuestionGate: {
    question: string;
    options: [string, string, string];
    correctIndex: number;
    explanation?: string;
    timeRemaining?: number;
  } | null;
}

export interface MissionResult {
  missionId: number;
  success: boolean;
  score: number;
  stars: number;
  accuracy: number;
  batteryRemaining: number;
  timeElapsed: number;
  cellsCollected: number;
  totalCells: number;
  xpEarned: number;
  creditsEarned: number;
  newLevel: boolean;
  newAchievements: string[];
  failureReason?: string;
}

export interface AchievementDef {
  id: string;
  title: string;
  description: string;
  icon: string;
  xp: number;
  credits: number;
}

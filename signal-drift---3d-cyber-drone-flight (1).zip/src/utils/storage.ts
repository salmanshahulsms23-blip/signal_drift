import {
  GameSettings,
  UserProfile,
  ProfileMeta,
  AchievementDef,
  DroneCosmetics,
  DroneUpgrades,
} from '../types/game';

export const PROFILES_KEY = 'signalDrift:profiles';
export const ACTIVE_PROFILE_KEY = 'signalDrift:activeProfileId';
export const PROFILE_PREFIX = 'signalDrift:profile:';
const OLD_STATS_KEY = 'signal_drift_player_stats_v1';
const OLD_SETTINGS_KEY = 'signal_drift_settings_v1';

export const AVATARS = [
  { id: 'neon_vector', label: 'Neon Vector', icon: '⚡' },
  { id: 'cyber_falcon', label: 'Cyber Falcon', icon: '🦅' },
  { id: 'aegis_core', label: 'Aegis Core', icon: '🛡️' },
  { id: 'nova_pilot', label: 'Nova Pilot', icon: '🚀' },
  { id: 'void_navigator', label: 'Void Navigator', icon: '🌌' },
  { id: 'prism_drone', label: 'Prism Drone', icon: '💠' },
  { id: 'apex_hunter', label: 'Apex Hunter', icon: '🎯' },
  { id: 'warp_drift', label: 'Warp Drift', icon: '🌀' },
  { id: 'cyber_kitsune', label: 'Cyber Kitsune', icon: '🦊' },
  { id: 'pulse_striker', label: 'Pulse Striker', icon: '⚡' },
  { id: 'chrono_eye', label: 'Chrono Eye', icon: '🔮' },
  { id: 'mecha_ace', label: 'Mecha Ace', icon: '🤖' },
];

export const STARTER_COLORS = [
  { id: 'cyan', label: 'Cyan Blue', hex: '#00f0ff' },
  { id: 'magenta', label: 'Neon Magenta', hex: '#ff00aa' },
  { id: 'amber', label: 'Solar Amber', hex: '#f59e0b' },
  { id: 'emerald', label: 'Electric Lime', hex: '#10b981' },
  { id: 'violet', label: 'Ultra Violet', hex: '#8b5cf6' },
  { id: 'crimson', label: 'Plasma Red', hex: '#ef4444' },
];

export const HANGAR_SKINS = [
  {
    id: 'starter',
    name: 'Starter Skyward',
    description: 'Standard aerocraft alloy composite with high agility.',
    price: 0,
    primaryColor: 0x181e29,
    accentColor: 0x00f0ff,
  },
  {
    id: 'neon_scout',
    name: 'Neon Scout',
    description: 'Sleek carbon-weave frame with high-frequency neon accents.',
    price: 400,
    primaryColor: 0x111827,
    accentColor: 0xec4899,
  },
  {
    id: 'solar_glider',
    name: 'Solar Glider',
    description: 'Thermal-plated gold chassis built for high solar radiation.',
    price: 750,
    primaryColor: 0x27272a,
    accentColor: 0xf59e0b,
  },
  {
    id: 'phantom_wing',
    name: 'Phantom Wing',
    description: 'Stealth matte-obsidian frame with crimson telemetry sensors.',
    price: 1100,
    primaryColor: 0x09090b,
    accentColor: 0xef4444,
  },
  {
    id: 'aurora_runner',
    name: 'Aurora Runner',
    description: 'Iridescent stratospheric hull tuned for high-altitude rifts.',
    price: 1600,
    primaryColor: 0x064e3b,
    accentColor: 0x10b981,
  },
  {
    id: 'quantum_drift',
    name: 'Quantum Drift',
    description: 'Superconducting titanium body with hyper-reactive thrusters.',
    price: 2200,
    primaryColor: 0x0f172a,
    accentColor: 0x06b6d4,
  },
  {
    id: 'signal_master',
    name: 'Signal Master',
    description: 'Legendary Apex Flight Spire casing. The pinnacle of drone tech.',
    price: 3500,
    primaryColor: 0x1e1b4b,
    accentColor: 0xa855f7,
  },
];

export const HANGAR_UPGRADES = [
  {
    id: 'acceleration',
    name: 'Thrust Boosters',
    description: 'Increases engine acceleration by +15% per tier.',
    maxLevel: 5,
    baseCost: 200,
    costMultiplier: 1.5,
  },
  {
    id: 'batteryCapacity',
    name: 'High-Density Cells',
    description: 'Expands maximum battery storage capacity by +15% per tier.',
    maxLevel: 5,
    baseCost: 200,
    costMultiplier: 1.5,
  },
  {
    id: 'turboEfficiency',
    name: 'Overdrive Regulators',
    description: 'Reduces battery drain during Turbo Boost by 15% per tier.',
    maxLevel: 5,
    baseCost: 250,
    costMultiplier: 1.5,
  },
  {
    id: 'windResistance',
    name: 'Aero Gyroscopes',
    description: 'Mitigates crosswind drift force by 20% per tier.',
    maxLevel: 5,
    baseCost: 250,
    costMultiplier: 1.5,
  },
  {
    id: 'hullShield',
    name: 'Impact Aegis Shield',
    description: 'Deploys a regenerative energy barrier absorbing 1 collision per flight.',
    maxLevel: 1,
    baseCost: 650,
    costMultiplier: 1,
  },
  {
    id: 'turboRecharge',
    name: 'Quick-Cycle Capacitors',
    description: 'Reduces Turbo cooldown from 3.0s down to 1.8s.',
    maxLevel: 5,
    baseCost: 220,
    costMultiplier: 1.4,
  },
];

export const ACHIEVEMENTS: AchievementDef[] = [
  {
    id: 'first_flight',
    title: 'First Flight',
    description: 'Complete your first drone assignment in District Alpha.',
    icon: '🚀',
    xp: 250,
    credits: 150,
  },
  {
    id: 'flawless_route',
    title: 'Flawless Route',
    description: 'Complete a mission with 100% gate sequence accuracy.',
    icon: '🎯',
    xp: 400,
    credits: 250,
  },
  {
    id: 'energy_saver',
    title: 'Power Conserver',
    description: 'Complete a mission with over 65% battery remaining.',
    icon: '⚡',
    xp: 350,
    credits: 200,
  },
  {
    id: 'no_collision',
    title: 'Clean Hull',
    description: 'Finish a mission without colliding with any obstacles.',
    icon: '🛡️',
    xp: 450,
    credits: 300,
  },
  {
    id: 'speed_pilot',
    title: 'Speed Pilot',
    description: 'Complete a mission in under 50% of the allocated time limit.',
    icon: '⏱️',
    xp: 500,
    credits: 350,
  },
  {
    id: 'cell_collector',
    title: 'Overcharge',
    description: 'Collect all energy cells available in a single mission.',
    icon: '💎',
    xp: 350,
    credits: 200,
  },
  {
    id: 'decoy_buster',
    title: 'Decoy Proof',
    description: 'Complete a mission featuring decoy gates without hitting a fake.',
    icon: '👁️',
    xp: 400,
    credits: 250,
  },
  {
    id: 'three_star_ace',
    title: 'Three-Star Ace',
    description: 'Earn 3 stars across at least 8 different missions.',
    icon: '⭐',
    xp: 600,
    credits: 500,
  },
  {
    id: 'signal_master',
    title: 'Signal Master',
    description: 'Successfully restore all 20 Signal Towers across the metropolis.',
    icon: '👑',
    xp: 2000,
    credits: 1500,
  },
];

export const DEFAULT_SETTINGS: GameSettings = {
  sound: true,
  soundVolume: 0.8,
  music: true,
  musicVolume: 0.45,
  graphics: 'high',
  invertPitch: false,
  touchControls: false,
};

export const DEFAULT_COSMETICS: DroneCosmetics = {
  equippedSkin: 'starter',
  equippedEngineColor: 'cyan',
  equippedPropellerStyle: 'standard',
  equippedBoostTrail: 'cyan_plasma',
  purchasedSkins: ['starter'],
  purchasedEngineColors: ['cyan'],
  purchasedPropellers: ['standard'],
  purchasedTrails: ['cyan_plasma'],
};

export const DEFAULT_UPGRADES: DroneUpgrades = {
  acceleration: 0,
  batteryCapacity: 0,
  turboEfficiency: 0,
  windResistance: 0,
  hullShield: 0,
  turboRecharge: 0,
};

export function createDefaultProfile(id: string, nickname: string, avatar: string, starterColor: string): UserProfile {
  return {
    id,
    nickname,
    avatar,
    starterColor,
    createdAt: Date.now(),
    credits: 300, // starter gift
    xp: 0,
    level: 1,
    unlockedLevel: 1,
    testingUnlockedAll: false,
    levelScores: {},
    achievements: [],
    totalMissionsCompleted: 0,
    totalGatesCleared: 0,
    totalEnergyCells: 0,
    cosmetics: {
      ...DEFAULT_COSMETICS,
      equippedEngineColor: starterColor || 'cyan',
      purchasedEngineColors: [starterColor || 'cyan'],
    },
    upgrades: { ...DEFAULT_UPGRADES },
    settings: { ...DEFAULT_SETTINGS },
  };
}

// --- PROFILE STORAGE MANAGERS ---

export function listProfiles(): ProfileMeta[] {
  try {
    // Check auto migration first
    checkAutoMigration();

    const raw = localStorage.getItem(PROFILES_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function saveProfilesList(list: ProfileMeta[]): void {
  try {
    localStorage.setItem(PROFILES_KEY, JSON.stringify(list));
  } catch {
    // localStorage full
  }
}

export function getActiveProfileId(): string | null {
  try {
    return localStorage.getItem(ACTIVE_PROFILE_KEY);
  } catch {
    return null;
  }
}

export function setActiveProfileId(id: string): void {
  try {
    localStorage.setItem(ACTIVE_PROFILE_KEY, id);
  } catch {
    // ignore
  }
}

export function loadProfile(id: string): UserProfile | null {
  try {
    const raw = localStorage.getItem(PROFILE_PREFIX + id);
    if (!raw) return null;
    const profile = JSON.parse(raw) as UserProfile;
    // ensure fallback defaults
    return {
      ...profile,
      cosmetics: { ...DEFAULT_COSMETICS, ...(profile.cosmetics || {}) },
      upgrades: { ...DEFAULT_UPGRADES, ...(profile.upgrades || {}) },
      settings: { ...DEFAULT_SETTINGS, ...(profile.settings || {}) },
      levelScores: profile.levelScores || {},
      achievements: profile.achievements || [],
    };
  } catch {
    return null;
  }
}

export function saveProfile(profile: UserProfile): void {
  try {
    localStorage.setItem(PROFILE_PREFIX + profile.id, JSON.stringify(profile));
    // update meta in profiles list
    const profiles = listProfiles();
    const idx = profiles.findIndex((p) => p.id === profile.id);
    const meta: ProfileMeta = {
      id: profile.id,
      nickname: profile.nickname,
      avatar: profile.avatar,
      starterColor: profile.starterColor,
      createdAt: profile.createdAt,
      level: profile.level,
      credits: profile.credits,
      unlockedLevel: profile.unlockedLevel,
    };
    if (idx >= 0) {
      profiles[idx] = meta;
    } else {
      profiles.push(meta);
    }
    saveProfilesList(profiles);
  } catch {
    // ignore
  }
}

export function createNewProfile(nickname: string, avatar: string, starterColor: string): UserProfile {
  const id = 'pilot_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7);
  const profile = createDefaultProfile(id, nickname, avatar, starterColor);
  saveProfile(profile);
  setActiveProfileId(id);
  return profile;
}

export function updateProfileNickname(id: string, newNickname: string): void {
  const profile = loadProfile(id);
  if (!profile) return;
  profile.nickname = newNickname;
  saveProfile(profile);
}

export function deleteProfile(id: string): string | null {
  try {
    localStorage.removeItem(PROFILE_PREFIX + id);
    const profiles = listProfiles().filter((p) => p.id !== id);
    saveProfilesList(profiles);

    const activeId = getActiveProfileId();
    if (activeId === id) {
      const nextActive = profiles.length > 0 ? profiles[0].id : null;
      if (nextActive) {
        setActiveProfileId(nextActive);
      } else {
        localStorage.removeItem(ACTIVE_PROFILE_KEY);
      }
      return nextActive;
    }
    return activeId;
  } catch {
    return null;
  }
}

// Automatic migration from previous single-user version into "Pilot One"
export function checkAutoMigration(): void {
  try {
    const rawOld = localStorage.getItem(OLD_STATS_KEY);
    const rawProfiles = localStorage.getItem(PROFILES_KEY);

    if (rawOld && (!rawProfiles || JSON.parse(rawProfiles).length === 0)) {
      const oldStats = JSON.parse(rawOld);
      let oldSettings = DEFAULT_SETTINGS;
      const rawSettings = localStorage.getItem(OLD_SETTINGS_KEY);
      if (rawSettings) {
        oldSettings = { ...DEFAULT_SETTINGS, ...JSON.parse(rawSettings) };
      }

      const id = 'pilot_migrated_1';
      const migratedProfile: UserProfile = {
        id,
        nickname: 'Pilot One',
        avatar: '⚡',
        starterColor: 'cyan',
        createdAt: Date.now(),
        credits: 500 + (oldStats.totalMissionsCompleted || 0) * 150,
        xp: oldStats.xp || 0,
        level: oldStats.level || 1,
        unlockedLevel: Math.max(1, oldStats.unlockedLevel || 1),
        testingUnlockedAll: false,
        levelScores: oldStats.levelScores || {},
        achievements: oldStats.achievements || [],
        totalMissionsCompleted: oldStats.totalMissionsCompleted || 0,
        totalGatesCleared: oldStats.totalGatesCleared || 0,
        totalEnergyCells: oldStats.totalEnergyCells || 0,
        cosmetics: { ...DEFAULT_COSMETICS },
        upgrades: { ...DEFAULT_UPGRADES },
        settings: oldSettings,
      };

      saveProfile(migratedProfile);
      setActiveProfileId(id);
    }
  } catch {
    // migration failed safely
  }
}

export function calculateLevelFromXP(xp: number): number {
  let lvl = 1;
  let needed = 500;
  let accumulated = 0;

  while (xp >= accumulated + needed) {
    accumulated += needed;
    lvl++;
    needed += 350;
  }
  return lvl;
}

export function getXPProgressInLevel(xp: number): { current: number; max: number; ratio: number } {
  let needed = 500;
  let accumulated = 0;

  while (xp >= accumulated + needed) {
    accumulated += needed;
    needed += 350;
  }
  const current = xp - accumulated;
  return {
    current,
    max: needed,
    ratio: Math.min(1, Math.max(0, current / needed)),
  };
}

export function getRankTitle(level: number): string {
  if (level >= 16) return 'Stratosphere Ace Supreme';
  if (level >= 12) return 'Apex Flight Commander';
  if (level >= 8) return 'Senior Signal Navigator';
  if (level >= 5) return 'Skyway Specialist';
  if (level >= 3) return 'Cyber Courier Pilot';
  if (level >= 2) return 'Aero Cadet';
  return 'Rookie Operator';
}

export function loadSettings(): GameSettings {
  try {
    const raw = localStorage.getItem('signal_drift_settings_v1');
    if (!raw) return DEFAULT_SETTINGS;
    return { ...DEFAULT_SETTINGS, ...JSON.parse(raw) };
  } catch {
    return DEFAULT_SETTINGS;
  }
}

export function saveSettings(settings: GameSettings): void {
  try {
    localStorage.setItem('signal_drift_settings_v1', JSON.stringify(settings));
  } catch {
    // ignore
  }
}

